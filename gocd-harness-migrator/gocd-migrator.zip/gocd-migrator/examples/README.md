# Examples

This directory contains representative GoCD input YAML files and their
corresponding converted Harness pipeline YAML output, covering the main
pipeline patterns supported by the tool.

## Input files (`input/`)

| File | Pattern |
|---|---|
| `docker-k8s-deploy.gocd.yaml` | K8s Docker Build + Deploy (CI + CD) |
| `db-migration.gocd.yaml` | RDS / DB Migration |
| `terraform-infrastructure.gocd.yaml` | Terraform Infrastructure Provisioning |
| `ops-script-pipeline.gocd.yaml` | Ops Script / SOP runbook |

## Output files (`output/`)

Each `.harness.yaml` file in `output/` is the converted Harness pipeline
YAML produced by running `python main.py convert` against the corresponding
input file. Output filenames match the input names.

## Running the conversion yourself

```bash
cd harness-migration-tool

# Convert a single file
python main.py convert \
  --input ../examples/input/docker-k8s-deploy.gocd.yaml \
  --output ../examples/output/

# Batch-convert a whole directory of GoCD YAMLs
python main.py batch \
  --input-dir /path/to/gocd-pipelines \
  --output /path/to/output
```
