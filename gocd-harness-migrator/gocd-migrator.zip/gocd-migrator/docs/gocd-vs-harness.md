# GoCD vs Harness CD

Entity mapping, platform comparison, and step-by-step migration guide for teams moving from GoCD to Harness Continuous Delivery.

---

**On this page**

- [1. Platform Overview](#1-platform-overview)
- [2. Key Differences](#2-key-differences)
- [3. Core Concept Mapping](#3-core-concept-mapping)
- [4. Artifact Sources](#4-artifact-sources)
- [5. Natively Supported Deployment Platforms](#5-natively-supported-deployment-platforms)
- [6. GoCD Agents vs Harness Connectors](#6-gocd-agents-vs-harness-connectors)
- [7. Migration of GoCD Entities to Harness](#7-migration-of-gocd-entities-to-harness)

---

## 1. Platform Overview

GoCD and Harness CD are both continuous delivery platforms designed to automate the release process. They are architected differently and target somewhat different use cases. Below is a high-level look at what each platform brings to the table.

### What GoCD Essentially Is

An open-source continuous integration and delivery platform originally created by ThoughtWorks. It focuses on pipeline-as-code, modeling sophisticated multi-stage pipelines with clear dependency management.

- Uses agents (elastic or static) to run jobs distributed across cloud or on-prem infrastructure
- Strong workflow visualization emphasizing flow of changes through environments
- Highly flexible — supports custom tooling, scripting, and integrations with common SCM and artifact repos
- Excels in managing complex dependency graphs and parallel execution at scale
- Best suited for teams that want full control and transparency over pipelines and agent management

### What Harness CD Essentially Is

A commercial SaaS-first continuous delivery platform that also supports self-hosted runners (delegates). It provides built-in, cloud-native deployment strategies like canary, blue/green, rolling, and serverless.

- User-friendly interface with plug-and-play integrations for cloud environments, GitOps, and monitoring
- AI-driven continuous verification for deployment quality and automatic rollback capabilities
- Deep integration with AWS, Google Cloud, Azure, and Kubernetes ecosystems
- Designed for scalability and ease of use with minimal operational overhead
- Targets developers, DevOps teams, and enterprises wanting to reduce toil with automation and built-in best practices

---

## 2. Key Differences

While both platforms solve the same fundamental problem — getting code from commit to production safely — they take different approaches. This table highlights the core trade-offs.

| Aspect | GoCD | Harness CD |
|---|---|---|
| **Origin** | Open Source, Enterprise Friendly | Commercial SaaS with open edition |
| **Deployment Model** | Self-managed, agent-based | SaaS-first with self-hosted delegates |
| **Pipeline Modeling** | Highly configurable pipeline-as-code | Visual, template-driven with abstractions |
| **Cloud-Native Support** | Requires manual scripting/configuration | Native integrations with cloud & serverless |
| **Deployment Strategies** | Custom workflows, manual setups | Built-in progressive deployment strategies |
| **Verification & Rollbacks** | Manual or custom scripting | AI-driven continuous verification with auto-rollback |
| **UI/UX Focus** | Developer/DevOps focused, detailed interfaces | User-friendly, observability & automation focused |
| **Flexibility** | High customization, complex use cases | Turnkey solutions, simpler setup with less customization |

---

## 3. Core Concept Mapping

The core concepts in Harness CD and GoCD largely align in function and purpose, even though the terminology differs. Both systems address the same challenges — defining *what* gets deployed, *how* it is deployed, *where* it is deployed, and *who* executes it.

This mapping shows how each concept pair fulfills the same role across both platforms.

| Harness CD Concept | GoCD Equivalent | What It Solves | Harness CD Definition | GoCD Definition |
|---|---|---|---|---|
| **Delegate** | Agent / Elastic Agent | Executes pipeline jobs remotely or locally | Software installed in your environment that connects to Harness and executes deployment and pipeline tasks. | Worker machines that execute jobs assigned by GoCD server, either static or elastic. |
| **Connector** | Material | Connects pipelines with SCM and artifact repos | Defines authentication and location info for external systems (Git, artifact repos, K8s clusters, etc.). | Defines a source (Git, SVN, artifact repo) that triggers pipelines and provides code/artifacts. |
| **Service** | Pipeline (partially) | Represents what gets deployed | Logical representation of an application or microservice deployed via pipelines. | Models the entire CI/CD workflow for a service. |
| **Environment** | Environment | Defines where deployments happen | Logical grouping of deployment targets (clusters, hosts, regions) with infrastructure definitions. | Represents deployment targets like dev, QA, production within GoCD. |
| **Pipeline** | Pipeline | Defines the delivery execution flow | A series of stages performing deployments to environments, with approvals, triggers, and variables. | A sequence of stages and jobs modeling CI/CD workflow steps for build, test, and deploy. |
| **Stage** | Stage | Organizes jobs/tasks into logical phases | A subset of a pipeline performing a major lifecycle segment (build, deploy, approval). | Groups jobs in a pipeline; represents a milestone in the delivery lifecycle. |
| **Step** | Job / Task | Smallest unit of execution in a stage | An atomic operation within a stage (deploy, script execution) executed by a delegate. | A unit of work executed by an agent; jobs are collections of tasks. |
| **—** | Task | Modularizes jobs into atomic tasks | *(No direct separate concept — tasks are part of Steps in Harness)* | Individual commands or scripts inside a job. |
| **Project** | Pipeline Group | Organizes CI/CD setups into manageable units | Organizational container grouping pipelines, services, and environments by team or business unit. | A group of related pipelines organized by team or feature. |
| **Template** | Template | Reuse common pipeline structures | Reusable pipeline, stage, or step definition template for standardization. | Reusable pipeline or stage definition enabling consistent workflow patterns. |
| **Trigger** | Material / Trigger | Automatically starts pipelines based on events | Events like Git commits, artifact availability, or schedule that initiate pipeline execution. | SCM commits, manual triggers, scheduled jobs that start pipeline runs. |
| **Approval Step** | Manual Approval Stage | Controlled gatekeeping in deployment pipelines | Human approval step integrated into pipelines to gate deployment progress. | Manual intervention requiring explicit approval before proceeding. |
| **Failure Strategy** | Failure Handling in Jobs | Determines how pipeline errors are handled | Error handling policies for steps or stages, including retry and rollback behavior. | Failure handling must be scripted or configured in job tasks with success/failure conditions. |
| **Variables** | Environment Variables | Parameterizes runs for different contexts | Customizable variables to parameterize pipelines and reuse across stages and services. | Pipeline variables, environment variables configurable per pipeline or environment. |

---

## 4. Artifact Sources

Artifact sources are the "what" that gets deployed — binaries, containers, packages, or other deployment artifacts fed into your pipelines. Both platforms treat artifact sources as fundamental components that trigger and feed deployment pipelines.

Harness CD supports multiple artifact sources natively through its UI, including popular container registries (Docker Hub, AWS ECR, Google GCR, Azure ACR), artifact repositories (Artifactory, Nexus), and its own Harness Artifact Registry. It also supports universal package formats and custom scripted sources.

GoCD manages artifacts primarily through plugin support and pipeline scripting. It integrates with the same registries and repositories but may require more manual configuration. Custom artifact handling is supported via scripts or plugins.

> **Key takeaway:** Harness abstracts many artifact source complexities through its UI, while GoCD provides granular control through configuration files and plugins.

---

## 5. Natively Supported Deployment Platforms

This table compares the deployment platforms available out-of-the-box in each tool. Harness prioritizes built-in integrations for modern cloud workloads. GoCD focuses on flexibility and extensibility, relying on custom scripting for specialized targets.

| Platform / Type | Harness CD | GoCD | Notes |
|---|---|---|---|
| **Kubernetes** | Yes | Yes | Both fully support K8s for application deployment. |
| **Native Helm** | Yes | Yes (via plugins) | Both support Helm-based deployments. |
| **Serverless Lambda** | Yes | Via script/CLI | Harness has built-in Lambda deployment; GoCD requires custom scripting. |
| **SSH** | Yes | Yes | Both can deploy using SSH commands. |
| **WinRM** | Yes | Yes (via plugins) | Both support Windows deployments; GoCD via agent plugins. |
| **AWS Auto Scaling Group** | Yes | Via script/CLI | Harness native; GoCD via custom steps or plugins. |
| **Spot Elastigroup** | Yes | — | Harness native integration for Spot instantiation. |
| **AWS Lambda** | Yes | Via Serverless Framework | Harness supports built-in steps; GoCD needs CLI usage. |
| **AWS SAM** | Yes | — | Harness supports first-class; GoCD requires user customization. |
| **Google Cloud Functions** | Yes | Via script/CLI | Harness supports GCF natively; GoCD requires scripting. |
| **Amazon ECS** | Yes | Via script/CLI | Harness supports ECS natively; GoCD via custom steps. |
| **Azure Web Apps** | Yes | Via script/CLI | Harness supports as built-in; GoCD uses Azure CLI/scripts. |
| **Tanzu Application Services** | Yes | — | Harness supports natively. |
| **Azure Functions** | Yes | Via script/CLI | Harness native; GoCD via Azure CLI scripting. |
| **Google Cloud Run** | Yes | Via script/CLI | Harness native; GoCD via gcloud CLI. |

> **Trade-off:** Harness offers more built-in integrations with less setup, while GoCD provides more flexibility for teams willing to invest in custom scripting and plugin configuration.

---

## 6. GoCD Agents vs Harness Connectors

These are fundamentally different concepts. GoCD Agents are worker nodes that *execute* pipeline jobs. Harness Connectors are authentication and location references to *external systems*. GoCD has no direct equivalent of Harness Connectors — it uses Materials, Plugins, and Job Scripts to integrate with external tools.

### GoCD Agent Types

**Static Agents**
Permanently registered agents running on dedicated machines or VMs. Managed and monitored manually. Suited for stable, long-lived build infrastructure.

**Elastic Agents (Kubernetes)**
Dynamically provisioned agents running as ephemeral pods on Kubernetes. Configured via the Kubernetes Elastic Agent Plugin with pod templates. Provides scaling and resource efficiency.

**Elastic Agents (Cloud)**
Dynamically provisioned agents on AWS, Azure, or Google Cloud via integration plugins. Less common, often requiring manual or custom configuration.

### How GoCD Integrates (Without Connectors)

GoCD connects to external tools through three mechanisms:

- **Materials** — define source repos (Git, SVN) that trigger pipelines
- **Plugins** — extend functionality for SCM, notifications, artifact stores, and elastic agents
- **Job scripts** — use shell commands and CLI tools (`kubectl`, `helm`, AWS CLI, `gcloud`) to interact with external platforms

In contrast, Harness Connectors provide a declarative, UI-driven way to authenticate and connect to the same external systems. You don't "plug in" specific connectors to a GoCD agent — instead, pipelines define integration steps using CLI tools or plugins combined with agent capabilities.

---

## 7. Migration of GoCD Entities to Harness

The migration path involves mapping each GoCD entity to its Harness equivalent and creating it via the Harness API. Below are the ordered steps for a complete migration.

### Step 1: Migrate GoCD Material (Git) → Harness Git Connector

**GoCD:** A "material" defines source code locations, typically Git repositories.

**Harness:** Create a Git Connector via API to link your repository.

API: [POST /connectors](https://apidocs.harness.io/connectors/createconnector)

---

### Step 2: Migrate GoCD Agent → Harness Delegate

**GoCD:** Agents execute jobs and stages on worker machines.

**Harness:** Delegates are worker pods that connect to Harness and execute workflow tasks. There is no direct "create" via REST — download the delegate YAML from the Harness UI and apply it to your cluster:

```bash
kubectl apply -f harness-delegate.yaml
```

After delegate installation, create a Kubernetes Connector referencing your delegate for cluster access.

API: [POST /connectors](https://apidocs.harness.io/connectors/createconnector)

---

### Step 3: Migrate GoCD Service Equivalent → Harness Service

**GoCD source:** Artifacts are produced by pipeline jobs, manifests live in Git materials, and deployment logic is defined as inline shell commands or script tasks.

**Harness target:** The Service entity centralizes deployment manifests (K8s YAML, Helm charts), artifact sources (Docker, Nexus), and deployment logic with parameterization for environments.

| GoCD Location | Harness Location | Action |
|---|---|---|
| Artifacts (on disk, server) | Service → Artifact Source | Define artifact source (Docker registry, Git, Nexus) |
| Manifests (in Git, material) | Service → Manifest | Reference manifest (K8s, Helm, ECS) via Git connector |
| Job/task with deployment cmd | Service Manifests & Steps | Move deployment scripts into Harness pipeline stage steps |
| Material (Git/SVN path) | Git Connector | Link repo via connector, reference path for manifests/artifacts |

API: [POST /api/services](https://apidocs.harness.io/services/createservicev2)

---

### Step 4: Migrate GoCD Environment & Infrastructure → Harness Environment & Infra Definition

**GoCD:** Environments are set manually and associated with agents and pipelines.

**Harness:** Create an Environment (e.g., "prod") and link it to an infrastructure definition (K8s cluster, AWS region, etc.).

APIs:
- Environment: [POST /ng/api/environments](https://apidocs.harness.io/environments/createenvironmentv2)
- Infrastructure: [POST /ng/api/environments/{envId}/infrastructures](https://apidocs.harness.io/infrastructures/createinfrastructure)

---

### Step 5: Migrate GoCD Jobs/Tasks → Harness Stage Execution Steps

**GoCD:** Each stage contains jobs, and each job has tasks (script, fetch artifact, etc.).

**Harness:** Each stage has an execution section with a list of steps — shell scripts, K8s manifest applies, build actions, approvals, etc.

**Conversion process:**

1. **Export** your GoCD pipeline definition (YAML or XML from config repos).
2. **Parse** stages and jobs/tasks — use PyYAML for YAML or `xml.etree.ElementTree` for XML.
3. **Map** GoCD task types to Harness step types:
   - `exec` (shell command) → ShellScript step
   - `fetch artifact` → Artifacts or ShellScript step
   - `ant` / `maven` → ShellScript or custom CI steps
4. **Generate** Harness pipeline JSON per stage, converting each GoCD job/task into a Harness step.
5. **Create** via the Harness API using your API key.

API: [POST /ng/api/pipelines](https://apidocs.harness.io/pipelines/create-pipeline)
