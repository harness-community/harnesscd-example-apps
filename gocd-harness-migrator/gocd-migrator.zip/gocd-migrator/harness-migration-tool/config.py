"""
Configuration for Harness Migration Tool.
Supports Gemini 2.0 Flash (primary) and Claude 3.5 Sonnet (quality fallback) on Vertex AI.
"""

from pydantic import BaseModel
from typing import Optional
import os


class LLMConfig(BaseModel):
    """LLM provider configuration for Vertex AI."""
    primary_model: str = "gemini-2.0-flash"
    fallback_model: str = "claude-3-5-sonnet-v2"
    gcp_project: str = os.getenv("GCP_PROJECT", "")
    gcp_region: str = os.getenv("GCP_REGION", "us-central1")
    temperature: float = 0.1
    max_output_tokens: int = 8192
    confidence_threshold: float = 70.0  # Below this, use LLM fallback


class AppConfig(BaseModel):
    """Application-level configuration."""
    app_name: str = "Harness Migration Tool"
    version: str = "1.0.0"
    debug: bool = os.getenv("DEBUG", "false").lower() == "true"
    host: str = os.getenv("HOST", "0.0.0.0")
    port: int = int(os.getenv("PORT", "8080"))
    max_upload_size_mb: int = 50
    batch_concurrency: int = 10


class HarnessConfig(BaseModel):
    """Harness-specific defaults."""
    org_identifier: str = "default"
    default_timeout: str = "10m"
    approval_timeout: str = "1d"
    secret_manager_ref: str = "harnessSecretManager"
    default_connector_ref: str = "GitHub_Connector"
    github_connector_ref: str = "account.GitHub_Connector"
    aws_connector_ref: str = "account.aws_connector"
    default_aws_region: str = "ap-south-1"


class Config(BaseModel):
    """Root configuration."""
    app: AppConfig = AppConfig()
    llm: LLMConfig = LLMConfig()
    harness: HarnessConfig = HarnessConfig()


# Global config instance
config = Config()
