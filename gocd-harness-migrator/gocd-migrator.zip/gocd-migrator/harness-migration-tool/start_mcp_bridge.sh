#!/bin/bash
# Start MCP Bridge Server for GoCD Migration
set -e

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${GREEN}🚀 Starting GoCD Migration MCP Bridge Server${NC}"
echo ""

# Check if port 8081 is already in use
if lsof -Pi :8081 -sTCP:LISTEN -t >/dev/null 2>&1 ; then
    echo -e "${YELLOW}⚠️  Port 8081 is already in use${NC}"
    echo ""
    echo "Options:"
    echo "  1. Kill the existing process: lsof -ti:8081 | xargs kill -9"
    echo "  2. Use a different port: python3 mcp_bridge.py --port 8082"
    echo ""
    read -p "Kill existing process? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo -e "${YELLOW}Killing process on port 8081...${NC}"
        lsof -ti:8081 | xargs kill -9
        sleep 1
    else
        echo -e "${RED}Exiting. Please free port 8081 or use a different port.${NC}"
        exit 1
    fi
fi

# Check if requirements are installed
echo -e "${GREEN}Checking dependencies...${NC}"
if ! python3 -c "import fastapi" 2>/dev/null; then
    echo -e "${YELLOW}⚠️  Dependencies not installed. Installing...${NC}"
    pip3 install -r requirements.txt
fi

# Set default environment variables if not set
export LOG_LEVEL=${LOG_LEVEL:-info}
export MIGRATION_HOST=${MIGRATION_HOST:-localhost}
export MIGRATION_PORT=${MIGRATION_PORT:-8081}

echo -e "${GREEN}✅ Dependencies OK${NC}"
echo ""
echo -e "${GREEN}Configuration:${NC}"
echo "  Host: $MIGRATION_HOST"
echo "  Port: $MIGRATION_PORT"
echo "  Log Level: $LOG_LEVEL"
echo ""
echo -e "${GREEN}📖 API Documentation:${NC}"
echo "  Swagger UI: http://$MIGRATION_HOST:$MIGRATION_PORT/docs"
echo "  Health Check: http://$MIGRATION_HOST:$MIGRATION_PORT/health"
echo ""
echo -e "${YELLOW}Press Ctrl+C to stop the server${NC}"
echo ""

# Start the server
python3 mcp_bridge.py \
    --host "$MIGRATION_HOST" \
    --port "$MIGRATION_PORT"
