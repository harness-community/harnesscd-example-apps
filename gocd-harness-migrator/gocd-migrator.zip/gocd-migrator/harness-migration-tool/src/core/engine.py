"""
Conversion Engine Orchestrator.

The central engine that coordinates the full pipeline:
  Parse -> Classify -> Convert -> Validate -> Extract Entities

Supports single-file and batch conversion modes.
"""

import yaml
from pathlib import Path
from typing import List, Optional, Dict

from config import config
from src.core.models import (
    ConversionResult, BatchResult, ConversionMethod,
    GocdPipeline, PatternMatch, Entity, EntityType,
    SourceType,
)
from src.parsers.gocd import GocdParser
from src.parsers.base import ParseError
from src.classifiers.gocd import GocdClassifier
from src.converters.gocd import get_converter
from src.validators.identifier import build_pipeline_tags


class ConversionEngine:
    """
    Main orchestrator for CI/CD pipeline migration.

    Supports GoCD as an input source (extensible to Jenkins, GitLab CI).
    """

    def __init__(self):
        self.parser = GocdParser()
        self.classifier = GocdClassifier()

    # ------------------------------------------------------------------
    # Single File Conversion
    # ------------------------------------------------------------------

    def convert_file(
        self, file_path: Path, source_repo: str = ""
    ) -> List[ConversionResult]:
        """
        Convert a single GoCD YAML file.

        Returns one ConversionResult per pipeline in the file.
        """
        results = []

        # Step 1: Parse
        try:
            pipelines = self.parser.parse_file(file_path)
        except ParseError as exc:
            return [ConversionResult(
                source_file=str(file_path),
                source_pipeline_name="(parse error)",
                source_type=SourceType.GOCD,
                pattern=PatternMatch(
                    pattern_id="error",
                    pattern_name="Parse Error",
                    confidence=0,
                ),
                errors=[str(exc)],
                success=False,
            )]

        # Step 2-4: Classify + Convert each pipeline
        for pipeline in pipelines:
            result = self.convert_pipeline(
                pipeline, source_file=str(file_path), source_repo=source_repo,
            )
            results.append(result)

        return results

    def convert_pipeline(
        self, pipeline: GocdPipeline, source_file: str = "",
        source_repo: str = "",
    ) -> ConversionResult:
        """Convert a single parsed GoCD pipeline."""

        # Step 2: Classify
        pattern = self.classifier.classify(pipeline)

        # Step 3: Convert
        converter = get_converter(pattern.converter_key)

        if converter is None:
            return ConversionResult(
                source_file=source_file,
                source_pipeline_name=pipeline.name,
                source_type=SourceType.GOCD,
                pattern=pattern,
                errors=[f"No converter found for pattern: {pattern.converter_key}"],
                success=False,
            )

        try:
            result = converter.convert(pipeline, pattern.pattern_id)
            result.source_file = source_file
            result.pattern = pattern
            result.source_type = SourceType.GOCD

            # Inject standard tags into the pipeline YAML
            self._inject_standard_tags(result, source_repo, pattern)

            if pattern.confidence < 50:
                result.warnings.append(
                    f"Low confidence match ({pattern.confidence:.0f}%). "
                    f"Manual review recommended."
                )

        except Exception as exc:
            result = ConversionResult(
                source_file=source_file,
                source_pipeline_name=pipeline.name,
                source_type=SourceType.GOCD,
                pattern=pattern,
                errors=[f"Conversion error: {exc}"],
                success=False,
            )

        return result

    def _inject_standard_tags(
        self, result: ConversionResult, source_repo: str,
        pattern: PatternMatch,
    ):
        """Merge standard migration tags into the converted pipeline YAML."""
        if not result.success or not result.harness_yaml:
            return

        pipeline_dict = result.harness_yaml.get("pipeline", {})
        existing_tags = pipeline_dict.get("tags", {})

        extra_tags = build_pipeline_tags(
            group="",
            source_repo=source_repo,
            pattern_name=pattern.pattern_name,
            converter_key=pattern.converter_key,
        )

        existing_tags.update(extra_tags)
        pipeline_dict["tags"] = existing_tags

    # ------------------------------------------------------------------
    # Batch Conversion
    # ------------------------------------------------------------------

    def convert_batch(self, directory: Path, glob_pattern: str = "*.yaml") -> BatchResult:
        """
        Convert all YAML files in a directory.

        Returns a BatchResult with per-file results and deduplicated entities.
        """
        batch = BatchResult()
        files = sorted(directory.glob(glob_pattern))
        batch.total_files = len(files)

        for file_path in files:
            file_results = self.convert_file(file_path)

            for result in file_results:
                batch.total_pipelines += 1
                batch.results.append(result)

                if result.success:
                    batch.successful += 1
                else:
                    batch.failed += 1

                if result.conversion_method in (
                    ConversionMethod.LLM_FALLBACK,
                    ConversionMethod.LLM_QUALITY,
                ):
                    batch.llm_fallback_used += 1

        # Deduplicate entities across all results
        batch.all_entities = self._deduplicate_entities(batch.results)

        return batch

    # ------------------------------------------------------------------
    # Entity Deduplication
    # ------------------------------------------------------------------

    def _deduplicate_entities(self, results: List[ConversionResult]) -> List[Entity]:
        """Collect and deduplicate entities across all conversion results."""
        seen = set()
        entities = []

        for result in results:
            for entity in result.entities:
                key = f"{entity.type}:{entity.identifier}"
                if key not in seen:
                    seen.add(key)
                    entities.append(entity)

        return entities

    # ------------------------------------------------------------------
    # Output Helpers
    # ------------------------------------------------------------------

    def result_to_yaml(self, result: ConversionResult) -> str:
        """Serialize a conversion result's Harness YAML to string."""
        if not result.harness_yaml:
            return ""

        # Remove internal keys (like _trigger)
        output = {k: v for k, v in result.harness_yaml.items() if not k.startswith("_")}
        return yaml.dump(output, default_flow_style=False, sort_keys=False, width=120)

    def write_results(self, results: List[ConversionResult], output_dir: Path):
        """Write conversion results to an output directory."""
        output_dir.mkdir(parents=True, exist_ok=True)

        for result in results:
            if not result.success or not result.harness_yaml:
                continue

            from src.validators.identifier import sanitize_identifier
            filename = f"{sanitize_identifier(result.source_pipeline_name)}.yaml"
            output_path = output_dir / filename

            yaml_str = self.result_to_yaml(result)
            output_path.write_text(yaml_str, encoding="utf-8")
