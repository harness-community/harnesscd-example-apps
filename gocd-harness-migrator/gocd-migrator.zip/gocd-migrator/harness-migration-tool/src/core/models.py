"""
Data models for the Harness Migration Tool.

These models represent the intermediate representation between source CI/CD systems
(GoCD, Jenkins, etc.) and the Harness target format. Every converter works with
these models rather than raw YAML dicts.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from enum import Enum


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class SourceType(str, Enum):
    """Supported source CI/CD systems."""
    GOCD = "gocd"
    JENKINS = "jenkins"        # future
    GITLAB_CI = "gitlab_ci"    # future


class ConversionMethod(str, Enum):
    """How a pipeline was converted."""
    RULE_BASED = "rule_based"
    LLM_FALLBACK = "llm_fallback"
    LLM_QUALITY = "llm_quality"


class EntityType(str, Enum):
    """Harness entity types."""
    PROJECT = "Project"
    CONNECTOR = "Connector"
    SECRET = "Secret"
    DELEGATE = "Delegate"
    SERVICE = "Service"
    ENVIRONMENT = "Environment"
    INFRA_DEFINITION = "InfrastructureDefinition"
    TRIGGER = "Trigger"
    INPUT_SET = "InputSet"
    USER_GROUP = "UserGroup"


class HarnessStageType(str, Enum):
    """Harness stage types."""
    CUSTOM = "Custom"
    DEPLOYMENT = "Deployment"
    CI = "CI"
    APPROVAL = "Approval"
    FEATURE_FLAG = "FeatureFlag"


class HarnessStepType(str, Enum):
    """Harness step types."""
    SHELL_SCRIPT = "ShellScript"
    TERRAFORM_PLAN = "TerraformPlan"
    TERRAFORM_APPLY = "TerraformApply"
    TERRAFORM_DESTROY = "TerraformDestroy"
    TERRAFORM_ROLLBACK = "TerraformRollback"
    HARNESS_APPROVAL = "HarnessApproval"
    RUN = "Run"
    BUILD_AND_PUSH_ECR = "BuildAndPushECR"
    BUILD_AND_PUSH_DOCKER = "BuildAndPushDockerRegistry"
    K8S_ROLLING_DEPLOY = "K8sRollingDeploy"
    K8S_APPLY = "K8sApply"
    HTTP = "Http"


# ---------------------------------------------------------------------------
# GoCD Source Models
# ---------------------------------------------------------------------------

@dataclass
class GocdMaterial:
    """A GoCD material (git repo or pipeline dependency)."""
    name: str
    type: str  # 'git' or 'pipeline'
    # Git-specific
    url: str = ""
    branch: str = "master"
    destination: str = ""
    auto_update: bool = True
    blacklist: List[str] = field(default_factory=list)
    # Pipeline dependency-specific
    pipeline: str = ""
    stage: str = ""


@dataclass
class GocdTask:
    """A GoCD task within a job."""
    type: str  # 'exec', 'fetch', 'unknown'
    # Exec-specific
    command: str = ""
    arguments: List[str] = field(default_factory=list)
    working_directory: str = ""
    # Fetch-specific
    fetch_stage: str = ""
    fetch_job: str = ""
    fetch_source: str = ""
    fetch_destination: str = ""
    fetch_pipeline: str = ""
    is_file: bool = False
    # Common
    run_if: str = ""
    raw: Dict[str, Any] = field(default_factory=dict)


@dataclass
class GocdArtifact:
    """A GoCD build artifact."""
    type: str = "build"  # 'build', 'test', 'external'
    source: str = ""
    destination: str = ""


@dataclass
class GocdJob:
    """A GoCD job within a stage."""
    name: str
    elastic_profile_id: str = ""
    tasks: List[GocdTask] = field(default_factory=list)
    artifacts: List[GocdArtifact] = field(default_factory=list)
    environment_variables: Dict[str, str] = field(default_factory=dict)
    timeout: int = 0  # 0 means no timeout


@dataclass
class GocdApproval:
    """GoCD stage approval configuration."""
    type: str = "success"  # 'manual' or 'success'
    roles: List[str] = field(default_factory=list)
    users: List[str] = field(default_factory=list)


@dataclass
class GocdStage:
    """A GoCD stage within a pipeline."""
    name: str
    jobs: List[GocdJob] = field(default_factory=list)
    approval: Optional[GocdApproval] = None
    clean_workspace: bool = False
    environment_variables: Dict[str, str] = field(default_factory=dict)


@dataclass
class GocdTimer:
    """GoCD timer/cron trigger."""
    spec: str = ""
    only_on_changes: bool = True


@dataclass
class GocdPipeline:
    """A fully parsed GoCD pipeline."""
    name: str
    group: str = "Default"
    label_template: str = ""
    parameters: Dict[str, str] = field(default_factory=dict)
    environment_variables: Dict[str, str] = field(default_factory=dict)
    materials: List[GocdMaterial] = field(default_factory=list)
    stages: List[GocdStage] = field(default_factory=list)
    timer: Optional[GocdTimer] = None

    @property
    def git_materials(self) -> List[GocdMaterial]:
        return [m for m in self.materials if m.type == "git"]

    @property
    def pipeline_materials(self) -> List[GocdMaterial]:
        return [m for m in self.materials if m.type == "pipeline"]

    @property
    def all_tasks(self) -> List[GocdTask]:
        """Flatten all tasks across all stages and jobs."""
        tasks = []
        for stage in self.stages:
            for job in stage.jobs:
                tasks.extend(job.tasks)
        return tasks

    @property
    def all_scripts(self) -> str:
        """Concatenate all exec task scripts for pattern detection."""
        scripts = []
        for task in self.all_tasks:
            if task.type == "exec":
                scripts.append(task.command)
                scripts.extend(task.arguments)
        return " ".join(scripts)

    @property
    def stage_names(self) -> List[str]:
        return [s.name for s in self.stages]


# ---------------------------------------------------------------------------
# Pattern Classification
# ---------------------------------------------------------------------------

@dataclass
class PatternMatch:
    """Result of classifying a GoCD pipeline into a known pattern."""
    pattern_id: str
    pattern_name: str
    confidence: float  # 0.0 to 100.0
    signals: List[str] = field(default_factory=list)
    converter_key: str = ""  # Maps to a registered converter


# ---------------------------------------------------------------------------
# Harness Entity
# ---------------------------------------------------------------------------

@dataclass
class Entity:
    """A Harness entity that needs to be created for the migration."""
    type: EntityType
    identifier: str
    name: str
    api_creatable: bool = True
    dependencies: List[str] = field(default_factory=list)
    api_script: str = ""
    manual_instructions: str = ""
    payload: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Conversion Result
# ---------------------------------------------------------------------------

@dataclass
class ConversionResult:
    """The complete output of converting a single pipeline."""
    source_file: str
    source_pipeline_name: str
    source_type: SourceType
    pattern: PatternMatch
    harness_yaml: Dict[str, Any] = field(default_factory=dict)
    entities: List[Entity] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    conversion_method: ConversionMethod = ConversionMethod.RULE_BASED
    success: bool = True
    additional_yamls: Dict[str, Dict[str, Any]] = field(default_factory=dict)


@dataclass
class BatchResult:
    """The complete output of converting a batch of files."""
    total_files: int = 0
    total_pipelines: int = 0
    successful: int = 0
    failed: int = 0
    llm_fallback_used: int = 0
    results: List[ConversionResult] = field(default_factory=list)
    all_entities: List[Entity] = field(default_factory=list)  # Deduplicated

    @property
    def success_rate(self) -> float:
        return (self.successful / self.total_pipelines * 100) if self.total_pipelines else 0.0
