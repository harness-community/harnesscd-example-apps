"""
Abstract base class for input parsers.

Each source CI/CD system (GoCD, Jenkins, GitLab CI) implements this interface
to parse its native YAML/config format into the common GocdPipeline model
(or a future generic SourcePipeline model).
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any
from pathlib import Path


class BaseParser(ABC):
    """Base class for all CI/CD source parsers."""

    @property
    @abstractmethod
    def source_type(self) -> str:
        """Return the source type identifier (e.g., 'gocd', 'jenkins')."""
        ...

    @abstractmethod
    def parse_file(self, file_path: Path) -> List[Any]:
        """
        Parse a source file and return a list of pipeline objects.

        A single file may contain multiple pipelines (common in GoCD).
        Returns a list of parsed pipeline dataclass instances.

        Raises:
            ParseError: If the file cannot be parsed.
        """
        ...

    @abstractmethod
    def parse_content(self, content: str, filename: str = "") -> List[Any]:
        """
        Parse raw YAML/config content and return pipeline objects.

        Useful for API endpoints where content is uploaded directly.
        """
        ...

    @abstractmethod
    def validate_format(self, content: str) -> bool:
        """
        Check if the content matches this parser's expected format.

        Returns True if the content looks like it belongs to this source type.
        """
        ...


class ParseError(Exception):
    """Raised when a source file cannot be parsed."""

    def __init__(self, message: str, file_path: str = "", details: str = ""):
        self.file_path = file_path
        self.details = details
        super().__init__(message)
