"""
GoCD YAML Parser.

Handles all GoCD YAML quirks:
- Duplicate YAML anchors (GoCD allows them, standard YAML doesn't)
- Null parameters / missing keys
- YAML aliases and anchors (&anchor / *anchor)
- Both 'working_directory' and 'working-directory' variants
- Approval as dict {'type': 'manual', 'roles': [...]} or string 'manual'
- Nested environment_variables at pipeline, stage, and job levels
"""

import re
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

from src.parsers.base import BaseParser, ParseError
from src.core.models import (
    GocdPipeline, GocdStage, GocdJob, GocdTask,
    GocdMaterial, GocdApproval, GocdArtifact, GocdTimer,
)


class GocdParser(BaseParser):
    """Parser for GoCD pipeline YAML files."""

    @property
    def source_type(self) -> str:
        return "gocd"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def parse_file(self, file_path: Path) -> List[GocdPipeline]:
        """Parse a GoCD YAML file into a list of GocdPipeline objects."""
        try:
            content = file_path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as exc:
            raise ParseError(
                f"Cannot read file: {exc}",
                file_path=str(file_path),
            )
        return self.parse_content(content, filename=str(file_path))

    def parse_content(self, content: str, filename: str = "") -> List[GocdPipeline]:
        """Parse raw GoCD YAML content into pipeline objects."""
        # Pre-process: deduplicate YAML anchors so standard parsers don't choke
        processed_content = self._deduplicate_anchors(content)

        # Parse YAML using ruamel (falls back to PyYAML if needed)
        raw = self._safe_yaml_load(processed_content, filename)
        if raw is None:
            raise ParseError("YAML parsed to None (empty file?)", file_path=filename)

        pipelines_dict = raw.get("pipelines")
        if not pipelines_dict or not isinstance(pipelines_dict, dict):
            raise ParseError(
                "No 'pipelines' key found in YAML",
                file_path=filename,
                details="GoCD YAML must have a top-level 'pipelines' mapping.",
            )

        pipelines: List[GocdPipeline] = []
        for name, spec in pipelines_dict.items():
            if spec is None:
                continue
            try:
                pipeline = self._parse_pipeline(name, spec)
                pipelines.append(pipeline)
            except Exception as exc:
                raise ParseError(
                    f"Error parsing pipeline '{name}': {exc}",
                    file_path=filename,
                    details=str(exc),
                )

        return pipelines

    def validate_format(self, content: str) -> bool:
        """Check if content looks like GoCD YAML."""
        return "pipelines:" in content and ("stages:" in content or "materials:" in content)

    # ------------------------------------------------------------------
    # YAML Loading with Duplicate Anchor Handling
    # ------------------------------------------------------------------

    def _deduplicate_anchors(self, content: str) -> str:
        """
        Rename duplicate YAML anchors to make them unique.

        GoCD allows duplicate anchors (last definition wins). Standard YAML
        parsers reject this. We scan for all anchor definitions (&name) and
        rename duplicates with a numeric suffix, updating corresponding
        aliases (*name) accordingly.
        """
        # Find all anchor definitions: &anchor_name
        anchor_pattern = re.compile(r'&([\w][\w\-]*)')
        anchor_counts: Dict[str, int] = {}
        anchor_renames: Dict[str, List[Tuple[int, str]]] = {}

        lines = content.split('\n')
        result_lines = []

        # First pass: identify duplicates and build rename map
        for line_num, line in enumerate(lines):
            for match in anchor_pattern.finditer(line):
                anchor_name = match.group(1)
                if anchor_name not in anchor_counts:
                    anchor_counts[anchor_name] = 0
                anchor_counts[anchor_name] += 1

                if anchor_counts[anchor_name] > 1:
                    new_name = f"{anchor_name}__dup{anchor_counts[anchor_name]}"
                    if anchor_name not in anchor_renames:
                        anchor_renames[anchor_name] = []
                    anchor_renames[anchor_name].append((line_num, new_name))

        if not anchor_renames:
            return content  # No duplicates, return as-is

        # Second pass: rename anchors and track which alias references
        # need updating. We process the content to rename only the
        # duplicate anchor definitions and their forward aliases.
        #
        # Strategy: For each duplicate anchor, rename the &anchor on
        # that line AND any *anchor references that appear AFTER that
        # line (until the next duplicate redefinition of the same anchor).
        processed = content
        for anchor_name, renames in anchor_renames.items():
            for line_num, new_name in renames:
                # Find the exact position in the line and rename
                old_anchor = f"&{anchor_name}"
                new_anchor = f"&{new_name}"

                # Process line by line to target the right occurrence
                lines = processed.split('\n')
                line = lines[line_num]
                # Replace the first occurrence of the anchor on this line
                lines[line_num] = line.replace(old_anchor, new_anchor, 1)

                # Now find all *anchor references after this line that
                # should point to this renamed anchor.
                # We look forward until we hit another &anchor (original or dup)
                for i in range(line_num + 1, len(lines)):
                    # Stop if we hit another definition of the same anchor
                    if f"&{anchor_name}" in lines[i]:
                        break
                    # Replace alias references
                    old_alias = f"*{anchor_name}"
                    new_alias = f"*{new_name}"
                    if old_alias in lines[i]:
                        lines[i] = lines[i].replace(old_alias, new_alias)

                processed = '\n'.join(lines)

        return processed

    def _safe_yaml_load(self, content: str, filename: str = "") -> Optional[Dict]:
        """Load YAML content, trying ruamel first, then PyYAML."""
        # Try ruamel.yaml first (better anchor handling)
        try:
            from ruamel.yaml import YAML
            yaml_parser = YAML()
            yaml_parser.preserve_quotes = True
            import io
            data = yaml_parser.load(io.StringIO(content))
            # Convert ruamel objects to plain dicts
            return self._to_plain_dict(data)
        except ImportError:
            pass
        except Exception:
            pass

        # Fallback to PyYAML
        try:
            import yaml
            return yaml.safe_load(content)
        except Exception as exc:
            raise ParseError(
                f"YAML parsing failed: {exc}",
                file_path=filename,
                details=str(exc),
            )

    def _to_plain_dict(self, obj: Any) -> Any:
        """Convert ruamel.yaml objects to plain Python dicts/lists/strings."""
        if obj is None:
            return None
        if isinstance(obj, dict):
            return {str(k): self._to_plain_dict(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [self._to_plain_dict(item) for item in obj]
        if isinstance(obj, (int, float, bool)):
            return obj
        return str(obj)

    # ------------------------------------------------------------------
    # Pipeline Parsing
    # ------------------------------------------------------------------

    def _parse_pipeline(self, name: str, spec: Dict[str, Any]) -> GocdPipeline:
        """Parse a single pipeline spec into a GocdPipeline."""
        pipeline = GocdPipeline(name=name)
        pipeline.group = spec.get("group", "Default") or "Default"
        pipeline.label_template = spec.get("label_template", "") or ""

        # Parameters (may be None)
        params = spec.get("parameters")
        pipeline.parameters = dict(params) if params else {}

        # Environment variables (may be None)
        env_vars = spec.get("environment_variables")
        pipeline.environment_variables = dict(env_vars) if env_vars else {}

        # Timer
        timer_spec = spec.get("timer")
        if timer_spec and isinstance(timer_spec, dict):
            pipeline.timer = GocdTimer(
                spec=str(timer_spec.get("spec", "")),
                only_on_changes=bool(timer_spec.get("only_on_changes", True)),
            )

        # Materials
        materials_spec = spec.get("materials")
        if materials_spec and isinstance(materials_spec, dict):
            pipeline.materials = self._parse_materials(materials_spec)

        # Stages
        stages_spec = spec.get("stages")
        if stages_spec and isinstance(stages_spec, list):
            pipeline.stages = self._parse_stages(stages_spec)

        return pipeline

    def _parse_materials(self, materials: Dict[str, Any]) -> List[GocdMaterial]:
        """Parse GoCD materials into GocdMaterial objects."""
        result = []
        for mat_name, mat_spec in materials.items():
            if mat_spec is None:
                continue

            if "git" in mat_spec:
                result.append(GocdMaterial(
                    name=mat_name,
                    type="git",
                    url=str(mat_spec["git"]),
                    branch=str(mat_spec.get("branch", "master") or "master"),
                    destination=str(mat_spec.get("destination", "") or ""),
                    auto_update=bool(mat_spec.get("autoUpdate", True)),
                    blacklist=list(mat_spec.get("blacklist", []) or []),
                ))
            elif "pipeline" in mat_spec:
                result.append(GocdMaterial(
                    name=mat_name,
                    type="pipeline",
                    pipeline=str(mat_spec["pipeline"]),
                    stage=str(mat_spec.get("stage", "") or ""),
                ))
            else:
                # Unknown material type -- capture raw for debugging
                result.append(GocdMaterial(
                    name=mat_name,
                    type="unknown",
                ))
        return result

    def _parse_stages(self, stages: List[Any]) -> List[GocdStage]:
        """Parse GoCD stages list into GocdStage objects."""
        result = []
        for stage_item in stages:
            if not isinstance(stage_item, dict):
                continue
            for stage_name, stage_spec in stage_item.items():
                if stage_spec is None:
                    continue
                result.append(self._parse_stage(stage_name, stage_spec))
        return result

    def _parse_stage(self, name: str, spec: Dict[str, Any]) -> GocdStage:
        """Parse a single GoCD stage."""
        stage = GocdStage(name=name)
        stage.clean_workspace = bool(spec.get("clean_workspace", False))

        # Environment variables at stage level
        env_vars = spec.get("environment_variables")
        stage.environment_variables = dict(env_vars) if env_vars else {}

        # Approval (can be dict or string)
        approval_spec = spec.get("approval")
        if approval_spec is not None:
            stage.approval = self._parse_approval(approval_spec)

        # Jobs
        jobs_spec = spec.get("jobs")
        if jobs_spec and isinstance(jobs_spec, dict):
            for job_name, job_spec in jobs_spec.items():
                if job_spec is None:
                    continue
                stage.jobs.append(self._parse_job(job_name, job_spec))

        return stage

    def _parse_approval(self, approval: Any) -> GocdApproval:
        """Parse approval config (string or dict)."""
        if isinstance(approval, str):
            return GocdApproval(type=approval)
        if isinstance(approval, dict):
            return GocdApproval(
                type=approval.get("type", "success") or "success",
                roles=list(approval.get("roles", []) or []),
                users=list(approval.get("users", []) or []),
            )
        return GocdApproval(type="success")

    def _parse_job(self, name: str, spec: Dict[str, Any]) -> GocdJob:
        """Parse a single GoCD job."""
        job = GocdJob(name=name)

        # Elastic profile ID
        job.elastic_profile_id = str(
            spec.get("elastic_profile_id", "") or ""
        )

        # Environment variables at job level
        env_vars = spec.get("environment_variables")
        job.environment_variables = dict(env_vars) if env_vars else {}

        # Tasks
        tasks_spec = spec.get("tasks")
        if tasks_spec and isinstance(tasks_spec, list):
            for task_item in tasks_spec:
                if not isinstance(task_item, dict):
                    continue
                job.tasks.append(self._parse_task(task_item))

        # Artifacts
        artifacts_spec = spec.get("artifacts")
        if artifacts_spec and isinstance(artifacts_spec, list):
            for art_item in artifacts_spec:
                if isinstance(art_item, dict):
                    for art_type, art_spec in art_item.items():
                        if isinstance(art_spec, dict):
                            job.artifacts.append(GocdArtifact(
                                type=str(art_type),
                                source=str(art_spec.get("source", "")),
                                destination=str(art_spec.get("destination", "")),
                            ))

        # Timeout
        job.timeout = int(spec.get("timeout", 0) or 0)

        return job

    def _parse_task(self, task_dict: Dict[str, Any]) -> GocdTask:
        """Parse a single GoCD task."""
        if "exec" in task_dict:
            return self._parse_exec_task(task_dict["exec"] or {}, task_dict)
        elif "fetch" in task_dict:
            return self._parse_fetch_task(task_dict["fetch"] or {}, task_dict)
        else:
            # Unknown task type
            return GocdTask(type="unknown", raw=task_dict)

    def _parse_exec_task(self, spec: Dict[str, Any], raw: Dict) -> GocdTask:
        """Parse a GoCD exec task."""
        # Handle both 'working_directory' and 'working-directory'
        working_dir = (
            spec.get("working_directory")
            or spec.get("working-directory")
            or ""
        )

        arguments = spec.get("arguments", []) or []
        # Ensure arguments are strings
        arguments = [str(a) for a in arguments]

        return GocdTask(
            type="exec",
            command=str(spec.get("command", "bash") or "bash"),
            arguments=arguments,
            working_directory=str(working_dir),
            run_if=str(spec.get("run_if", "") or ""),
            raw=raw,
        )

    def _parse_fetch_task(self, spec: Dict[str, Any], raw: Dict) -> GocdTask:
        """Parse a GoCD fetch artifact task."""
        return GocdTask(
            type="fetch",
            fetch_stage=str(spec.get("stage", "") or ""),
            fetch_job=str(spec.get("job", "") or ""),
            fetch_source=str(spec.get("source", "") or ""),
            fetch_destination=str(spec.get("destination", "") or ""),
            fetch_pipeline=str(spec.get("pipeline", "") or ""),
            is_file=bool(spec.get("is_file", False)),
            run_if=str(spec.get("run_if", "") or ""),
            raw=raw,
        )
