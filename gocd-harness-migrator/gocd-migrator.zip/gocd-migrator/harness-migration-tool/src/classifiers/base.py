"""
Abstract base class for pipeline pattern classifiers.

Each source type has a classifier that detects which conversion pattern
a pipeline belongs to (e.g., Terraform Infrastructure, K8s Deploy, etc.)
"""

from abc import ABC, abstractmethod
from typing import List

from src.core.models import PatternMatch


class BaseClassifier(ABC):
    """Base class for pipeline pattern classifiers."""

    @abstractmethod
    def classify(self, pipeline: object) -> PatternMatch:
        """
        Classify a pipeline into a known pattern.

        Returns a PatternMatch with the pattern ID, confidence score,
        and the signals that triggered the match.
        """
        ...

    @abstractmethod
    def list_patterns(self) -> List[dict]:
        """Return metadata about all known patterns."""
        ...
