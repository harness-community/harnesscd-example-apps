"""
GoCD Pipeline Pattern Classifier.

Classifies GoCD pipelines into one of 22 known patterns based on signals
from stage names, script content, materials, pipeline names, and parameters.

Each pattern has a set of weighted signals. The classifier scores all patterns
and returns the best match with a confidence score (0-100).
"""

from typing import List, Dict, Callable

from src.classifiers.base import BaseClassifier
from src.core.models import GocdPipeline, PatternMatch


# ---------------------------------------------------------------------------
# Pattern Definitions
# ---------------------------------------------------------------------------

PATTERNS: Dict[str, Dict] = {
    "terraform_infra": {
        "name": "Terraform Infrastructure (Plan/Apply)",
        "description": "Terraform plan and apply stages for infrastructure provisioning",
        "converter_key": "terraform_infra",
    },
    "terraform_infra_db": {
        "name": "Terraform Infrastructure + DB Migration",
        "description": "Terraform infra with an additional database migration stage",
        "converter_key": "terraform_infra",
    },
    "k8s_deploy_autogen": {
        "name": "Docker Build + K8s Deploy (Autogen)",
        "description": "Preprocess/build image, then K8s plan/apply via deploy scripts",
        "converter_key": "k8s_deploy",
    },
    "k8s_deploy_standalone": {
        "name": "Docker Build + K8s Deploy (Standalone)",
        "description": "Separate build and kube-deploy stages",
        "converter_key": "k8s_deploy",
    },
    "terraform_deploy_docker": {
        "name": "Docker Build + Terraform Deploy",
        "description": "Docker build followed by Terraform plan/apply for deployment",
        "converter_key": "terraform_deploy",
    },
    "ld_terraform": {
        "name": "LaunchDarkly Terraform Deploy",
        "description": "LaunchDarkly feature flag management via Terraform",
        "converter_key": "terraform_infra",
    },
    "ld_config_upload": {
        "name": "LaunchDarkly Config Upload (Generate/Dryrun/Upload)",
        "description": "Generate LD config, dry-run, then upload",
        "converter_key": "ld_upload",
    },
    "ld_single_update": {
        "name": "LaunchDarkly/MLP Single-Stage Update",
        "description": "Single-stage LD or MLP update",
        "converter_key": "ld_upload",
    },
    "data_pipeline": {
        "name": "Data Pipeline Build + Deploy",
        "description": "Offline data pipeline deployment (S3, Airflow, StepFunctions)",
        "converter_key": "data_pipeline",
    },
    "perf_test": {
        "name": "Performance/Load Test",
        "description": "Load testing pipeline with scale-up/down and test execution",
        "converter_key": "perf_test",
    },
    "db_migration": {
        "name": "Database Migration (Flyway)",
        "description": "Flyway-based database create/migrate/repair",
        "converter_key": "db_migration",
    },
    "s3_bucket": {
        "name": "S3 Bucket Provisioning",
        "description": "S3 bucket creation via Terraform",
        "converter_key": "terraform_infra",
    },
    "ddb_scale": {
        "name": "DynamoDB/Infrastructure Scale",
        "description": "Auto-scaling operations for DynamoDB or other infra",
        "converter_key": "ops_script",
    },
    "country_onboarding": {
        "name": "Country Onboarding Ops",
        "description": "UMS/SEA country onboarding and config operations",
        "converter_key": "ops_script",
    },
    "s3_data_copy": {
        "name": "S3 Data Copy/Sync",
        "description": "Copy data between S3 buckets or environments",
        "converter_key": "ops_script",
    },
    "cms_copy": {
        "name": "CMS Copy/Scheduled Sync",
        "description": "Scheduled CMS table/data synchronization",
        "converter_key": "ops_script",
    },
    "sonar_quality": {
        "name": "Code Quality (Sonar)",
        "description": "Sonar code quality checks",
        "converter_key": "ops_script",
    },
    "incident_report": {
        "name": "Incident Report Generation",
        "description": "Automated incident report generation",
        "converter_key": "ops_script",
    },
    "ml_pipeline": {
        "name": "ML Pipeline Setup",
        "description": "Machine learning pipeline infrastructure setup",
        "converter_key": "ops_script",
    },
    "telegraf_monitoring": {
        "name": "Telegraf/Monitoring Management",
        "description": "Telegraf agent deployment and monitoring setup",
        "converter_key": "ops_script",
    },
    "trigger_pipeline": {
        "name": "Trigger/Start Build Pipeline",
        "description": "Pipeline that triggers downstream builds",
        "converter_key": "ops_script",
    },
    "flink_infra": {
        "name": "Flink/Streaming Infrastructure",
        "description": "Flink streaming infrastructure provisioning",
        "converter_key": "ops_script",
    },
    "generic": {
        "name": "Generic Pipeline",
        "description": "Unclassified pipeline -- uses generic converter or LLM fallback",
        "converter_key": "generic",
    },
}


class GocdClassifier(BaseClassifier):
    """Classifies GoCD pipelines into known patterns."""

    def classify(self, pipeline: GocdPipeline) -> PatternMatch:
        """Score all patterns and return the best match."""
        scores: List[PatternMatch] = []

        # Gather signals once
        ctx = self._build_context(pipeline)

        # Score each pattern
        for pattern_id, pattern_meta in PATTERNS.items():
            if pattern_id == "generic":
                continue  # Generic is the fallback
            score, signals = self._score_pattern(pattern_id, ctx)
            if score > 0:
                scores.append(PatternMatch(
                    pattern_id=pattern_id,
                    pattern_name=pattern_meta["name"],
                    confidence=min(score, 100.0),
                    signals=signals,
                    converter_key=pattern_meta["converter_key"],
                ))

        # Sort by confidence descending
        scores.sort(key=lambda m: m.confidence, reverse=True)

        if scores and scores[0].confidence >= 20:
            return scores[0]

        # Fallback to generic
        return PatternMatch(
            pattern_id="generic",
            pattern_name="Generic Pipeline",
            confidence=10.0,
            signals=["No pattern matched with sufficient confidence"],
            converter_key="generic",
        )

    def list_patterns(self) -> List[dict]:
        """Return metadata about all known patterns."""
        return [
            {"id": pid, **meta}
            for pid, meta in PATTERNS.items()
        ]

    # ------------------------------------------------------------------
    # Context Builder
    # ------------------------------------------------------------------

    def _build_context(self, p: GocdPipeline) -> Dict:
        """Pre-compute all the signals we'll need for classification."""
        all_scripts = p.all_scripts.lower()
        stage_names = [s.lower() for s in p.stage_names]
        pipeline_name = p.name.lower()
        material_urls = [m.url.lower() for m in p.git_materials]
        material_names = [m.name.lower() for m in p.materials]
        has_pipeline_deps = len(p.pipeline_materials) > 0

        # Collect all elastic profile IDs
        elastic_profiles = set()
        for stage in p.stages:
            for job in stage.jobs:
                if job.elastic_profile_id:
                    elastic_profiles.add(job.elastic_profile_id.lower())

        # Check for fetch tasks
        has_fetch = any(t.type == "fetch" for t in p.all_tasks)

        # Collect artifact sources
        artifact_sources = []
        for stage in p.stages:
            for job in stage.jobs:
                for art in job.artifacts:
                    artifact_sources.append(art.source.lower())

        return {
            "pipeline_name": pipeline_name,
            "group": p.group.lower() if p.group else "",
            "stage_names": stage_names,
            "stage_count": len(p.stages),
            "all_scripts": all_scripts,
            "material_urls": material_urls,
            "material_names": material_names,
            "has_pipeline_deps": has_pipeline_deps,
            "pipeline_deps": [m.pipeline.lower() for m in p.pipeline_materials],
            "has_timer": p.timer is not None,
            "has_fetch": has_fetch,
            "elastic_profiles": elastic_profiles,
            "parameters": {k.lower(): str(v).lower() for k, v in p.parameters.items()},
            "env_vars": {k.lower(): str(v).lower() for k, v in p.environment_variables.items()},
            "artifact_sources": artifact_sources,
        }

    # ------------------------------------------------------------------
    # Pattern Scoring
    # ------------------------------------------------------------------

    def _score_pattern(self, pattern_id: str, ctx: Dict) -> tuple:
        """Score a specific pattern. Returns (score, signals)."""
        scorer = getattr(self, f"_score_{pattern_id}", None)
        if scorer:
            return scorer(ctx)
        return 0, []

    # --- Terraform Infrastructure ---
    def _score_terraform_infra(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        sn = ctx["stage_names"]
        scripts = ctx["all_scripts"]

        if "plan" in sn and "apply" in sn and "preprocess" not in sn:
            score += 40
            signals.append("stages: plan + apply (no preprocess)")
        if "terraform" in scripts:
            score += 30
            signals.append("scripts contain 'terraform'")
        if "apply_terraform" in scripts:
            score += 15
            signals.append("scripts contain 'apply_terraform'")
        if any("persona-reco-deploy" in u for u in ctx["material_urls"]):
            score += 10
            signals.append("material: persona-reco-deploy")
        if "plan.txt" in ctx["artifact_sources"]:
            score += 10
            signals.append("artifact: plan.txt")
        # Negative: if it's K8s deploy, reduce score
        if "apply_kubernetes" in scripts:
            score -= 30
            signals.append("penalty: apply_kubernetes detected (likely K8s)")
        return score, signals

    # --- Terraform Infra + DB Migration ---
    def _score_terraform_infra_db(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        sn = ctx["stage_names"]
        scripts = ctx["all_scripts"]

        if "plan" in sn and "apply" in sn and "migrate" in sn:
            score += 50
            signals.append("stages: plan + apply + migrate")
        if "terraform" in scripts and "flyway" in scripts:
            score += 30
            signals.append("scripts: terraform + flyway")
        if "rds" in ctx["pipeline_name"]:
            score += 10
            signals.append("pipeline name contains 'rds'")
        return score, signals

    # --- Docker Build + K8s Deploy (Autogen) ---
    def _score_k8s_deploy_autogen(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        sn = ctx["stage_names"]
        scripts = ctx["all_scripts"]

        if "preprocess" in sn and "plan" in sn and "apply" in sn:
            score += 45
            signals.append("stages: preprocess + plan + apply")
        elif "preprocess" in sn:
            score += 25
            signals.append("stage: preprocess present")
        if "apply_kubernetes" in scripts:
            score += 30
            signals.append("scripts contain 'apply_kubernetes'")
        if "build.sh" in scripts:
            score += 10
            signals.append("scripts contain 'build.sh'")
        if "image.txt" in ctx["artifact_sources"]:
            score += 10
            signals.append("artifact: image.txt")
        if "autogen" in ctx["pipeline_name"]:
            score += 10
            signals.append("pipeline name contains 'autogen'")
        return score, signals

    # --- Docker Build + K8s Deploy (Standalone) ---
    def _score_k8s_deploy_standalone(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        sn = ctx["stage_names"]
        scripts = ctx["all_scripts"]

        if "build" in sn and "kube-deploy" in sn:
            score += 50
            signals.append("stages: build + kube-deploy")
        elif "kube-deploy" in sn:
            score += 35
            signals.append("stage: kube-deploy")
        if "kube_deploy" in scripts:
            score += 25
            signals.append("scripts contain 'kube_deploy'")
        if "kube_delete" in scripts:
            score += 10
            signals.append("scripts contain 'kube_delete'")
        if "image_ref" in ctx["artifact_sources"]:
            score += 10
            signals.append("artifact: image_ref")
        return score, signals

    # --- Docker Build + Terraform Deploy ---
    def _score_terraform_deploy_docker(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        sn = ctx["stage_names"]
        scripts = ctx["all_scripts"]

        if "code-build" in sn and ("terraform-plan" in sn or "terraform-apply" in sn):
            score += 55
            signals.append("stages: code-build + terraform-plan/apply")
        if "docker build" in scripts and "terraform" in scripts:
            score += 25
            signals.append("scripts: docker build + terraform")
        if any("persona-terraform-playbooks" in u for u in ctx["material_urls"]):
            score += 15
            signals.append("material: persona-terraform-playbooks")
        return score, signals

    # --- LaunchDarkly Terraform ---
    def _score_ld_terraform(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        sn = ctx["stage_names"]
        scripts = ctx["all_scripts"]

        if "terraform-plan" in sn and "terraform-deploy" in sn:
            score += 35
            signals.append("stages: terraform-plan + terraform-deploy")
        if any("launch-darkly" in u or "persona-launch-darkly" in u for u in ctx["material_urls"]):
            score += 40
            signals.append("material: launch-darkly repo")
        if "launch-darkly" in ctx["pipeline_name"] or "launch_darkly" in ctx["pipeline_name"]:
            score += 15
            signals.append("pipeline name: launch-darkly")
        return score, signals

    # --- LaunchDarkly Config Upload ---
    def _score_ld_config_upload(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        sn = ctx["stage_names"]
        scripts = ctx["all_scripts"]

        if "generate" in sn and "upload" in sn:
            score += 45
            signals.append("stages: generate + upload")
        if "dryrun" in sn:
            score += 15
            signals.append("stage: dryrun")
        if "ld-upload" in ctx["pipeline_name"]:
            score += 20
            signals.append("pipeline name: ld-upload")
        if "--stage generate" in scripts or "--stage upload" in scripts:
            score += 15
            signals.append("scripts: --stage generate/upload flags")
        if "result.zip" in ctx["artifact_sources"]:
            score += 10
            signals.append("artifact: result.zip")
        return score, signals

    # --- LaunchDarkly / MLP Single Update ---
    def _score_ld_single_update(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        sn = ctx["stage_names"]
        scripts = ctx["all_scripts"]

        if sn == ["update"] or (len(sn) == 1 and "update" in sn[0]):
            score += 30
            signals.append("single stage: update")
        if "mlp" in ctx["pipeline_name"] or "ld-upload" in ctx["pipeline_name"]:
            score += 25
            signals.append("pipeline name: mlp or ld-upload")
        if "python3 -m mlp.main" in scripts:
            score += 30
            signals.append("scripts: python3 -m mlp.main")
        return score, signals

    # --- Data Pipeline ---
    def _score_data_pipeline(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        scripts = ctx["all_scripts"]

        if "offline" in ctx["pipeline_name"]:
            score += 30
            signals.append("pipeline name contains 'offline'")
        if "deploy" in ctx["stage_names"] and ctx["stage_count"] <= 2:
            score += 15
            signals.append("simple deploy stage(s)")
        if any("persona-reco-core" in u for u in ctx["material_urls"]):
            score += 10
            signals.append("material: persona-reco-core")
        if "airflow" in scripts or "stepfunction" in scripts:
            score += 25
            signals.append("scripts: airflow or stepfunction")
        if ctx["has_pipeline_deps"] and any("cornerstone" in d for d in ctx["pipeline_deps"]):
            score += 10
            signals.append("depends on cornerstone pipeline")
        return score, signals

    # --- Perf Test ---
    def _score_perf_test(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        sn = ctx["stage_names"]
        scripts = ctx["all_scripts"]

        if "scale-up" in sn or "scale-down" in sn or "perf-test" in sn:
            score += 45
            signals.append("stages: scale-up/scale-down/perf-test")
        if "loadtest" in ctx["pipeline_name"] or "perf" in ctx["pipeline_name"]:
            score += 30
            signals.append("pipeline name: loadtest or perf")
        if "locust" in scripts or "gatling" in scripts:
            score += 20
            signals.append("scripts: locust or gatling")
        return score, signals

    # --- DB Migration ---
    def _score_db_migration(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        sn = ctx["stage_names"]
        scripts = ctx["all_scripts"]

        if "migrate" in sn or "repair" in sn:
            score += 30
            signals.append("stages: migrate or repair")
        if "flyway" in scripts:
            score += 40
            signals.append("scripts: flyway")
        if "database" in ctx["pipeline_name"]:
            score += 20
            signals.append("pipeline name: database")
        # Negative: don't match terraform+migrate combos (that's terraform_infra_db)
        if "plan" in sn and "apply" in sn:
            score -= 20
            signals.append("penalty: plan+apply present (likely terraform)")
        return score, signals

    # --- S3 Bucket ---
    def _score_s3_bucket(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        scripts = ctx["all_scripts"]

        if "s3bucket" in ctx["pipeline_name"]:
            score += 50
            signals.append("pipeline name: s3bucket")
        if "s3bucket.sh" in scripts:
            score += 30
            signals.append("scripts: s3bucket.sh")
        if "s3bucket.env" in ctx["artifact_sources"]:
            score += 15
            signals.append("artifact: s3bucket.env")
        return score, signals

    # --- DDB Scale ---
    def _score_ddb_scale(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        scripts = ctx["all_scripts"]

        if "ddb" in ctx["pipeline_name"] or "scaleup" in ctx["pipeline_name"]:
            score += 30
            signals.append("pipeline name: ddb or scaleup")
        if "auto_scale.py" in scripts:
            score += 45
            signals.append("scripts: auto_scale.py")
        if "scale-up" in ctx["stage_names"] and ctx["stage_count"] == 1:
            score += 15
            signals.append("single scale-up stage")
        return score, signals

    # --- Country Onboarding ---
    def _score_country_onboarding(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        scripts = ctx["all_scripts"]

        if "sea-ums" in ctx["pipeline_name"] or "country-onboarding" in ctx["pipeline_name"]:
            score += 45
            signals.append("pipeline name: sea-ums or country-onboarding")
        if any("country-onboarding-ops" in u for u in ctx["material_urls"]):
            score += 30
            signals.append("material: country-onboarding-ops")
        if "add_new_country_config" in scripts:
            score += 25
            signals.append("scripts: add_new_country_config")
        return score, signals

    # --- S3 Data Copy ---
    def _score_s3_data_copy(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        scripts = ctx["all_scripts"]

        if "copy" in ctx["pipeline_name"] and ("data" in ctx["pipeline_name"] or "prod" in ctx["pipeline_name"]):
            score += 35
            signals.append("pipeline name: copy + data/prod")
        if "aws s3 cp" in scripts or "copy_tf_serving" in scripts:
            score += 35
            signals.append("scripts: aws s3 cp or copy_tf_serving")
        if "copy-prod-data" in ctx["pipeline_name"]:
            score += 25
            signals.append("pipeline name: copy-prod-data")
        return score, signals

    # --- CMS Copy ---
    def _score_cms_copy(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        scripts = ctx["all_scripts"]

        if "copy-cms" in ctx["pipeline_name"] or "cms-meta" in ctx["pipeline_name"]:
            score += 40
            signals.append("pipeline name: copy-cms or cms-meta")
        if "copy_cms" in scripts or "copy_all_cms" in scripts:
            score += 35
            signals.append("scripts: copy_cms or copy_all_cms")
        if ctx["has_timer"]:
            score += 10
            signals.append("has timer (scheduled)")
        return score, signals

    # --- Sonar ---
    def _score_sonar_quality(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        scripts = ctx["all_scripts"]

        if "sonar" in ctx["pipeline_name"]:
            score += 45
            signals.append("pipeline name: sonar")
        if "sonar.sh" in scripts or "sonarqube" in scripts:
            score += 40
            signals.append("scripts: sonar")
        if "checks" in ctx["stage_names"]:
            score += 15
            signals.append("stage: checks")
        return score, signals

    # --- Incident Report ---
    def _score_incident_report(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        scripts = ctx["all_scripts"]

        if "incidents-report" in ctx["pipeline_name"]:
            score += 50
            signals.append("pipeline name: incidents-report")
        if "incidents_analytics" in scripts:
            score += 35
            signals.append("scripts: incidents_analytics")
        if "generate_report" in ctx["stage_names"]:
            score += 15
            signals.append("stage: generate_report")
        return score, signals

    # --- ML Pipeline ---
    def _score_ml_pipeline(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        scripts = ctx["all_scripts"]

        if "churn" in ctx["pipeline_name"] or "prediction" in ctx["pipeline_name"]:
            score += 35
            signals.append("pipeline name: churn or prediction")
        if "setup_churn_pred" in scripts:
            score += 40
            signals.append("scripts: setup_churn_pred")
        if "is_destroy" in ctx["parameters"]:
            score += 15
            signals.append("parameter: is_destroy")
        return score, signals

    # --- Telegraf ---
    def _score_telegraf_monitoring(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        scripts = ctx["all_scripts"]

        if "telegraf" in ctx["pipeline_name"]:
            score += 50
            signals.append("pipeline name: telegraf")
        if "manage.sh" in scripts and "telegraf" in scripts:
            score += 30
            signals.append("scripts: manage.sh + telegraf")
        return score, signals

    # --- Trigger Pipeline ---
    def _score_trigger_pipeline(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        sn = ctx["stage_names"]

        if sn == ["start-build"] or (len(sn) == 1 and "start-build" in sn[0]):
            score += 45
            signals.append("single stage: start-build")
        if "TERRAFORM_BRANCH" in [a.upper() for a in ctx["artifact_sources"]]:
            score += 20
            signals.append("artifact: TERRAFORM_BRANCH")
        return score, signals

    # --- Flink ---
    def _score_flink_infra(self, ctx: Dict) -> tuple:
        score, signals = 0, []
        scripts = ctx["all_scripts"]

        if "flink" in ctx["pipeline_name"]:
            score += 45
            signals.append("pipeline name: flink")
        if "flink" in ctx["group"]:
            score += 25
            signals.append("group: flink")
        if "flink" in scripts:
            score += 20
            signals.append("scripts: flink")
        return score, signals
