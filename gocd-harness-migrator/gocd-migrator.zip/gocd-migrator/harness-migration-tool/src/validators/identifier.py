"""
Identifier sanitization and GoCD variable syntax conversion.

Handles:
- Converting names to valid Harness identifiers (alphanumeric + underscore)
- Converting GoCD #{variable} syntax to Harness <+pipeline.variables.variable>
- Converting ${ENV_VAR} references appropriately
"""

import re
from typing import Optional


def sanitize_identifier(name: str, fallback: str = "item") -> str:
    """
    Convert a name to a valid Harness identifier.

    Rules (matches Harness UI auto-generation):
    - Hyphens are stripped (not replaced with underscores)
    - Spaces become underscores
    - Other non-alphanumeric chars are removed
    - Cannot start with a digit or underscore
    - Max 128 characters
    """
    if not name:
        return fallback

    # Strip hyphens (Harness concatenates, not replaces)
    identifier = name.replace('-', '')

    # Spaces become underscores
    identifier = identifier.replace(' ', '_')

    # Remove remaining non-alphanumeric (except underscores)
    identifier = re.sub(r'[^a-zA-Z0-9_]', '', identifier)

    # Remove leading digits
    identifier = re.sub(r'^[0-9]+', '', identifier)

    # Remove leading underscores
    identifier = identifier.lstrip('_')

    # Collapse multiple underscores
    identifier = re.sub(r'_+', '_', identifier)

    # Strip trailing underscores
    identifier = identifier.rstrip('_')

    # Truncate to 128 chars
    identifier = identifier[:128]

    return identifier or fallback


def convert_gocd_variables(value: str) -> str:
    """
    Convert GoCD #{variable} syntax to Harness <+pipeline.variables.variable>.

    Examples:
        #{region_short}  -->  <+pipeline.variables.region_short>
        #{env}-#{region} -->  <+pipeline.variables.env>-<+pipeline.variables.region>
    """
    if not isinstance(value, str):
        return str(value) if value is not None else ""

    pattern = r'#\{([^}]+)\}'

    def _replace(match: re.Match) -> str:
        var_name = match.group(1)
        return f"<+pipeline.variables.{var_name}>"

    return re.sub(pattern, _replace, value)


def convert_gocd_env_vars(value: str) -> str:
    """
    Convert GoCD environment variable references.

    In GoCD, ${VAR_NAME} in exec tasks references pipeline-level env vars.
    In Harness ShellScript steps, these are available directly as $VAR_NAME
    or via <+pipeline.variables.VAR_NAME> for pipeline variables.

    We convert #{param} but leave ${VAR} as-is (they work in shell scripts).
    """
    return convert_gocd_variables(value)


def extract_repo_name(git_url: str) -> Optional[str]:
    """
    Extract the repository name from a git URL.

    Examples:
        git@github.com:hotstar/persona-reco-service.git  -->  hotstar/persona-reco-service
        https://github.com/org/repo.git                  -->  org/repo
    """
    # SSH format
    match = re.search(r'github\.com[:/](.+?)(?:\.git)?$', git_url)
    if match:
        return match.group(1)

    # HTTPS format
    match = re.search(r'github\.com/(.+?)(?:\.git)?$', git_url)
    if match:
        return match.group(1)

    return None


def build_pipeline_tags(group: str, source_repo: str, pattern_name: str, converter_key: str) -> dict:
    """
    Build the standard tag set for a converted pipeline.

    Tags applied:
    - GoCD group name (traceability to original pipeline group)
    - source_repo: which GoCD repository the pipeline came from
    - pattern: detected pipeline pattern (e.g. terraform_infra, k8s_deploy)
    - converter: which converter processed it
    - Module tags: CI, CD, or Custom based on pipeline purpose
    """
    tags = {}
    if group:
        tags[group] = ""

    if source_repo:
        tags["source_repo"] = source_repo

    clean_pattern = pattern_name.replace(" ", "_").replace("/", "_")
    clean_pattern = re.sub(r'[^a-zA-Z0-9_]', '', clean_pattern)
    if clean_pattern:
        tags["pattern"] = clean_pattern

    if converter_key:
        tags["converter"] = converter_key

    cd_converters = {"k8s_deploy", "terraform_deploy", "db_migration", "terraform_infra"}
    cd_patterns = {"k8s_deploy_autogen", "k8s_deploy_standalone", "terraform_deploy_docker",
                   "db_migration", "terraform_infra"}
    ci_cd_patterns = {"k8s_deploy_autogen", "k8s_deploy_standalone", "terraform_deploy_docker"}

    pattern_lower = pattern_name.lower().replace(" ", "_")

    if converter_key in cd_converters or pattern_lower in cd_patterns:
        tags["CD"] = ""
    else:
        tags["Custom"] = ""

    if pattern_lower in ci_cd_patterns or "docker_build" in pattern_lower or "build" in pattern_lower:
        tags["CI"] = ""

    return tags


def pipeline_name_to_title(name: str) -> str:
    """Convert a pipeline/stage name to a human-readable title."""
    return name.replace('_', ' ').replace('-', ' ').title()


def sanitize_step_name(name: str, fallback: str = "Step") -> str:
    """
    Sanitize a step name to comply with Harness validation.

    Harness step name regex: ^[a-zA-Z_0-9-.][-0-9a-zA-Z_\\s.]{0,127}$
    Only allow: letters, digits, underscores, hyphens, dots, spaces.
    """
    if not name:
        return fallback

    name = re.sub(r'[^a-zA-Z0-9_\-.\s]', ' ', name)
    name = re.sub(r'\s+', ' ', name).strip()

    if name and not re.match(r'^[a-zA-Z_0-9\-.]', name):
        name = 'Step ' + name

    name = name[:128].strip()

    return name or fallback
