"""
Harness YAML Builder.

Provides reusable builder functions to construct valid Harness pipeline YAML.
All converters use this instead of building raw dicts directly.
This ensures structural consistency and makes schema changes easy.
"""

from typing import Dict, Any, List, Optional, Tuple

from config import config
from src.validators.identifier import (
    sanitize_identifier,
    sanitize_step_name,
    convert_gocd_variables,
    pipeline_name_to_title,
    extract_repo_name,
)
from src.core.models import (
    GocdPipeline, GocdStage, GocdJob, GocdTask,
    GocdApproval, GocdMaterial, GocdTimer,
)


class HarnessBuilder:
    """Builds Harness pipeline YAML structures."""

    def __init__(self):
        self._step_counter = 0
        self._pipeline_env_vars: Dict[str, str] = {}

    def _next_step_id(self, prefix: str = "step") -> str:
        self._step_counter += 1
        return f"{prefix}_{self._step_counter}"

    def reset_counter(self):
        self._step_counter = 0

    def set_pipeline_env_vars(self, env_vars: Dict[str, str]) -> None:
        """Store GoCD environment_variables so step builders can inject them.

        GoCD automatically exports environment_variables as OS env vars.
        Harness does not — they must be explicitly mapped into each step.
        """
        self._pipeline_env_vars = dict(env_vars) if env_vars else {}

    # ------------------------------------------------------------------
    # Pipeline Wrapper
    # ------------------------------------------------------------------

    def build_pipeline(
        self,
        name: str,
        group: str,
        stages: List[Dict[str, Any]],
        variables: Optional[List[Dict[str, Any]]] = None,
        codebase: Optional[Dict[str, Any]] = None,
        description: str = "",
    ) -> Dict[str, Any]:
        """Build the top-level pipeline structure."""
        tags = {}
        if group:
            tags[group] = ""

        pipeline = {
            "pipeline": {
                "name": name,
                "identifier": sanitize_identifier(name),
                "projectIdentifier": sanitize_identifier(group),
                "orgIdentifier": config.harness.org_identifier,
                "tags": tags,
            }
        }

        if description:
            pipeline["pipeline"]["description"] = description

        if codebase:
            pipeline["pipeline"]["properties"] = codebase

        if variables:
            pipeline["pipeline"]["variables"] = variables

        if stages:
            pipeline["pipeline"]["stages"] = stages

        return pipeline

    # ------------------------------------------------------------------
    # Variables
    # ------------------------------------------------------------------

    def build_variables_from_params(
        self, parameters: Dict[str, str]
    ) -> List[Dict[str, Any]]:
        """Convert GoCD parameters to Harness pipeline variables."""
        variables = []
        for name, value in parameters.items():
            variables.append({
                "name": name,
                "type": "String",
                "value": str(value) if value is not None else "",
                "description": f"Migrated from GoCD parameter: {name}",
            })
        return variables

    def build_variables_from_env(
        self, env_vars: Dict[str, str]
    ) -> List[Dict[str, Any]]:
        """Convert GoCD environment variables to Harness pipeline variables."""
        variables = []
        for name, value in env_vars.items():
            converted = convert_gocd_variables(str(value) if value is not None else "")
            variables.append({
                "name": name,
                "type": "String",
                "value": converted,
                "description": f"Migrated from GoCD environment variable: {name}",
            })
        return variables

    def build_all_variables(self, pipeline: GocdPipeline) -> List[Dict[str, Any]]:
        """Build the combined variable list from parameters + env vars.

        Also stores environment_variables so step builders can inject them
        as OS-level env vars (GoCD does this automatically, Harness does not).
        """
        variables = []
        if pipeline.parameters:
            variables.extend(self.build_variables_from_params(pipeline.parameters))
        if pipeline.environment_variables:
            variables.extend(self.build_variables_from_env(pipeline.environment_variables))
        self.set_pipeline_env_vars(pipeline.environment_variables)
        return variables

    # ------------------------------------------------------------------
    # Codebase (CI properties)
    # ------------------------------------------------------------------

    def build_codebase(self, material: GocdMaterial) -> Optional[Dict[str, Any]]:
        """Build the properties.ci.codebase section from a git material."""
        repo_name = extract_repo_name(material.url)
        if not repo_name:
            return None

        branch = convert_gocd_variables(material.branch)

        return {
            "ci": {
                "codebase": {
                    "connectorRef": config.harness.default_connector_ref,
                    "repoName": repo_name,
                    "build": {
                        "type": "branch",
                        "spec": {"branch": branch},
                    },
                }
            }
        }

    # ------------------------------------------------------------------
    # Stages
    # ------------------------------------------------------------------

    def build_custom_stage(
        self,
        name: str,
        steps: List[Dict[str, Any]],
        description: str = "",
        delegate_selectors: Optional[List[str]] = None,
        failure_strategy: bool = True,
        when_condition: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Build a Custom stage."""
        stage = {
            "stage": {
                "name": pipeline_name_to_title(name),
                "identifier": sanitize_identifier(name),
                "description": description or f"Migrated from GoCD stage: {name}",
                "type": "Custom",
                "spec": {
                    "execution": {
                        "steps": steps,
                    }
                },
                "tags": {},
            }
        }

        if delegate_selectors:
            stage["stage"]["delegateSelectors"] = delegate_selectors

        if failure_strategy:
            stage["stage"]["failureStrategies"] = [
                {
                    "onFailure": {
                        "errors": ["AllErrors"],
                        "action": {"type": "StageRollback"},
                    }
                }
            ]
        else:
            stage["stage"]["failureStrategies"] = []

        if when_condition:
            stage["stage"]["when"] = {
                "pipelineStatus": when_condition,
            }

        return stage

    def build_ci_stage(
        self,
        name: str,
        steps: List[Dict[str, Any]],
        clone_codebase: bool = True,
        description: str = "",
        delegate_selectors: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Build a CI stage with Run steps and optional code cloning."""
        stage = {
            "stage": {
                "name": pipeline_name_to_title(name),
                "identifier": sanitize_identifier(name),
                "description": description or f"Migrated from GoCD stage: {name}",
                "type": "CI",
                "spec": {
                    "cloneCodebase": clone_codebase,
                    "infrastructure": {
                        "type": "KubernetesDirect",
                        "spec": {
                            "connectorRef": "account.k8s_build_connector",
                            "namespace": "harness-builds",
                            "automountServiceAccountToken": True,
                            "os": "Linux",
                        },
                    },
                    "execution": {
                        "steps": steps,
                    },
                },
            }
        }

        if delegate_selectors:
            stage["stage"]["delegateSelectors"] = delegate_selectors

        return stage

    def build_approval_stage(
        self,
        name: str,
        message: str,
        user_groups: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Build a standalone Approval stage."""
        return {
            "stage": {
                "name": pipeline_name_to_title(name),
                "identifier": sanitize_identifier(name),
                "type": "Approval",
                "spec": {
                    "execution": {
                        "steps": [
                            self.build_approval_step(
                                name=f"Approve {name}",
                                message=message,
                                user_groups=user_groups or ["account.Admin"],
                            )
                        ],
                    }
                },
                "tags": {},
            }
        }

    def build_deployment_stage(
        self,
        name: str,
        steps: List[Dict[str, Any]],
        deployment_type: str = "Kubernetes",
        service_ref: str = "<+input>",
        environment_ref: str = "<+input>",
        infra_identifier: str = "<+input>",
        rollback_steps: Optional[List[Dict[str, Any]]] = None,
        description: str = "",
        delegate_selectors: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Build a Deployment stage."""
        stage = {
            "stage": {
                "name": pipeline_name_to_title(name),
                "identifier": sanitize_identifier(name),
                "description": description or f"Migrated from GoCD stage: {name}",
                "type": "Deployment",
                "spec": {
                    "deploymentType": deployment_type,
                    "service": {
                        "serviceRef": service_ref,
                    },
                    "environment": {
                        "environmentRef": environment_ref,
                        "deployToAll": False,
                        "infrastructureDefinitions": [
                            {"identifier": infra_identifier}
                        ],
                    },
                    "execution": {
                        "steps": steps,
                        "rollbackSteps": rollback_steps or [],
                    },
                },
                "tags": {},
                "failureStrategies": [
                    {
                        "onFailure": {
                            "errors": ["AllErrors"],
                            "action": {"type": "StageRollback"},
                        }
                    }
                ],
            }
        }

        if delegate_selectors:
            stage["stage"]["delegateSelectors"] = delegate_selectors

        return stage

    # ------------------------------------------------------------------
    # Steps
    # ------------------------------------------------------------------

    def build_shell_step(
        self,
        name: str,
        script: str,
        identifier: Optional[str] = None,
        timeout: str = "",
        on_delegate: bool = True,
        env_vars: Optional[List[Dict]] = None,
        output_vars: Optional[List[Dict]] = None,
    ) -> Dict[str, Any]:
        """Build a ShellScript step."""
        step_id = identifier or self._next_step_id("shell")
        effective_env_vars = env_vars
        if not effective_env_vars and self._pipeline_env_vars:
            effective_env_vars = [
                {"name": k, "value": f"<+pipeline.variables.{k}>", "type": "String"}
                for k in self._pipeline_env_vars
            ]
        return {
            "step": {
                "type": "ShellScript",
                "name": name,
                "identifier": sanitize_identifier(step_id),
                "spec": {
                    "shell": "Bash",
                    "onDelegate": on_delegate,
                    "source": {
                        "type": "Inline",
                        "spec": {"script": script},
                    },
                    "environmentVariables": effective_env_vars or [],
                    "outputVariables": output_vars or [],
                },
                "timeout": timeout or config.harness.default_timeout,
            }
        }

    def build_run_step(
        self,
        name: str,
        command: str,
        identifier: Optional[str] = None,
        timeout: str = "",
        connector_ref: str = "account.haborBuilderConnector",
        image: str = "ubuntu:latest",
    ) -> Dict[str, Any]:
        """Build a Run step for CI stages."""
        step_id = identifier or self._next_step_id("run")
        step = {
            "step": {
                "type": "Run",
                "name": name,
                "identifier": sanitize_identifier(step_id),
                "spec": {
                    "connectorRef": connector_ref,
                    "image": image,
                    "shell": "Sh",
                    "command": command,
                },
            }
        }
        if self._pipeline_env_vars:
            step["step"]["spec"]["envVariables"] = {
                k: f"<+pipeline.variables.{k}>"
                for k in self._pipeline_env_vars
            }
        if timeout:
            step["step"]["timeout"] = timeout
        return step

    def build_approval_step(
        self,
        name: str = "Manual Approval",
        message: str = "Please review and approve",
        identifier: Optional[str] = None,
        user_groups: Optional[List[str]] = None,
        timeout: str = "",
    ) -> Dict[str, Any]:
        """Build a HarnessApproval step."""
        step_id = identifier or self._next_step_id("approval")
        return {
            "step": {
                "type": "HarnessApproval",
                "name": name,
                "identifier": sanitize_identifier(step_id),
                "spec": {
                    "approvalMessage": message,
                    "includePipelineExecutionHistory": True,
                    "isAutoRejectEnabled": False,
                    "approvers": {
                        "minimumCount": 1,
                        "disallowPipelineExecutor": False,
                        "userGroups": user_groups or ["account.Admin"],
                    },
                    "approverInputs": [],
                },
                "timeout": timeout or config.harness.approval_timeout,
            }
        }

    def build_terraform_plan_step(
        self,
        provisioner_id: str,
        command: str = "Apply",
        connector_ref: str = "",
        identifier: str = "terraform_plan",
    ) -> Dict[str, Any]:
        """Build a TerraformPlan step (Custom stage compatible)."""
        return {
            "step": {
                "type": "TerraformPlan",
                "name": f"Terraform Plan{' - Destroy' if command == 'Destroy' else ''}",
                "identifier": identifier,
                "spec": {
                    "provisionerIdentifier": provisioner_id,
                    "configuration": {
                        "command": command,
                        "configFiles": {
                            "store": {
                                "spec": {
                                    "connectorRef": connector_ref or config.harness.default_connector_ref,
                                    "repoName": "<+input>",
                                    "gitFetchType": "Branch",
                                    "branch": "<+input>",
                                    "folderPath": "<+input>",
                                },
                                "type": "Github",
                            }
                        },
                        "secretManagerRef": config.harness.secret_manager_ref,
                        "skipRefreshCommand": False,
                    },
                },
                "timeout": config.harness.default_timeout,
            }
        }

    def build_terraform_apply_step(
        self,
        provisioner_id: str,
        connector_ref: str = "",
        identifier: str = "terraform_apply",
    ) -> Dict[str, Any]:
        """Build a TerraformApply step (Inline configuration)."""
        return {
            "step": {
                "type": "TerraformApply",
                "name": "Terraform Apply",
                "identifier": identifier,
                "spec": {
                    "provisionerIdentifier": provisioner_id,
                    "configuration": {
                        "type": "Inline",
                        "spec": {
                            "configFiles": {
                                "store": {
                                    "spec": {
                                        "connectorRef": connector_ref or config.harness.default_connector_ref,
                                        "gitFetchType": "Branch",
                                        "branch": "<+input>",
                                        "folderPath": "<+input>",
                                    },
                                    "type": "Github",
                                }
                            }
                        },
                    },
                },
                "timeout": config.harness.default_timeout,
            }
        }

    def build_terraform_destroy_step(
        self,
        provisioner_id: str,
        connector_ref: str = "",
        identifier: str = "terraform_destroy",
    ) -> Dict[str, Any]:
        """Build a TerraformDestroy step (Inline configuration)."""
        return {
            "step": {
                "type": "TerraformDestroy",
                "name": "Terraform Destroy",
                "identifier": identifier,
                "spec": {
                    "provisionerIdentifier": provisioner_id,
                    "configuration": {
                        "type": "Inline",
                        "spec": {
                            "configFiles": {
                                "store": {
                                    "spec": {
                                        "connectorRef": connector_ref or config.harness.default_connector_ref,
                                        "folderPath": "<+input>",
                                        "gitFetchType": "Branch",
                                        "branch": "<+input>",
                                    },
                                    "type": "Github",
                                }
                            }
                        },
                    },
                },
                "timeout": config.harness.default_timeout,
            }
        }

    def build_terraform_rollback_step(
        self,
        provisioner_id: str,
    ) -> Dict[str, Any]:
        """Build a TerraformRollback step."""
        return {
            "step": {
                "type": "TerraformRollback",
                "name": "Terraform Rollback",
                "identifier": "terraform_rollback",
                "spec": {
                    "provisionerIdentifier": provisioner_id,
                },
                "timeout": config.harness.default_timeout,
            }
        }

    # ------------------------------------------------------------------
    # Task-to-Step Conversion Helpers
    # ------------------------------------------------------------------

    def task_to_shell_step(self, task: GocdTask, step_name: str = "") -> Dict[str, Any]:
        """Convert a GoCD exec task to a Harness ShellScript step."""
        script_lines = []

        if task.working_directory:
            wd = convert_gocd_variables(task.working_directory)
            script_lines.append(f"cd {wd}")

        if task.arguments:
            if task.command in ("bash", "sh") and len(task.arguments) >= 2 and task.arguments[0] == "-c":
                # bash -c "script" pattern
                script = task.arguments[1]
                script_lines.append(convert_gocd_variables(script))
            else:
                full_cmd = f"{task.command} {' '.join(task.arguments)}"
                script_lines.append(convert_gocd_variables(full_cmd))
        else:
            script_lines.append(convert_gocd_variables(task.command))

        raw_name = step_name or f"Execute {task.command}"
        name = sanitize_step_name(raw_name)
        return self.build_shell_step(
            name=name,
            script="\n".join(script_lines),
        )

    def fetch_task_to_comment_step(self, task: GocdTask) -> Dict[str, Any]:
        """Convert a GoCD fetch task to a placeholder ShellScript step with TODO."""
        pipeline_ref = convert_gocd_variables(task.fetch_pipeline) if task.fetch_pipeline else ""
        script = f"""# TODO: Implement artifact fetch
# Original GoCD fetch configuration:
#   Pipeline: {pipeline_ref or '(same pipeline)'}
#   Stage: {task.fetch_stage}
#   Job: {task.fetch_job}
#   Source: {task.fetch_source}
#   Destination: {task.fetch_destination}
#
# Harness options:
#   1. Use output variables from previous stage
#   2. Store/retrieve from S3 or Harness artifact management
#   3. Use 'Artifact Source' in service definition
echo "TODO: Implement artifact fetch for {task.fetch_source}"
"""
        raw_name = f"Fetch {task.fetch_source or 'artifact'}"
        return self.build_shell_step(
            name=sanitize_step_name(raw_name),
            script=script,
            timeout="5m",
        )

    def convert_stage_tasks_to_steps(
        self, stage: GocdStage
    ) -> List[Dict[str, Any]]:
        """Convert all tasks in a stage's jobs to Harness steps."""
        steps = []
        for job in stage.jobs:
            for task in job.tasks:
                if task.type == "exec":
                    steps.append(self.task_to_shell_step(task))
                elif task.type == "fetch":
                    steps.append(self.fetch_task_to_comment_step(task))
                else:
                    steps.append(self.build_shell_step(
                        name=sanitize_step_name(f"Unknown task {task.type}"),
                        script=f"# TODO: Manually convert this task\n# Raw: {task.raw}",
                    ))
        return steps

    def task_to_run_step(self, task: GocdTask, step_name: str = "") -> Dict[str, Any]:
        """Convert a GoCD exec task to a Harness Run step (for CI stages)."""
        script_lines = []

        if task.working_directory:
            wd = convert_gocd_variables(task.working_directory)
            script_lines.append(f"cd {wd}")

        if task.arguments:
            if task.command in ("bash", "sh") and len(task.arguments) >= 2 and task.arguments[0] == "-c":
                script = task.arguments[1]
                script_lines.append(convert_gocd_variables(script))
            else:
                full_cmd = f"{task.command} {' '.join(task.arguments)}"
                script_lines.append(convert_gocd_variables(full_cmd))
        else:
            script_lines.append(convert_gocd_variables(task.command))

        raw_name = step_name or f"Execute {task.command}"
        name = sanitize_step_name(raw_name)
        return self.build_run_step(
            name=name,
            command="\n".join(script_lines),
        )

    def convert_stage_tasks_to_run_steps(
        self, stage: GocdStage
    ) -> List[Dict[str, Any]]:
        """Convert all tasks in a stage's jobs to CI Run steps."""
        steps = []
        for job in stage.jobs:
            for task in job.tasks:
                if task.type == "exec":
                    steps.append(self.task_to_run_step(task))
                elif task.type == "fetch":
                    steps.append(self.build_run_step(
                        name=sanitize_step_name(f"Fetch {task.fetch_source or 'artifact'}"),
                        command=(
                            f"# TODO: Implement artifact fetch\n"
                            f"# Source: {task.fetch_pipeline or '(same pipeline)'} / "
                            f"{task.fetch_stage} / {task.fetch_job}\n"
                            f"# File: {task.fetch_source or 'artifact'}\n"
                            f'echo "TODO: Fetch artifact"'
                        ),
                    ))
                else:
                    steps.append(self.build_run_step(
                        name=sanitize_step_name(f"Unknown task {task.type}"),
                        command=f"# TODO: Manually convert task type '{task.type}'",
                    ))
        return steps

    # ------------------------------------------------------------------
    # Step conversion: ShellScript → Run (for CI stage migration)
    # ------------------------------------------------------------------

    def split_steps_for_ci(
        self, steps: List[Dict[str, Any]]
    ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """Split steps into (approval_steps, ci_run_steps).

        Approval steps cannot live inside CI stages and need their own
        Approval stage. ShellScript steps are converted to Run steps.
        """
        approvals: List[Dict[str, Any]] = []
        ci_steps: List[Dict[str, Any]] = []

        for step in steps:
            step_type = step.get("step", {}).get("type", "")
            if step_type == "HarnessApproval":
                approvals.append(step)
            elif step_type == "ShellScript":
                ci_steps.append(self._shell_step_to_run(step))
            else:
                ci_steps.append(step)

        return approvals, ci_steps

    @staticmethod
    def _shell_step_to_run(step: Dict[str, Any]) -> Dict[str, Any]:
        """Convert a single ShellScript step dict to a Run step dict."""
        inner = step["step"]
        script = inner.get("spec", {}).get("source", {}).get("spec", {}).get("script", "")
        run_step: Dict[str, Any] = {
            "step": {
                "type": "Run",
                "name": inner["name"],
                "identifier": inner["identifier"],
                "spec": {
                    "connectorRef": "account.haborBuilderConnector",
                    "image": "ubuntu:latest",
                    "shell": "Sh",
                    "command": script,
                },
            }
        }
        shell_env_vars = inner.get("spec", {}).get("environmentVariables", [])
        if shell_env_vars:
            run_step["step"]["spec"]["envVariables"] = {
                ev["name"]: ev["value"] for ev in shell_env_vars if "name" in ev
            }
        timeout = inner.get("timeout")
        if timeout:
            run_step["step"]["timeout"] = timeout
        return run_step

    # ------------------------------------------------------------------
    # Trigger (Timer/Cron)
    # ------------------------------------------------------------------

    def build_cron_trigger(
        self, timer: GocdTimer, pipeline_identifier: str
    ) -> Dict[str, Any]:
        """Build a Harness cron trigger from a GoCD timer."""
        return {
            "trigger": {
                "name": f"{pipeline_identifier}_scheduled",
                "identifier": f"{sanitize_identifier(pipeline_identifier)}_cron",
                "type": "Scheduled",
                "spec": {
                    "type": "Cron",
                    "spec": {
                        "expression": timer.spec,
                    },
                },
                "pipelineIdentifier": sanitize_identifier(pipeline_identifier),
            }
        }

    # ------------------------------------------------------------------
    # Delegate Selectors
    # ------------------------------------------------------------------

    def get_delegate_selectors(self, pipeline: GocdPipeline) -> List[str]:
        """Extract delegate selectors from elastic profile IDs."""
        selectors = set()
        for stage in pipeline.stages:
            for job in stage.jobs:
                if job.elastic_profile_id:
                    selector = convert_gocd_variables(job.elastic_profile_id)
                    selectors.add(selector)

        # Also check pipeline-level parameter
        ep = pipeline.parameters.get("elastic_profile") or pipeline.parameters.get("agentprefix")
        if ep:
            selectors.add(convert_gocd_variables(ep))

        return list(selectors)
