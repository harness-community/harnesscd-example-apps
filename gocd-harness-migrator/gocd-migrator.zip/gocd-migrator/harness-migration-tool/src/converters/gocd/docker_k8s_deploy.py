"""
Docker Build + K8s Deploy Converter.

Handles GoCD patterns:
  - k8s_deploy_autogen: preprocess/build -> plan -> apply via deploy.sh
  - k8s_deploy_standalone: build pipeline -> kube-deploy via kube_deploy

Generates Harness pipelines based on the GoCD pipeline's role:
  1. Build-only pipeline → CI pipeline with BuildAndPushECR, cloneCodebase
  2. Deploy pipeline → CD pipeline with K8sRollingDeploy, service ref
  3. Combined pipeline → CI stage + CD stage in one pipeline

Also generates a Harness Service YAML with Custom Remote Manifest
for pipelines that include K8s deployment.

These separate pipelines can be orchestrated via Harness Chained Pipelines.
"""

import re
from typing import List, Dict, Any, Optional, Tuple

from src.converters.base import BaseConverter
from src.core.models import (
    GocdPipeline, GocdStage, GocdJob, GocdTask, GocdMaterial,
    ConversionResult, ConversionMethod, Entity, EntityType,
)
from src.validators.identifier import (
    sanitize_identifier, convert_gocd_variables,
    extract_repo_name,
)
from config import config


class DockerK8sDeployConverter(BaseConverter):
    """Converts GoCD Docker Build + K8s Deploy pipelines to Harness CI/CD."""

    @property
    def converter_key(self) -> str:
        return "k8s_deploy"

    @property
    def supported_patterns(self) -> List[str]:
        return ["k8s_deploy_autogen", "k8s_deploy_standalone"]

    def convert(self, pipeline: GocdPipeline, pattern_id: str) -> ConversionResult:
        result = ConversionResult(
            source_file="",
            source_pipeline_name=pipeline.name,
            source_type="gocd",
            pattern=None,
            conversion_method=ConversionMethod.RULE_BASED,
        )

        pipeline_role = self._detect_pipeline_role(pipeline, pattern_id)
        ecr_info = self._extract_ecr_info(pipeline)
        env_info = self._extract_environment_info(pipeline)
        delegate_selectors = self._get_delegate_selectors(pipeline)
        approval_groups = self._get_approval_user_groups(pipeline)
        app_id = self._extract_app_id(pipeline, pattern_id)
        service_id = self._derive_service_id(pipeline)
        env_id = sanitize_identifier(env_info["env_name"]) or "default"
        infra_id = f"k8s_{env_id}"

        if pipeline_role == "build":
            harness_yaml = self._build_ci_pipeline(
                pipeline, ecr_info, delegate_selectors,
            )
        elif pipeline_role == "deploy":
            harness_yaml = self._build_cd_pipeline(
                pipeline, ecr_info, env_info, app_id,
                service_id, env_id, infra_id,
                delegate_selectors, approval_groups,
            )
            svc_yaml = self._build_service_yaml(pipeline, service_id, app_id)
            result.additional_yamls[f"{service_id}.SERVICE"] = svc_yaml
        else:
            harness_yaml = self._build_combined_pipeline(
                pipeline, pattern_id, ecr_info, env_info, app_id,
                service_id, env_id, infra_id,
                delegate_selectors, approval_groups,
            )
            svc_yaml = self._build_service_yaml(pipeline, service_id, app_id)
            result.additional_yamls[f"{service_id}.SERVICE"] = svc_yaml

        for mat in pipeline.pipeline_materials:
            dep = convert_gocd_variables(mat.pipeline)
            result.warnings.append(
                f"Depends on upstream pipeline '{dep}' (stage: {mat.stage}). "
                f"Create a Harness trigger or chained pipeline to connect."
            )
        if pipeline.timer:
            result.warnings.append(
                f"Pipeline has a cron schedule ({pipeline.timer.spec}). "
                f"Create a Harness cron trigger separately."
            )

        result.harness_yaml = harness_yaml
        result.entities = self._extract_entities(
            pipeline, pipeline_role, ecr_info, env_info,
            service_id, env_id, infra_id,
            approval_groups, delegate_selectors,
        )
        result.success = True
        return result

    # ------------------------------------------------------------------
    # Pipeline Role Detection
    # ------------------------------------------------------------------

    def _detect_pipeline_role(self, pipeline: GocdPipeline, pattern_id: str) -> str:
        """Determine if a pipeline is build-only, deploy-only, or combined."""
        scripts = pipeline.all_scripts.lower()
        stage_names = [s.name.lower() for s in pipeline.stages]

        has_build = any(k in scripts for k in ["docker build", "docker push", "build.sh"])
        has_build_stage = any(
            k in sn for sn in stage_names
            for k in ["build", "preprocess", "code-build", "code_build"]
        )
        has_ecr = "ecr" in scripts or "docker_registry" in str(pipeline.parameters).lower()

        has_deploy = any(k in scripts for k in ["kube_deploy", "kube_delete", "deploy.sh"])
        has_deploy_stage = any(
            k in sn for sn in stage_names
            for k in ["deploy", "kube-deploy", "kube_deploy", "plan", "apply"]
        )

        is_build = (has_build or has_build_stage or has_ecr)
        is_deploy = (has_deploy or has_deploy_stage)

        if is_build and is_deploy:
            return "combined"
        elif is_build and not is_deploy:
            return "build"
        elif is_deploy:
            return "deploy"

        return "combined"

    # ------------------------------------------------------------------
    # CI Pipeline (Build-only)
    # ------------------------------------------------------------------

    def _build_ci_pipeline(
        self, pipeline: GocdPipeline, ecr_info: Dict,
        delegate_selectors: List[str],
    ) -> Dict[str, Any]:
        variables = self._build_variables(pipeline)
        repo_info = self._extract_repo_info(pipeline)
        ecr_account = self._extract_ecr_account(ecr_info)
        ecr_image_name = ecr_info.get("image_path", pipeline.name)
        ecr_region = ecr_info.get("region", config.harness.default_aws_region)

        steps = []

        pre_build_script = self._extract_pre_build_script(pipeline)
        if pre_build_script:
            steps.append({
                "step": {
                    "type": "Run",
                    "name": "Pre-Build Setup",
                    "identifier": "PreBuildSetup",
                    "spec": {
                        "connectorRef": "account.haborBuilderConnector",
                        "image": "alpine/git:latest",
                        "shell": "Sh",
                        "command": pre_build_script,
                    },
                }
            })

        steps.append({
            "step": {
                "type": "BuildAndPushECR",
                "name": "Build and Push to ECR",
                "identifier": "BuildandPushtoECR",
                "spec": {
                    "connectorRef": "account.aws_connector",
                    "region": ecr_region,
                    "account": ecr_account,
                    "imageName": ecr_image_name,
                    "tags": ["<+pipeline.sequenceId>"],
                },
            }
        })

        codebase = None
        if pipeline.git_materials:
            mat = pipeline.git_materials[0]
            repo_name = extract_repo_name(mat.url) or ""
            codebase = {
                "ci": {
                    "codebase": {
                        "connectorRef": config.harness.github_connector_ref,
                        "repoName": repo_name,
                        "build": "<+input>",
                    }
                }
            }

        ci_stage = {
            "stage": {
                "name": "Build and Push",
                "identifier": "BuildandPush",
                "description": "Build Docker image and push to ECR",
                "type": "CI",
                "spec": {
                    "cloneCodebase": True,
                    "infrastructure": {
                        "type": "KubernetesDirect",
                        "spec": {
                            "connectorRef": "account.k8s_build_connector",
                            "namespace": "harness-builds",
                            "automountServiceAccountToken": True,
                            "os": "Linux",
                        },
                    },
                    "execution": {"steps": steps},
                },
            }
        }

        if delegate_selectors:
            ci_stage["stage"]["delegateSelectors"] = delegate_selectors

        tags = {pipeline.group: ""} if pipeline.group else {}
        harness_yaml = {
            "pipeline": {
                "name": pipeline.name,
                "identifier": sanitize_identifier(pipeline.name),
                "projectIdentifier": sanitize_identifier(pipeline.group),
                "orgIdentifier": config.harness.org_identifier,
                "tags": tags,
                "stages": [ci_stage],
            }
        }

        if codebase:
            harness_yaml["pipeline"]["properties"] = codebase

        if variables:
            harness_yaml["pipeline"]["variables"] = variables

        return harness_yaml

    # ------------------------------------------------------------------
    # CD Pipeline (Deploy-only)
    # ------------------------------------------------------------------

    def _build_cd_pipeline(
        self, pipeline: GocdPipeline, ecr_info: Dict,
        env_info: Dict, app_id: str,
        service_id: str, env_id: str, infra_id: str,
        delegate_selectors: List[str], approval_groups: List[str],
    ) -> Dict[str, Any]:
        variables = self._build_variables(pipeline)
        variables.append({
            "name": "image",
            "type": "String",
            "value": "<+input>",
            "description": "Full image URI passed from upstream build pipeline",
        })

        stages = []

        has_approval = any(
            s.approval and s.approval.type == "manual"
            for s in pipeline.stages
        )
        if has_approval:
            stages.append({
                "stage": {
                    "name": "Approval",
                    "identifier": "Approval",
                    "description": "Manual approval before deployment",
                    "type": "Approval",
                    "spec": {
                        "execution": {
                            "steps": [{
                                "step": {
                                    "type": "HarnessApproval",
                                    "name": "Approve Deployment",
                                    "identifier": "ApproveDeployment",
                                    "spec": {
                                        "approvalMessage": "Review and approve deployment for <+pipeline.name>",
                                        "includePipelineExecutionHistory": True,
                                        "isAutoRejectEnabled": False,
                                        "approvers": {
                                            "userGroups": approval_groups,
                                            "minimumCount": 1,
                                            "disallowPipelineExecutor": False,
                                        },
                                        "approverInputs": [],
                                    },
                                    "timeout": "1d",
                                }
                            }],
                        }
                    },
                    "tags": {},
                }
            })

        env_type_label = "Prod" if env_info.get("env_name", "").lower() == "prod" else "Nonprod"
        deploy_stage = {
            "stage": {
                "name": f"Deploy to {env_type_label}",
                "identifier": f"Deployto{env_type_label}",
                "description": f"K8s rolling deploy to {env_info.get('env_name', 'target')}",
                "type": "Deployment",
                "spec": {
                    "deploymentType": "Kubernetes",
                    "service": {
                        "serviceRef": service_id,
                        "serviceInputs": {
                            "serviceDefinition": {
                                "type": "Kubernetes",
                                "spec": {
                                    "variables": [
                                        {
                                            "name": "image",
                                            "type": "String",
                                            "default": "<+input>",
                                        },
                                        {
                                            "name": "app_id",
                                            "type": "String",
                                            "default": "<+input>",
                                        },
                                    ],
                                },
                            },
                        },
                    },
                    "environment": {
                        "environmentRef": env_id,
                        "deployToAll": False,
                        "infrastructureDefinitions": [
                            {"identifier": infra_id}
                        ],
                    },
                    "execution": {
                        "steps": [{
                            "step": {
                                "type": "K8sRollingDeploy",
                                "name": "Rolling Deploy",
                                "identifier": "RollingDeploy",
                                "spec": {
                                    "skipDryRun": False,
                                    "pruningEnabled": False,
                                },
                                "timeout": "10m",
                            }
                        }],
                        "rollbackSteps": [{
                            "step": {
                                "type": "K8sRollingRollback",
                                "name": "Rolling Rollback",
                                "identifier": "RollingRollback",
                                "spec": {"pruningEnabled": False},
                                "timeout": "10m",
                            }
                        }],
                    },
                },
                "tags": {},
                "failureStrategies": [{
                    "onFailure": {
                        "errors": ["AllErrors"],
                        "action": {"type": "StageRollback"},
                    }
                }],
            }
        }

        if delegate_selectors:
            deploy_stage["stage"]["delegateSelectors"] = delegate_selectors

        stages.append(deploy_stage)

        tags = {pipeline.group: ""} if pipeline.group else {}
        harness_yaml = {
            "pipeline": {
                "name": pipeline.name,
                "identifier": sanitize_identifier(pipeline.name),
                "projectIdentifier": sanitize_identifier(pipeline.group),
                "orgIdentifier": config.harness.org_identifier,
                "tags": tags,
                "variables": variables,
                "stages": stages,
            }
        }

        return harness_yaml

    # ------------------------------------------------------------------
    # Combined Pipeline (Build + Deploy)
    # ------------------------------------------------------------------

    def _build_combined_pipeline(
        self, pipeline: GocdPipeline, pattern_id: str,
        ecr_info: Dict, env_info: Dict, app_id: str,
        service_id: str, env_id: str, infra_id: str,
        delegate_selectors: List[str], approval_groups: List[str],
    ) -> Dict[str, Any]:
        """For pipelines that have both build and deploy in one GoCD pipeline."""
        variables = self._build_variables(pipeline)
        repo_info = self._extract_repo_info(pipeline)
        ecr_account = self._extract_ecr_account(ecr_info)
        ecr_image_name = ecr_info.get("image_path", pipeline.name)
        ecr_region = ecr_info.get("region", config.harness.default_aws_region)

        stages = []

        # CI Stage
        build_steps = []
        pre_build = self._extract_pre_build_script(pipeline)
        if pre_build:
            build_steps.append({
                "step": {
                    "type": "Run",
                    "name": "Pre-Build Setup",
                    "identifier": "PreBuildSetup",
                    "spec": {
                        "connectorRef": "account.haborBuilderConnector",
                        "image": "alpine/git:latest",
                        "shell": "Sh",
                        "command": pre_build,
                    },
                }
            })

        build_steps.append({
            "step": {
                "type": "BuildAndPushECR",
                "name": "Build and Push to ECR",
                "identifier": "BuildandPushtoECR",
                "spec": {
                    "connectorRef": "account.aws_connector",
                    "region": ecr_region,
                    "account": ecr_account,
                    "imageName": ecr_image_name,
                    "tags": ["<+pipeline.sequenceId>"],
                },
            }
        })

        ci_stage = {
            "stage": {
                "name": "Build and Push",
                "identifier": "BuildandPush",
                "type": "CI",
                "spec": {
                    "cloneCodebase": True,
                    "infrastructure": {
                        "type": "KubernetesDirect",
                        "spec": {
                            "connectorRef": "account.k8s_build_connector",
                            "namespace": "harness-builds",
                            "automountServiceAccountToken": True,
                            "os": "Linux",
                        },
                    },
                    "execution": {"steps": build_steps},
                },
            }
        }
        stages.append(ci_stage)

        # Approval stage (if any)
        has_approval = any(
            s.approval and s.approval.type == "manual"
            for s in pipeline.stages
        )
        if has_approval:
            stages.append({
                "stage": {
                    "name": "Approval",
                    "identifier": "Approval",
                    "type": "Approval",
                    "spec": {
                        "execution": {
                            "steps": [{
                                "step": {
                                    "type": "HarnessApproval",
                                    "name": "Approve Deployment",
                                    "identifier": "ApproveDeployment",
                                    "spec": {
                                        "approvalMessage": "Review and approve deployment for <+pipeline.name>",
                                        "includePipelineExecutionHistory": True,
                                        "isAutoRejectEnabled": False,
                                        "approvers": {
                                            "userGroups": approval_groups,
                                            "minimumCount": 1,
                                            "disallowPipelineExecutor": False,
                                        },
                                        "approverInputs": [],
                                    },
                                    "timeout": "1d",
                                }
                            }],
                        }
                    },
                    "tags": {},
                }
            })

        # CD Stage
        deploy_stage = {
            "stage": {
                "name": "Deploy",
                "identifier": "Deploy",
                "type": "Deployment",
                "spec": {
                    "deploymentType": "Kubernetes",
                    "service": {
                        "serviceRef": service_id,
                        "serviceInputs": {
                            "serviceDefinition": {
                                "type": "Kubernetes",
                                "spec": {
                                    "variables": [
                                        {
                                            "name": "image",
                                            "type": "String",
                                            "default": "<+input>",
                                        },
                                        {
                                            "name": "app_id",
                                            "type": "String",
                                            "default": "<+input>",
                                        },
                                    ],
                                },
                            },
                        },
                    },
                    "environment": {
                        "environmentRef": env_id,
                        "deployToAll": False,
                        "infrastructureDefinitions": [
                            {"identifier": infra_id}
                        ],
                    },
                    "execution": {
                        "steps": [{
                            "step": {
                                "type": "K8sRollingDeploy",
                                "name": "Rolling Deploy",
                                "identifier": "RollingDeploy",
                                "spec": {
                                    "skipDryRun": False,
                                    "pruningEnabled": False,
                                },
                                "timeout": "10m",
                            }
                        }],
                        "rollbackSteps": [{
                            "step": {
                                "type": "K8sRollingRollback",
                                "name": "Rolling Rollback",
                                "identifier": "RollingRollback",
                                "spec": {"pruningEnabled": False},
                                "timeout": "10m",
                            }
                        }],
                    },
                },
                "tags": {},
                "failureStrategies": [{
                    "onFailure": {
                        "errors": ["AllErrors"],
                        "action": {"type": "StageRollback"},
                    }
                }],
            }
        }

        if delegate_selectors:
            deploy_stage["stage"]["delegateSelectors"] = delegate_selectors

        stages.append(deploy_stage)

        # Codebase for CI
        codebase = None
        if pipeline.git_materials:
            mat = pipeline.git_materials[0]
            repo_name = extract_repo_name(mat.url) or ""
            codebase = {
                "ci": {
                    "codebase": {
                        "connectorRef": config.harness.github_connector_ref,
                        "repoName": repo_name,
                        "build": "<+input>",
                    }
                }
            }

        tags = {pipeline.group: ""} if pipeline.group else {}
        harness_yaml = {
            "pipeline": {
                "name": pipeline.name,
                "identifier": sanitize_identifier(pipeline.name),
                "projectIdentifier": sanitize_identifier(pipeline.group),
                "orgIdentifier": config.harness.org_identifier,
                "tags": tags,
                "variables": variables,
                "stages": stages,
            }
        }

        if codebase:
            harness_yaml["pipeline"]["properties"] = codebase
        if variables:
            harness_yaml["pipeline"]["variables"] = variables

        return harness_yaml

    # ------------------------------------------------------------------
    # Service YAML Generation
    # ------------------------------------------------------------------

    def _build_service_yaml(
        self, pipeline: GocdPipeline, service_id: str, app_id: str,
    ) -> Dict[str, Any]:
        """Generate a Harness Service YAML with Custom Remote Manifest."""
        return {
            "service": {
                "name": service_id,
                "identifier": service_id,
                "orgIdentifier": config.harness.org_identifier,
                "projectIdentifier": sanitize_identifier(pipeline.group),
                "serviceDefinition": {
                    "type": "Kubernetes",
                    "spec": {
                        "manifests": [{
                            "manifest": {
                                "identifier": "k8smanifest",
                                "type": "K8sManifest",
                                "spec": {
                                    "store": {
                                        "type": "CustomRemote",
                                        "spec": {
                                            "extractionScript": self._build_extraction_script(),
                                            "filePath": "manifest.yaml",
                                        },
                                    },
                                    "skipResourceVersioning": False,
                                },
                            }
                        }],
                        "variables": [
                            {
                                "name": "image",
                                "type": "String",
                                "default": "<+input>",
                                "description": "Full ECR image URI",
                            },
                            {
                                "name": "app_id",
                                "type": "String",
                                "default": "<+input>",
                                "description": "App identifier in format: service-name.namespace.env-region",
                            },
                        ],
                    },
                },
            }
        }

    def _build_extraction_script(self) -> str:
        return (
            "#!/bin/bash\n"
            "set -e\n"
            "\n"
            'IMAGE="<+serviceVariables.image>"\n'
            'APP_ID="<+serviceVariables.app_id>"\n'
            "\n"
            'echo "DEBUG: IMAGE=${IMAGE}"\n'
            'echo "DEBUG: APP_ID=${APP_ID}"\n'
            "\n"
            'SERVICE_NAME=$(echo "$APP_ID" | cut -d\'.\' -f1)\n'
            'NAMESPACE=$(echo "$APP_ID" | cut -d\'.\' -f2)\n'
            "\n"
            'echo "DEBUG: SERVICE_NAME=${SERVICE_NAME}"\n'
            'echo "DEBUG: NAMESPACE=${NAMESPACE}"\n'
            "\n"
            'if [ -z "$SERVICE_NAME" ]; then\n'
            '  echo "ERROR: SERVICE_NAME is empty. Check that app_id is passed correctly."\n'
            "  exit 1\n"
            "fi\n"
            "\n"
            "cat > manifest.yaml <<EOF\n"
            "apiVersion: apps/v1\n"
            "kind: Deployment\n"
            "metadata:\n"
            "  name: ${SERVICE_NAME}\n"
            "  namespace: ${NAMESPACE}\n"
            "spec:\n"
            "  replicas: 2\n"
            "  selector:\n"
            "    matchLabels:\n"
            "      app: ${SERVICE_NAME}\n"
            "  template:\n"
            "    metadata:\n"
            "      labels:\n"
            "        app: ${SERVICE_NAME}\n"
            "    spec:\n"
            "      containers:\n"
            "      - name: ${SERVICE_NAME}\n"
            "        image: ${IMAGE}\n"
            "        ports:\n"
            "        - containerPort: 8080\n"
            "---\n"
            "apiVersion: v1\n"
            "kind: Service\n"
            "metadata:\n"
            "  name: ${SERVICE_NAME}\n"
            "  namespace: ${NAMESPACE}\n"
            "spec:\n"
            "  selector:\n"
            "    app: ${SERVICE_NAME}\n"
            "  ports:\n"
            "  - port: 80\n"
            "    targetPort: 8080\n"
            "EOF\n"
            "\n"
            'echo "--- Generated manifest ---"\n'
            "cat manifest.yaml\n"
        )

    # ------------------------------------------------------------------
    # Information Extraction
    # ------------------------------------------------------------------

    def _build_variables(self, pipeline: GocdPipeline) -> List[Dict[str, Any]]:
        variables = []
        for name, value in pipeline.parameters.items():
            variables.append({
                "name": name,
                "type": "String",
                "value": str(value) if value is not None else "",
                "description": f"Migrated from GoCD parameter: {name}",
            })
        for name, value in pipeline.environment_variables.items():
            converted = convert_gocd_variables(str(value) if value is not None else "")
            variables.append({
                "name": name,
                "type": "String",
                "value": converted,
                "description": f"Migrated from GoCD environment variable: {name}",
            })
        return variables

    def _extract_ecr_info(self, pipeline: GocdPipeline) -> Dict[str, str]:
        ecr_registry = ""
        ecr_image_path = ""
        ecr_region = pipeline.parameters.get("ecr_region",
                     pipeline.parameters.get("region", config.harness.default_aws_region))

        all_scripts = pipeline.all_scripts

        ecr_match = re.search(
            r'(\d+\.dkr\.ecr\.[a-z0-9-]+\.amazonaws\.com)/([^\s]+)',
            all_scripts
        )
        if ecr_match:
            ecr_registry = ecr_match.group(1)
            ecr_image_path = ecr_match.group(2)

        if not ecr_registry:
            ecr_registry = pipeline.parameters.get("docker_registry", "")
            ecr_image_path = pipeline.parameters.get("image_name", "")

        ecr_registry = convert_gocd_variables(ecr_registry)
        ecr_image_path = convert_gocd_variables(ecr_image_path)
        ecr_region = convert_gocd_variables(str(ecr_region))

        return {
            "registry": ecr_registry,
            "image_path": ecr_image_path,
            "region": ecr_region,
        }

    def _extract_ecr_account(self, ecr_info: Dict) -> str:
        """Extract the AWS account ID from the ECR registry URL."""
        registry = ecr_info.get("registry", "")
        match = re.match(r'^(\d+)\.dkr\.ecr', registry)
        if match:
            return match.group(1)
        return "<+input>"

    def _extract_repo_info(self, pipeline: GocdPipeline) -> Dict[str, str]:
        repos = {"service_repo": "", "deploy_repo": ""}
        for mat in pipeline.git_materials:
            url = mat.url
            branch = convert_gocd_variables(mat.branch)
            if "deploy" in mat.name.lower() or "deploy" in url.lower():
                repos["deploy_repo"] = url
                repos["deploy_branch"] = branch
            else:
                repos["service_repo"] = url
                repos["service_branch"] = branch

        if not repos["service_repo"] and pipeline.git_materials:
            repos["service_repo"] = pipeline.git_materials[0].url
            repos["service_branch"] = convert_gocd_variables(
                pipeline.git_materials[0].branch
            )

        return repos

    def _extract_environment_info(self, pipeline: GocdPipeline) -> Dict[str, str]:
        env_name = (
            pipeline.parameters.get("pipeline_env")
            or pipeline.parameters.get("env")
            or ""
        )

        if not env_name:
            name_lower = pipeline.name.lower()
            if "prod" in name_lower and "nonprod" not in name_lower:
                env_name = "prod"
            elif "dev" in name_lower or "nonprod" in name_lower:
                env_name = "nonprod"
            elif "staging" in name_lower or "stg" in name_lower:
                env_name = "staging"
            else:
                env_name = "default"

        region = (
            pipeline.parameters.get("region")
            or pipeline.parameters.get("region_short")
            or ""
        )
        return {"env_name": env_name, "region": region}

    def _extract_app_id(self, pipeline: GocdPipeline, pattern_id: str) -> str:
        """Extract the k8s_app_id from parameters or construct from pipeline name."""
        app_id = pipeline.parameters.get("k8s_app_id", "")
        if app_id:
            return convert_gocd_variables(app_id)

        scripts = pipeline.all_scripts
        app_id_match = re.search(r'k8s_app_id[=:\s]+([^\s]+)', scripts)
        if app_id_match:
            return convert_gocd_variables(app_id_match.group(1))

        return f"{pipeline.name}.default.default"

    def _derive_service_id(self, pipeline: GocdPipeline) -> str:
        """Derive a K8s service identifier from the pipeline name."""
        base = re.sub(r'-(dev|prod|staging|nonprod|build)$', '', pipeline.name, flags=re.IGNORECASE)
        return sanitize_identifier(f"k8s_{base}")

    def _extract_pre_build_script(self, pipeline: GocdPipeline) -> str:
        """Extract any pre-build scripts (git checkout, dependency install, etc.)."""
        lines = []
        for stage in pipeline.stages:
            if stage.name.lower() in ("build", "preprocess", "code-build", "code_build"):
                for job in stage.jobs:
                    for task in job.tasks:
                        if task.type == "exec" and task.arguments:
                            script = " ".join(task.arguments)
                            if "docker build" not in script.lower() and "docker push" not in script.lower():
                                if any(k in script.lower() for k in ["pip install", "npm install", "make", "chmod"]):
                                    if task.working_directory:
                                        wd = convert_gocd_variables(task.working_directory)
                                        lines.append(f"cd {wd}")
                                    lines.append(convert_gocd_variables(script))
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _get_approval_user_groups(self, pipeline: GocdPipeline) -> List[str]:
        groups = set()
        for stage in pipeline.stages:
            if stage.approval and stage.approval.type == "manual":
                for role in stage.approval.roles:
                    groups.add(f"account.{sanitize_identifier(role)}")
        return list(groups) if groups else ["account.Admin"]

    def _get_delegate_selectors(self, pipeline: GocdPipeline) -> List[str]:
        selectors = set()
        for stage in pipeline.stages:
            for job in stage.jobs:
                if job.elastic_profile_id:
                    sel = convert_gocd_variables(job.elastic_profile_id)
                    selectors.add(sel)
        return list(selectors) if selectors else []

    # ------------------------------------------------------------------
    # Entity Extraction
    # ------------------------------------------------------------------

    def _extract_entities(
        self, pipeline: GocdPipeline, pipeline_role: str,
        ecr_info: Dict, env_info: Dict,
        service_id: str, env_id: str, infra_id: str,
        approval_groups: List[str], delegate_selectors: List[str],
    ) -> List[Entity]:
        entities = []
        seen = set()
        project_id = sanitize_identifier(pipeline.group)

        if project_id not in seen:
            seen.add(project_id)
            entities.append(Entity(
                type=EntityType.PROJECT,
                identifier=project_id,
                name=pipeline.group,
                api_creatable=True,
            ))

        if pipeline.git_materials:
            conn_id = "github_connector"
            if conn_id not in seen:
                seen.add(conn_id)
                entities.append(Entity(
                    type=EntityType.CONNECTOR,
                    identifier=conn_id,
                    name="GitHub Connector",
                    api_creatable=True,
                    dependencies=["Secret: github_ssh_key"],
                ))

        if pipeline_role in ("build", "combined"):
            ecr_conn_id = "aws_connector"
            if ecr_conn_id not in seen:
                seen.add(ecr_conn_id)
                entities.append(Entity(
                    type=EntityType.CONNECTOR,
                    identifier=ecr_conn_id,
                    name="AWS Connector (ECR + K8s)",
                    api_creatable=True,
                    dependencies=["Secret: aws_access_key", "Secret: aws_secret_key"],
                ))

        if pipeline_role in ("deploy", "combined"):
            if service_id not in seen:
                seen.add(service_id)
                entities.append(Entity(
                    type=EntityType.SERVICE,
                    identifier=service_id,
                    name=f"K8s Service ({pipeline.name})",
                    api_creatable=True,
                    manual_instructions=(
                        "Create this service using the generated SERVICE.yaml file. "
                        "It uses Custom Remote Manifest for dynamic K8s manifest generation."
                    ),
                ))

            if env_id not in seen and env_id != "default":
                seen.add(env_id)
                env_type = "Production" if env_info.get("env_name", "").lower() == "prod" else "PreProduction"
                entities.append(Entity(
                    type=EntityType.ENVIRONMENT,
                    identifier=env_id,
                    name=f"{env_info['env_name'].title()} Environment",
                    api_creatable=True,
                ))

            if infra_id not in seen:
                seen.add(infra_id)
                entities.append(Entity(
                    type=EntityType.INFRA_DEFINITION,
                    identifier=infra_id,
                    name=f"K8s Infra ({env_info.get('env_name', 'default')})",
                    api_creatable=True,
                    manual_instructions=(
                        "Create a Kubernetes infrastructure definition with the correct "
                        "cluster connector and namespace for this environment."
                    ),
                ))

        for sel in delegate_selectors:
            delegate_id = sanitize_identifier(sel)
            if delegate_id not in seen:
                seen.add(delegate_id)
                entities.append(Entity(
                    type=EntityType.DELEGATE,
                    identifier=delegate_id,
                    name=f"{sel} Delegate",
                    api_creatable=False,
                    manual_instructions=(
                        f"Install a Harness Delegate with selector: {sel}\n"
                        f"Mapped from GoCD elastic_profile_id."
                    ),
                ))

        for group_ref in approval_groups:
            group_id = group_ref.replace("account.", "")
            if group_id not in seen and group_id != "Admin":
                seen.add(group_id)
                entities.append(Entity(
                    type=EntityType.USER_GROUP,
                    identifier=group_id,
                    name=group_id,
                    api_creatable=False,
                    manual_instructions=(
                        f"Create a User Group for deployment approvals. "
                        f"Mapped from GoCD approval role."
                    ),
                ))

        return entities
