"""
GoCD converter registry.

All GoCD pattern converters register here. The engine looks up converters
by their converter_key (assigned by the classifier).
"""

from typing import Dict

from src.converters.base import BaseConverter
from src.converters.gocd.generic import GenericConverter

# Registry of all available GoCD converters
_REGISTRY: Dict[str, BaseConverter] = {}


def register_converter(converter: BaseConverter):
    """Register a converter in the global registry."""
    _REGISTRY[converter.converter_key] = converter


def get_converter(converter_key: str) -> BaseConverter:
    """Look up a converter by key. Falls back to generic."""
    return _REGISTRY.get(converter_key, _REGISTRY.get("generic"))


def list_converters() -> Dict[str, BaseConverter]:
    """Return all registered converters."""
    return dict(_REGISTRY)


# Auto-register built-in converters
register_converter(GenericConverter())

# Pattern-specific converters
from src.converters.gocd.terraform_infra import TerraformInfraConverter
register_converter(TerraformInfraConverter())

from src.converters.gocd.docker_k8s_deploy import DockerK8sDeployConverter
register_converter(DockerK8sDeployConverter())

from src.converters.gocd.ld_upload import LdUploadConverter
register_converter(LdUploadConverter())

from src.converters.gocd.ops_script import OpsScriptConverter
register_converter(OpsScriptConverter())

from src.converters.gocd.data_pipeline import DataPipelineConverter
register_converter(DataPipelineConverter())

from src.converters.gocd.db_migration import DbMigrationConverter
register_converter(DbMigrationConverter())

from src.converters.gocd.terraform_deploy import TerraformDeployConverter
register_converter(TerraformDeployConverter())

from src.converters.gocd.perf_test import PerfTestConverter
register_converter(PerfTestConverter())
