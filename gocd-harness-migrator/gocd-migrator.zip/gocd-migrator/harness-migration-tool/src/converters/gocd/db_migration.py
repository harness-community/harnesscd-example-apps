"""
DB Migration GoCD Converter.

Handles the `db_migration` pattern (19 pipelines): RDS provisioning via
Terraform followed by database schema migration (Flyway / prepare_db.sh).

Typical GoCD structure:
  Stage 1: rds-plan  – Terraform plan for RDS infrastructure
  Stage 2: rds-apply – Terraform apply (may have approval)
  Stage 3: migrate   – Run DB migration scripts (prepare_db.sh, flyway)

The Harness output uses:
  - Custom stage with TerraformPlan + HarnessApproval + TerraformApply for
    the infrastructure provisioning portion
  - Custom stage with ShellScript steps for the DB migration portion
  - Fetch artifact tasks become structured TODO stubs
  - fetch_config #{vault_path} → Harness secret expression references
"""

import re
from typing import List, Dict, Any, Optional, Tuple

from src.converters.base import BaseConverter
from src.converters.harness_builder import HarnessBuilder
from src.core.models import (
    GocdPipeline, GocdStage, GocdTask,
    ConversionResult, ConversionMethod, Entity, EntityType,
)
from src.validators.identifier import (
    sanitize_identifier, sanitize_step_name, convert_gocd_variables,
)


_TERRAFORM_STAGE_HINTS = re.compile(
    r"(rds[_-]?plan|rds[_-]?apply|terraform[_-]?plan|terraform[_-]?apply|tf[_-]?plan|tf[_-]?apply)",
    re.IGNORECASE,
)

_MIGRATION_HINTS = re.compile(
    r"(migrate|flyway|prepare_db|db[_-]?migrate|schema|liquibase)",
    re.IGNORECASE,
)


class DbMigrationConverter(BaseConverter):
    """Converter for RDS + database migration GoCD pipelines."""

    @property
    def converter_key(self) -> str:
        return "db_migration"

    @property
    def supported_patterns(self) -> List[str]:
        return ["db_migration"]

    def convert(self, pipeline: GocdPipeline, pattern_id: str) -> ConversionResult:
        builder = HarnessBuilder()
        builder.reset_counter()

        result = ConversionResult(
            source_file="",
            source_pipeline_name=pipeline.name,
            source_type="gocd",
            pattern=None,
            conversion_method=ConversionMethod.RULE_BASED,
        )

        variables = builder.build_all_variables(pipeline)
        has_git = bool(pipeline.git_materials)
        delegate_selectors = builder.get_delegate_selectors(pipeline)

        harness_stages = []
        has_ci_stage = False
        first_ci_stage = True
        provisioner_id = sanitize_identifier(pipeline.name) + "_rds"

        for stage in pipeline.stages:
            is_tf = bool(_TERRAFORM_STAGE_HINTS.search(stage.name))
            is_migrate = bool(_MIGRATION_HINTS.search(stage.name))

            if is_tf and not is_migrate:
                h_stage = self._build_terraform_stage(
                    stage, builder, pipeline, provisioner_id,
                    is_plan=("plan" in stage.name.lower()),
                    delegate_selectors=delegate_selectors,
                )
                harness_stages.append(h_stage)
            else:
                steps = self._build_migration_steps(stage, builder, pipeline)
                if has_git:
                    approval_steps, ci_steps = builder.split_steps_for_ci(steps)
                    if approval_steps:
                        harness_stages.append(builder.build_approval_stage(
                            name=f"Approve {stage.name}",
                            message=f"Review and approve DB migration: {stage.name}",
                            user_groups=self._resolve_user_groups(stage.approval) if stage.approval else ["account.Admin"],
                        ))
                    if ci_steps:
                        harness_stages.append(builder.build_ci_stage(
                            name=stage.name,
                            steps=ci_steps,
                            clone_codebase=first_ci_stage,
                            description=f"DB Migration – migrated from GoCD stage: {stage.name}",
                            delegate_selectors=delegate_selectors[:1] if delegate_selectors else None,
                        ))
                        has_ci_stage = True
                        first_ci_stage = False
                else:
                    harness_stages.append(builder.build_custom_stage(
                        name=stage.name,
                        description=f"DB Migration – migrated from GoCD stage: {stage.name}",
                        steps=steps,
                        delegate_selectors=delegate_selectors[:1] if delegate_selectors else None,
                    ))

        codebase = builder.build_codebase(pipeline.git_materials[0]) if has_git and has_ci_stage else None

        pipeline_yaml = builder.build_pipeline(
            name=pipeline.name,
            group=pipeline.group,
            stages=harness_stages,
            variables=variables,
            codebase=codebase,
            description=f"DB Migration pipeline migrated from GoCD",
        )

        triggers = self._build_triggers(pipeline, builder)
        if triggers:
            pipeline_yaml["_triggers"] = triggers

        result.harness_yaml = pipeline_yaml
        result.entities = self._extract_entities(pipeline, delegate_selectors)
        result.success = True
        return result

    # ------------------------------------------------------------------
    # Terraform stages (plan / apply)
    # ------------------------------------------------------------------

    def _build_terraform_stage(
        self,
        stage: GocdStage,
        builder: HarnessBuilder,
        pipeline: GocdPipeline,
        provisioner_id: str,
        is_plan: bool,
        delegate_selectors: List[str],
    ) -> Dict[str, Any]:
        steps: List[Dict[str, Any]] = []

        # Fetch tasks become TODO stubs
        for job in stage.jobs:
            for task in job.tasks:
                if task.type == "fetch":
                    steps.append(self._build_fetch_step(task, builder))

        if is_plan:
            steps.append(builder.build_terraform_plan_step(
                provisioner_id=provisioner_id,
                command="Apply",
            ))
        else:
            if stage.approval and stage.approval.type == "manual":
                groups = self._resolve_user_groups(stage.approval)
                steps.append(builder.build_approval_step(
                    name=f"Approve {stage.name}",
                    message=f"Review Terraform plan and approve apply for {pipeline.name}",
                    user_groups=groups,
                ))
            steps.append(builder.build_terraform_apply_step(
                provisioner_id=provisioner_id,
            ))

        return builder.build_custom_stage(
            name=stage.name,
            description=f"Terraform {('Plan' if is_plan else 'Apply')} – {stage.name}",
            steps=steps,
            delegate_selectors=delegate_selectors[:1] if delegate_selectors else None,
        )

    # ------------------------------------------------------------------
    # DB migration stages
    # ------------------------------------------------------------------

    def _build_migration_steps(
        self,
        stage: GocdStage,
        builder: HarnessBuilder,
        pipeline: GocdPipeline,
    ) -> List[Dict[str, Any]]:
        steps: List[Dict[str, Any]] = []

        if stage.approval and stage.approval.type == "manual":
            groups = self._resolve_user_groups(stage.approval)
            steps.append(builder.build_approval_step(
                name=f"Approve {stage.name}",
                message=f"Review and approve DB migration stage: {stage.name}",
                user_groups=groups,
            ))

        for job in stage.jobs:
            tasks = job.tasks
            i = 0
            while i < len(tasks):
                task = tasks[i]

                if task.type == "fetch":
                    steps.append(self._build_fetch_step(task, builder))
                    i += 1
                    continue

                if task.type != "exec":
                    steps.append(builder.build_shell_step(
                        name=sanitize_step_name(f"Unknown task {task.type}"),
                        script=f"# TODO: Manually convert task type '{task.type}'\n# Raw: {task.raw}",
                    ))
                    i += 1
                    continue

                script = self._extract_script(task)

                merged, consumed = self._try_merge_git_preamble(tasks, i)
                if consumed > 1:
                    step_name = sanitize_step_name(
                        self._infer_step_name(merged) or "Git Checkout"
                    )
                    steps.append(builder.build_shell_step(
                        name=step_name,
                        script=convert_gocd_variables(self._annotate_fetch_config(merged)),
                    ))
                    i += consumed
                    continue

                step_name = sanitize_step_name(
                    self._infer_step_name(script) or self._default_step_name(task)
                )
                steps.append(builder.build_shell_step(
                    name=step_name,
                    script=convert_gocd_variables(self._annotate_fetch_config(script)),
                ))
                i += 1

        return steps

    # ------------------------------------------------------------------
    # Fetch task stubs
    # ------------------------------------------------------------------

    def _build_fetch_step(self, task: GocdTask, builder: HarnessBuilder) -> Dict[str, Any]:
        pipeline_ref = convert_gocd_variables(task.fetch_pipeline) if task.fetch_pipeline else "(same pipeline)"
        source = task.fetch_source or "artifact"
        dest = task.fetch_destination or ""

        script = (
            f"# Artifact fetch from upstream pipeline\n"
            f"# Source pipeline: {pipeline_ref}\n"
            f"# Stage: {task.fetch_stage} / Job: {task.fetch_job}\n"
            f"# File: {source}\n"
        )
        if dest:
            script += f"# Destination: {dest}\n"
        script += (
            f"#\n"
            f"# Harness migration options:\n"
            f"#   1. Use output variables from the upstream pipeline trigger\n"
            f"#   2. Store in S3/GCS and fetch via shell script\n"
            f"#   3. Use Harness Artifact Source with pipeline chaining\n"
            f'echo "TODO: Fetch {source} from {pipeline_ref}"\n'
        )

        return builder.build_shell_step(
            name=sanitize_step_name(f"Fetch {source}"),
            script=script,
            timeout="5m",
        )

    # ------------------------------------------------------------------
    # Script helpers
    # ------------------------------------------------------------------

    def _extract_script(self, task: GocdTask) -> str:
        if task.command in ("bash", "sh") and len(task.arguments) >= 2 and task.arguments[0] == "-c":
            script = " ".join(task.arguments[1:])
        elif task.arguments:
            script = f"{task.command} {' '.join(task.arguments)}"
        else:
            script = task.command

        if task.working_directory:
            wd = convert_gocd_variables(task.working_directory)
            script = f"cd {wd} && {script}"
        return script

    def _annotate_fetch_config(self, script: str) -> str:
        def _replace(m):
            path = m.group(1)
            return (
                f"# fetch_config: vault path = {path}\n"
                f"# TODO: Map to Harness Secret Manager → secrets.getValue(\"<secret_id>\")\n"
                f"{m.group(0)}"
            )
        return re.sub(r"(?:\.?\s*)?fetch_config\s+([\w/\-#{}.]+)", _replace, script)

    def _try_merge_git_preamble(self, tasks, start_idx) -> Tuple[str, int]:
        git_cmds = re.compile(r"git\s+(fetch|reset|checkout|pull)", re.IGNORECASE)
        scripts = []
        i = start_idx
        while i < len(tasks) and tasks[i].type == "exec":
            s = self._extract_script(tasks[i])
            if i == start_idx or git_cmds.search(s):
                scripts.append(s)
                i += 1
            else:
                break
        if len(scripts) > 1:
            return "\n".join(scripts), len(scripts)
        return scripts[0] if scripts else "", 1

    _STEP_HINTS = [
        (r"prepare_db|flyway|migrate|schema", "Run DB Migration"),
        (r"deploy_rds\.sh", "Deploy RDS"),
        (r"terraform\s+(plan|apply|init)", "Terraform"),
        (r"fetch_config", "Fetch Secrets"),
        (r"git\s+fetch.*git\s+reset|git\s+checkout", "Git Checkout"),
        (r"docker\s+build", "Docker Build"),
        (r"aws\s+ecr", "ECR Login"),
    ]

    def _infer_step_name(self, script: str) -> Optional[str]:
        for regex, label in self._STEP_HINTS:
            if re.search(regex, script, re.IGNORECASE):
                return label
        return None

    def _default_step_name(self, task: GocdTask) -> str:
        if task.arguments:
            hint = " ".join(task.arguments[:2])[:50]
            return sanitize_step_name(f"Execute {hint}")
        return sanitize_step_name(f"Execute {task.command[:50]}")

    # ------------------------------------------------------------------
    # User groups
    # ------------------------------------------------------------------

    def _resolve_user_groups(self, approval) -> List[str]:
        groups = []
        if approval.roles:
            groups = [f"account.{sanitize_identifier(r)}" for r in approval.roles]
        if approval.users:
            groups.extend([f"account.{sanitize_identifier(u)}" for u in approval.users])
        return groups or ["account.Admin"]

    # ------------------------------------------------------------------
    # Triggers
    # ------------------------------------------------------------------

    def _build_triggers(self, pipeline: GocdPipeline, builder: HarnessBuilder) -> List[Dict]:
        triggers = []
        if pipeline.timer:
            triggers.append(builder.build_cron_trigger(pipeline.timer, pipeline.name))
        for mat in pipeline.pipeline_materials:
            if mat.name:
                upstream = convert_gocd_variables(
                    pipeline.parameters.get("cornerstone_pipeline", mat.name)
                )
                triggers.append({
                    "trigger": {
                        "name": f"{pipeline.name}_on_{sanitize_identifier(upstream)}",
                        "identifier": sanitize_identifier(f"{pipeline.name}_on_{upstream}"),
                        "type": "Pipeline",
                        "spec": {
                            "type": "Pipeline",
                            "spec": {
                                "pipelineIdentifier": sanitize_identifier(upstream),
                                "stageName": "<+input>",
                                "event": "OnSuccess",
                            },
                        },
                        "pipelineIdentifier": sanitize_identifier(pipeline.name),
                    }
                })
        return triggers

    # ------------------------------------------------------------------
    # Entities
    # ------------------------------------------------------------------

    def _extract_entities(self, pipeline: GocdPipeline, delegate_selectors: List[str]) -> List[Entity]:
        entities: List[Entity] = []

        entities.append(Entity(
            type=EntityType.PROJECT,
            identifier=sanitize_identifier(pipeline.group),
            name=pipeline.group,
            payload={"orgIdentifier": "default"},
        ))

        if pipeline.git_materials:
            entities.append(Entity(
                type=EntityType.CONNECTOR,
                identifier="GitHub_Connector",
                name="GitHub Connector",
                payload={"type": "Github", "spec": {"url": pipeline.git_materials[0].url}},
            ))

        entities.append(Entity(
            type=EntityType.CONNECTOR,
            identifier="AWS_Connector",
            name="AWS Connector (for Terraform + RDS)",
            payload={"type": "Aws", "spec": {"credential": {"type": "ManualConfig"}}},
        ))

        for sel in delegate_selectors:
            entities.append(Entity(
                type=EntityType.DELEGATE,
                identifier=sanitize_identifier(sel),
                name=f"{sel} Delegate",
                payload={"tags": [sel]},
            ))

        vault_path = pipeline.parameters.get("vault_path", "")
        if vault_path:
            entities.append(Entity(
                type=EntityType.SECRET,
                identifier=sanitize_identifier(f"vault_{vault_path.split('/')[-1]}"),
                name=f"Vault secret: {vault_path}",
                payload={"secretManagerIdentifier": "harnessSecretManager", "valueType": "Inline"},
            ))

        return entities
