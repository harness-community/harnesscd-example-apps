"""
Terraform Infrastructure Converter.

Handles GoCD patterns:
  - terraform_infra (plan -> apply)
  - terraform_infra_db (plan -> apply -> migrate)
  - s3_bucket (s3 bucket provisioning)
  - ld_terraform (LaunchDarkly via Terraform)

Generates Harness Custom stages with native TerraformPlan, HarnessApproval,
and TerraformApply steps. Custom stages support Terraform steps natively
without requiring a service/environment wrapper.

Validated Harness YAML template provided by user.
"""

import re
from typing import List, Dict, Any, Optional

from src.converters.base import BaseConverter
from src.core.models import (
    GocdPipeline, GocdStage, GocdMaterial,
    ConversionResult, ConversionMethod, Entity, EntityType,
)
from src.validators.identifier import (
    sanitize_identifier, convert_gocd_variables,
    extract_repo_name, pipeline_name_to_title,
)
from config import config


class TerraformInfraConverter(BaseConverter):
    """Converts GoCD Terraform infrastructure pipelines to Harness CD pipelines."""

    @property
    def converter_key(self) -> str:
        return "terraform_infra"

    @property
    def supported_patterns(self) -> List[str]:
        return ["terraform_infra", "terraform_infra_db", "s3_bucket", "ld_terraform"]

    def convert(self, pipeline: GocdPipeline, pattern_id: str) -> ConversionResult:
        result = ConversionResult(
            source_file="",
            source_pipeline_name=pipeline.name,
            source_type="gocd",
            pattern=None,
            conversion_method=ConversionMethod.RULE_BASED,
        )

        # Build variables from GoCD parameters + env vars
        variables = self._build_variables(pipeline)

        # Extract git material info for terraform configFiles
        git_mat = pipeline.git_materials[0] if pipeline.git_materials else None
        repo_name = extract_repo_name(git_mat.url) if git_mat else "<+input>"
        branch = convert_gocd_variables(git_mat.branch) if git_mat else "<+input>"

        # Extract terraform folder path from script working directories
        folder_path = self._extract_terraform_folder(pipeline)

        # Derive provisioner identifier from pipeline name
        provisioner_id = sanitize_identifier(pipeline.name)

        # Determine terraform command (Apply or Destroy)
        tf_command = self._detect_terraform_command(pipeline)

        # Detect if there's a prod-confirm / extra approval gate
        has_prod_confirm = any(
            s.name.lower() in ("prod-confirm", "prod_confirm")
            for s in pipeline.stages
        )

        # Build the CD stage
        stage = self._build_terraform_stage(
            pipeline=pipeline,
            repo_name=repo_name,
            branch=branch,
            folder_path=folder_path,
            provisioner_id=provisioner_id,
            tf_command=tf_command,
        )

        stages = [stage]

        # If pattern is terraform_infra_db, add a DB migration stage
        if pattern_id == "terraform_infra_db":
            migrate_stage = self._build_migrate_stage(pipeline)
            if migrate_stage:
                stages.append(migrate_stage)

        # Build the pipeline
        tags = {pipeline.group: ""} if pipeline.group else {}
        harness_yaml = {
            "pipeline": {
                "name": pipeline.name,
                "identifier": sanitize_identifier(pipeline.name),
                "projectIdentifier": sanitize_identifier(pipeline.group),
                "orgIdentifier": config.harness.org_identifier,
                "tags": tags,
                "variables": variables,
                "stages": stages,
            }
        }

        # Add warnings for pipeline dependencies
        for mat in pipeline.pipeline_materials:
            dep = convert_gocd_variables(mat.pipeline)
            result.warnings.append(
                f"Depends on upstream pipeline '{dep}' (stage: {mat.stage}). "
                f"Create a Harness trigger to chain these."
            )

        # Add timer warning
        if pipeline.timer:
            result.warnings.append(
                f"Pipeline has a cron schedule ({pipeline.timer.spec}). "
                f"Create a Harness cron trigger separately."
            )

        if has_prod_confirm:
            result.warnings.append(
                "Original pipeline had a prod-confirm gate. "
                "The approval step in the Harness pipeline serves this purpose."
            )

        result.harness_yaml = harness_yaml
        result.entities = self._extract_entities(pipeline)
        result.success = True
        return result

    # ------------------------------------------------------------------
    # Variable Building
    # ------------------------------------------------------------------

    def _build_variables(self, pipeline: GocdPipeline) -> List[Dict[str, Any]]:
        """Build Harness variables from GoCD parameters + env vars."""
        variables = []

        for name, value in pipeline.parameters.items():
            variables.append({
                "name": name,
                "type": "String",
                "value": str(value) if value is not None else "",
                "description": f"Migrated from GoCD parameter: {name}",
            })

        for name, value in pipeline.environment_variables.items():
            converted = convert_gocd_variables(str(value) if value is not None else "")
            variables.append({
                "name": name,
                "type": "String",
                "value": converted,
                "description": f"Migrated from GoCD environment variable: {name}",
            })

        return variables

    # ------------------------------------------------------------------
    # Terraform Stage Builder
    # ------------------------------------------------------------------

    def _build_terraform_stage(
        self,
        pipeline: GocdPipeline,
        repo_name: str,
        branch: str,
        folder_path: str,
        provisioner_id: str,
        tf_command: str,
    ) -> Dict[str, Any]:
        """Build a Custom stage with native TerraformPlan -> Approval -> TerraformApply steps."""

        connector_ref = config.harness.default_connector_ref
        aws_region = self._detect_aws_region(pipeline)
        steps = []

        # Build environment variables from pipeline params so Terraform can access them
        tf_env_vars = self._build_terraform_env_vars(pipeline)

        # Step 1: TerraformPlan
        tf_plan_config: Dict[str, Any] = {
            "command": tf_command,
            "configFiles": {
                "store": {
                    "spec": {
                        "connectorRef": connector_ref,
                        "repoName": repo_name,
                        "gitFetchType": "Branch",
                        "branch": branch,
                        "folderPath": folder_path,
                    },
                    "type": "Github",
                }
            },
            "providerCredential": {
                "type": "Aws",
                "spec": {
                    "connectorRef": config.harness.aws_connector_ref,
                    "region": aws_region,
                    "roleArn": "",
                },
            },
            "secretManagerRef": config.harness.secret_manager_ref,
            "skipRefreshCommand": False,
        }
        if tf_env_vars:
            tf_plan_config["environmentVariables"] = tf_env_vars

        steps.append({
            "step": {
                "type": "TerraformPlan",
                "name": "Terraform Plan",
                "identifier": "terraform_plan",
                "spec": {
                    "provisionerIdentifier": provisioner_id,
                    "configuration": tf_plan_config,
                },
                "timeout": "10m",
            }
        })

        # Step 2: HarnessApproval
        user_groups = self._get_approval_user_groups(pipeline)
        steps.append({
            "step": {
                "type": "HarnessApproval",
                "name": "Approve Terraform Apply",
                "identifier": "approve_terraform_apply",
                "spec": {
                    "approvalMessage": "Please review the Terraform plan and approve the pipeline progression",
                    "includePipelineExecutionHistory": True,
                    "isAutoRejectEnabled": False,
                    "approvers": {
                        "userGroups": user_groups,
                        "minimumCount": 1,
                        "disallowPipelineExecutor": False,
                    },
                    "approverInputs": [],
                },
                "timeout": "1d",
            }
        })

        # Step 3: TerraformApply (inherits config from the Plan step)
        steps.append({
            "step": {
                "type": "TerraformApply",
                "name": "Terraform Apply",
                "identifier": "terraform_apply",
                "spec": {
                    "provisionerIdentifier": provisioner_id,
                    "configuration": {
                        "type": "InheritFromPlan",
                    },
                },
                "timeout": "10m",
            }
        })

        delegate_selectors = self._get_delegate_selectors(pipeline)

        stage = {
            "stage": {
                "name": "Terraform Plan and Apply",
                "identifier": "terraform_plan_and_apply",
                "description": f"Migrated from GoCD pipeline: {pipeline.name}",
                "type": "Custom",
                "spec": {
                    "execution": {
                        "steps": steps,
                    },
                },
                "tags": {},
                "failureStrategies": [
                    {
                        "onFailure": {
                            "errors": ["AllErrors"],
                            "action": {
                                "type": "ManualIntervention",
                                "spec": {
                                    "timeout": "1d",
                                    "onTimeout": {
                                        "action": {"type": "MarkAsFailure"},
                                    },
                                },
                            },
                        }
                    }
                ],
            }
        }

        if delegate_selectors:
            stage["stage"]["delegateSelectors"] = delegate_selectors

        return stage

    # ------------------------------------------------------------------
    # DB Migration Stage (for terraform_infra_db pattern)
    # ------------------------------------------------------------------

    def _build_migrate_stage(self, pipeline: GocdPipeline) -> Optional[Dict[str, Any]]:
        """Build a migration stage if the pipeline has migrate/repair stages."""
        migrate_stages = [
            s for s in pipeline.stages
            if s.name.lower() in ("migrate", "repair", "create-table")
        ]
        if not migrate_stages:
            return None

        from src.converters.harness_builder import HarnessBuilder
        builder = HarnessBuilder()

        steps = []
        for stage in migrate_stages:
            task_steps = builder.convert_stage_tasks_to_steps(stage)
            steps.extend(task_steps)

        return builder.build_custom_stage(
            name="Database Migration",
            steps=steps,
            description="Database migration step migrated from GoCD",
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _build_terraform_env_vars(self, pipeline: GocdPipeline) -> List[Dict[str, Any]]:
        """Map pipeline variables as environment variables for the Terraform execution.

        GoCD parameters like #{env}, #{project_name} were consumed by wrapper
        scripts (deploy-plan.sh, manage.sh). In Harness native Terraform steps
        these become env vars so the .tf configs can reference them via
        TF_VAR_<name> or standard env var lookups.
        """
        env_vars = []
        for name in pipeline.parameters:
            env_vars.append({
                "name": name,
                "value": f"<+pipeline.variables.{name}>",
                "type": "String",
            })
        for name in pipeline.environment_variables:
            env_vars.append({
                "name": name,
                "value": f"<+pipeline.variables.{name}>",
                "type": "String",
            })
        return env_vars

    def _extract_terraform_folder(self, pipeline: GocdPipeline) -> str:
        """Try to extract the terraform folder path from script working directories."""
        for task in pipeline.all_tasks:
            if task.type == "exec" and task.working_directory:
                wd = task.working_directory.lower()
                if "terraform" in wd:
                    return convert_gocd_variables(task.working_directory)
                if "scripts" in wd:
                    # Scripts dir is usually adjacent to terraform dir
                    parent = task.working_directory.rsplit("/scripts", 1)[0]
                    return convert_gocd_variables(f"{parent}/terraform")
        return "<+input>"

    def _detect_terraform_command(self, pipeline: GocdPipeline) -> str:
        """Detect whether this is Apply or Destroy based on GoCD config."""
        command_var = pipeline.environment_variables.get("COMMAND", "apply_terraform")

        if "destroy" in command_var.lower():
            return "Destroy"

        # Also check stage names
        for stage in pipeline.stages:
            if "destroy" in stage.name.lower():
                return "Destroy"

        return "Apply"

    _REGION_MAP = {
        "aps1": "ap-south-1",
        "apse1": "ap-southeast-1",
        "apse2": "ap-southeast-2",
        "apne1": "ap-northeast-1",
        "afs1": "af-south-1",
        "euw1": "eu-west-1",
        "euw2": "eu-west-2",
        "euc1": "eu-central-1",
        "use1": "us-east-1",
        "usw2": "us-west-2",
    }

    def _detect_aws_region(self, pipeline: GocdPipeline) -> str:
        """Detect AWS region from pipeline name, parameters, or env vars."""
        search_targets = [
            pipeline.name,
            pipeline.parameters.get("environment", ""),
            pipeline.parameters.get("region", ""),
            pipeline.parameters.get("aws_region", ""),
            pipeline.environment_variables.get("AWS_REGION", ""),
            pipeline.environment_variables.get("AWS_DEFAULT_REGION", ""),
        ]
        combined = " ".join(str(v) for v in search_targets).lower()

        for suffix, region in self._REGION_MAP.items():
            if suffix in combined:
                return region

        return config.harness.default_aws_region

    def _get_approval_user_groups(self, pipeline: GocdPipeline) -> List[str]:
        """Extract approval user groups from GoCD approval roles."""
        groups = set()
        for stage in pipeline.stages:
            if stage.approval and stage.approval.type == "manual":
                for role in stage.approval.roles:
                    groups.add(f"account.{sanitize_identifier(role)}")
                for user in stage.approval.users:
                    # Users are mapped differently -- add as warning
                    pass
        return list(groups) if groups else ["account.Admin"]

    def _get_delegate_selectors(self, pipeline: GocdPipeline) -> List[str]:
        """Extract delegate selectors from elastic profile IDs."""
        selectors = set()
        for stage in pipeline.stages:
            for job in stage.jobs:
                if job.elastic_profile_id:
                    sel = convert_gocd_variables(job.elastic_profile_id)
                    selectors.add(sel)

        ep = pipeline.parameters.get("elastic_profile_env")
        if ep:
            selectors.add(f"<+pipeline.variables.elastic_profile_env>-infra-eks-legacy")

        return list(selectors) if selectors else []

    # ------------------------------------------------------------------
    # Entity Extraction
    # ------------------------------------------------------------------

    def _extract_entities(self, pipeline: GocdPipeline) -> List[Entity]:
        """Extract required Harness entities."""
        entities = []
        seen = set()

        # Project
        proj_id = sanitize_identifier(pipeline.group)
        if proj_id not in seen:
            seen.add(proj_id)
            entities.append(Entity(
                type=EntityType.PROJECT,
                identifier=proj_id,
                name=pipeline.group,
                api_creatable=True,
            ))

        # GitHub Connector
        if "GitHub_Connector" not in seen:
            seen.add("GitHub_Connector")
            entities.append(Entity(
                type=EntityType.CONNECTOR,
                identifier="GitHub_Connector",
                name="GitHub Connector",
                api_creatable=True,
                dependencies=["Secret: github_ssh_key"],
            ))

        # AWS Connector (for Terraform provider credential)
        aws_conn = config.harness.aws_connector_ref.replace("account.", "")
        if aws_conn not in seen:
            seen.add(aws_conn)
            entities.append(Entity(
                type=EntityType.CONNECTOR,
                identifier=aws_conn,
                name="AWS Connector (Terraform Provider)",
                api_creatable=True,
                dependencies=["AWS IAM Role / Access Keys"],
            ))

        # Secret Manager
        sm_ref = config.harness.secret_manager_ref
        if sm_ref not in seen:
            seen.add(sm_ref)
            entities.append(Entity(
                type=EntityType.SECRET,
                identifier=sm_ref,
                name="Harness Secret Manager",
                api_creatable=False,
                manual_instructions="Built-in Harness secret manager. Verify it is enabled at account level.",
            ))

        # User Groups (from approval roles)
        user_groups = self._get_approval_user_groups(pipeline)
        for ug in user_groups:
            ug_id = ug.replace("account.", "")
            if ug_id not in seen:
                seen.add(ug_id)
                entities.append(Entity(
                    type=EntityType.USER_GROUP,
                    identifier=ug_id,
                    name=ug_id.replace("_", " ").title(),
                    api_creatable=True,
                    manual_instructions=f"Mapped from GoCD approval role. Ref: {ug}",
                ))

        # Delegates (from elastic_profile_id on jobs)
        delegate_selectors = self._get_delegate_selectors(pipeline)
        for sel in delegate_selectors:
            sel_id = sanitize_identifier(sel)
            if sel_id not in seen:
                seen.add(sel_id)
                entities.append(Entity(
                    type=EntityType.DELEGATE,
                    identifier=sel_id,
                    name=f"{sel} Delegate",
                    api_creatable=False,
                    manual_instructions=f"Mapped from GoCD elastic_profile_id. Install a Harness delegate with selector: {sel}",
                ))

        return entities
