"""
Generic GoCD Converter.

Fallback converter for pipelines that don't match a specific pattern.
Uses CI stages with Run steps when git materials are present,
Custom stages otherwise.
"""

from typing import List

from src.converters.base import BaseConverter
from src.converters.harness_builder import HarnessBuilder
from src.core.models import (
    GocdPipeline, ConversionResult, ConversionMethod, Entity, EntityType,
)
from src.validators.identifier import sanitize_identifier, convert_gocd_variables


class GenericConverter(BaseConverter):
    """Fallback converter that handles any GoCD pipeline generically."""

    @property
    def converter_key(self) -> str:
        return "generic"

    @property
    def supported_patterns(self) -> List[str]:
        return ["generic"]

    def convert(self, pipeline: GocdPipeline, pattern_id: str) -> ConversionResult:
        """Convert a GoCD pipeline using generic mapping rules."""
        builder = HarnessBuilder()
        builder.reset_counter()

        result = ConversionResult(
            source_file="",
            source_pipeline_name=pipeline.name,
            source_type="gocd",
            pattern=None,
            conversion_method=ConversionMethod.RULE_BASED,
        )

        variables = builder.build_all_variables(pipeline)
        has_git = bool(pipeline.git_materials)
        codebase = builder.build_codebase(pipeline.git_materials[0]) if has_git else None
        delegate_selectors = builder.get_delegate_selectors(pipeline)

        harness_stages = []
        first_ci_stage = True

        for stage in pipeline.stages:
            has_approval = stage.approval and stage.approval.type == "manual"

            user_groups = ["account.Admin"]
            if has_approval and stage.approval.roles:
                user_groups = [
                    f"account.{sanitize_identifier(r)}"
                    for r in stage.approval.roles
                ]

            if has_approval:
                harness_stages.append(builder.build_approval_stage(
                    name=f"Approve {stage.name}",
                    message=f"Review and approve stage: {stage.name}",
                    user_groups=user_groups,
                ))

            if has_git:
                run_steps = builder.convert_stage_tasks_to_run_steps(stage)
                ci_stage = builder.build_ci_stage(
                    name=stage.name,
                    steps=run_steps,
                    clone_codebase=first_ci_stage,
                    description=f"Migrated from GoCD stage: {stage.name}",
                    delegate_selectors=delegate_selectors[:1] if delegate_selectors else None,
                )
                harness_stages.append(ci_stage)
                first_ci_stage = False
            else:
                task_steps = builder.convert_stage_tasks_to_steps(stage)
                custom_stage = builder.build_custom_stage(
                    name=stage.name,
                    steps=task_steps,
                    delegate_selectors=delegate_selectors[:1] if delegate_selectors else None,
                )
                harness_stages.append(custom_stage)

        harness_yaml = builder.build_pipeline(
            name=pipeline.name,
            group=pipeline.group,
            stages=harness_stages,
            variables=variables if variables else None,
            codebase=codebase,
        )

        if pipeline.timer:
            trigger = builder.build_cron_trigger(pipeline.timer, pipeline.name)
            result.warnings.append(
                f"Pipeline has a cron schedule ({pipeline.timer.spec}). "
                f"Create a Harness trigger separately."
            )
            harness_yaml["_trigger"] = trigger

        for mat in pipeline.pipeline_materials:
            dep_pipeline = convert_gocd_variables(mat.pipeline)
            result.warnings.append(
                f"Pipeline depends on upstream pipeline '{dep_pipeline}' "
                f"(stage: {mat.stage}). Create a Harness trigger to chain these."
            )

        result.entities = self._extract_entities(pipeline)
        result.harness_yaml = harness_yaml
        result.success = True

        return result

    def _extract_entities(self, pipeline: GocdPipeline) -> List[Entity]:
        """Extract required Harness entities from the pipeline."""
        entities = []
        seen = set()

        # Project
        project_id = sanitize_identifier(pipeline.group)
        if project_id not in seen:
            seen.add(project_id)
            entities.append(Entity(
                type=EntityType.PROJECT,
                identifier=project_id,
                name=pipeline.group,
                api_creatable=True,
            ))

        # Connectors from git materials
        for mat in pipeline.git_materials:
            conn_id = "GitHub_Connector"
            if conn_id not in seen:
                seen.add(conn_id)
                entities.append(Entity(
                    type=EntityType.CONNECTOR,
                    identifier=conn_id,
                    name="GitHub Connector",
                    api_creatable=True,
                    dependencies=["Secret: github_ssh_key"],
                ))

        # Delegates from elastic profiles
        profiles = set()
        for stage in pipeline.stages:
            for job in stage.jobs:
                if job.elastic_profile_id:
                    profiles.add(job.elastic_profile_id)

        for profile in profiles:
            delegate_id = sanitize_identifier(profile)
            if delegate_id not in seen:
                seen.add(delegate_id)
                entities.append(Entity(
                    type=EntityType.DELEGATE,
                    identifier=f"{delegate_id}_delegate",
                    name=f"{profile} Delegate",
                    api_creatable=False,
                ))

        return entities
