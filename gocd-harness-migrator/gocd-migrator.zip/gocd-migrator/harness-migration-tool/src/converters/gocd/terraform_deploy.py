"""
Terraform Deploy Docker GoCD Converter.

Handles the `terraform_deploy_docker` pattern (16 pipelines): Docker image
build followed by Terraform plan/apply to deploy the containerised workload.

Typical GoCD structure:
  Stage 1: code-build     – Docker build, tag with git revision, push to ECR
  Stage 2: terraform-plan – Terraform plan (uses image ref from code-build)
  Stage 3: terraform-apply – Terraform apply with manual approval

The Harness output uses:
  - Custom stage with ShellScript steps for the Docker build stage
  - Custom stage with TerraformPlan + HarnessApproval + TerraformApply for
    the infrastructure deployment
  - Fetch artifact tasks become structured TODO stubs
  - fetch_config #{vault_path} → Harness secret expression references
"""

import re
from typing import List, Dict, Any, Optional, Tuple

from src.converters.base import BaseConverter
from src.converters.harness_builder import HarnessBuilder
from src.core.models import (
    GocdPipeline, GocdStage, GocdTask,
    ConversionResult, ConversionMethod, Entity, EntityType,
)
from src.validators.identifier import (
    sanitize_identifier, sanitize_step_name, convert_gocd_variables,
)


_TF_STAGE_RE = re.compile(
    r"terraform[_-]?(plan|apply)|tf[_-]?(plan|apply)", re.IGNORECASE
)
_BUILD_STAGE_RE = re.compile(
    r"code[_-]?build|docker[_-]?build|build[_-]?image|start[_-]?build", re.IGNORECASE
)


class TerraformDeployConverter(BaseConverter):
    """Converter for Docker Build + Terraform Deploy GoCD pipelines."""

    @property
    def converter_key(self) -> str:
        return "terraform_deploy"

    @property
    def supported_patterns(self) -> List[str]:
        return ["terraform_deploy_docker"]

    def convert(self, pipeline: GocdPipeline, pattern_id: str) -> ConversionResult:
        builder = HarnessBuilder()
        builder.reset_counter()

        result = ConversionResult(
            source_file="",
            source_pipeline_name=pipeline.name,
            source_type="gocd",
            pattern=None,
            conversion_method=ConversionMethod.RULE_BASED,
        )

        variables = builder.build_all_variables(pipeline)
        has_git = bool(pipeline.git_materials)
        delegate_selectors = builder.get_delegate_selectors(pipeline)

        provisioner_id = sanitize_identifier(pipeline.name) + "_tf"
        harness_stages = []
        has_ci_stage = False
        first_ci_stage = True

        for stage in pipeline.stages:
            is_build = bool(_BUILD_STAGE_RE.search(stage.name))
            is_tf = bool(_TF_STAGE_RE.search(stage.name))

            if is_build and not is_tf:
                if has_git:
                    ecr_info = self._extract_ecr_info(pipeline)
                    ci_steps = self._build_ci_steps_with_ecr(
                        stage, builder, pipeline, ecr_info,
                    )
                    if stage.approval and stage.approval.type == "manual":
                        harness_stages.append(builder.build_approval_stage(
                            name=f"Approve {stage.name}",
                            message=f"Review and approve stage: {stage.name}",
                            user_groups=self._resolve_user_groups(stage.approval),
                        ))
                    harness_stages.append(builder.build_ci_stage(
                        name=stage.name,
                        steps=ci_steps,
                        clone_codebase=first_ci_stage,
                        description=f"Docker Build – migrated from GoCD stage: {stage.name}",
                        delegate_selectors=delegate_selectors[:1] if delegate_selectors else None,
                    ))
                    has_ci_stage = True
                    first_ci_stage = False
                else:
                    h_stage = self._build_docker_stage(
                        stage, builder, pipeline, delegate_selectors,
                    )
                    harness_stages.append(h_stage)
            elif is_tf:
                is_plan = "plan" in stage.name.lower()
                h_stage = self._build_terraform_stage(
                    stage, builder, pipeline, provisioner_id,
                    is_plan=is_plan,
                    delegate_selectors=delegate_selectors,
                )
                harness_stages.append(h_stage)
            else:
                steps = self._build_generic_steps(stage, builder, pipeline)
                harness_stages.append(builder.build_custom_stage(
                    name=stage.name,
                    description=f"Migrated from GoCD stage: {stage.name}",
                    steps=steps,
                    delegate_selectors=delegate_selectors[:1] if delegate_selectors else None,
                ))

        codebase = builder.build_codebase(pipeline.git_materials[0]) if has_git and has_ci_stage else None

        pipeline_yaml = builder.build_pipeline(
            name=pipeline.name,
            group=pipeline.group,
            stages=harness_stages,
            variables=variables,
            codebase=codebase,
            description="Docker Build + Terraform Deploy pipeline migrated from GoCD",
        )

        triggers = self._build_triggers(pipeline, builder)
        if triggers:
            pipeline_yaml["_triggers"] = triggers

        result.harness_yaml = pipeline_yaml
        result.entities = self._extract_entities(pipeline, delegate_selectors)
        result.success = True
        return result

    # ------------------------------------------------------------------
    # Docker build stage
    # ------------------------------------------------------------------

    def _build_docker_stage(
        self,
        stage: GocdStage,
        builder: HarnessBuilder,
        pipeline: GocdPipeline,
        delegate_selectors: List[str],
    ) -> Dict[str, Any]:
        steps = self._build_generic_steps(stage, builder, pipeline)
        return builder.build_custom_stage(
            name=stage.name,
            description=f"Docker Build – migrated from GoCD stage: {stage.name}",
            steps=steps,
            delegate_selectors=delegate_selectors[:1] if delegate_selectors else None,
        )

    # ------------------------------------------------------------------
    # CI build steps with native BuildAndPushECR
    # ------------------------------------------------------------------

    _DOCKER_CMD_RE = re.compile(
        r"docker\s+(build|push|tag)|DOCKER_BUILDKIT|"
        r"ecr\s+get-login|image_ref|echo\s+\$\{?DOCKER_REGISTRY",
        re.IGNORECASE,
    )

    def _build_ci_steps_with_ecr(
        self,
        stage: GocdStage,
        builder: HarnessBuilder,
        pipeline: GocdPipeline,
        ecr_info: Dict[str, str],
    ) -> List[Dict[str, Any]]:
        """Build CI steps replacing manual docker build/push with native BuildAndPushECR."""
        pre_steps: List[Dict[str, Any]] = []
        found_docker = False

        for job in stage.jobs:
            for task in job.tasks:
                if task.type == "fetch":
                    pre_steps.append(self._build_fetch_run_step(task, builder))
                    continue
                if task.type != "exec":
                    continue

                script = self._extract_script(task)
                if self._DOCKER_CMD_RE.search(script):
                    found_docker = True
                    continue

                name = sanitize_step_name(
                    self._infer_step_name(script) or self._default_step_name(task)
                )
                builder._step_counter += 1
                pre_steps.append({
                    "step": {
                        "type": "Run",
                        "name": name,
                        "identifier": f"run_{builder._step_counter}",
                        "spec": {
                            "connectorRef": "account.haborBuilderConnector",
                            "image": "ubuntu:latest",
                            "shell": "Sh",
                            "command": convert_gocd_variables(
                                self._annotate_fetch_config(script)
                            ),
                        },
                    }
                })

        if found_docker and ecr_info.get("account"):
            pre_steps.append({
                "step": {
                    "type": "BuildAndPushECR",
                    "name": "Build and Push to ECR",
                    "identifier": "BuildandPushtoECR",
                    "spec": {
                        "connectorRef": "account.aws_connector",
                        "region": ecr_info.get("region", "ap-south-1"),
                        "account": ecr_info["account"],
                        "imageName": ecr_info.get("image_name", pipeline.name),
                        "tags": ["<+codebase.commitSha>"],
                    },
                }
            })
        elif found_docker:
            pre_steps.append({
                "step": {
                    "type": "BuildAndPushECR",
                    "name": "Build and Push to ECR",
                    "identifier": "BuildandPushtoECR",
                    "spec": {
                        "connectorRef": "account.aws_connector",
                        "region": "<+input>",
                        "account": "<+input>",
                        "imageName": pipeline.name,
                        "tags": ["<+codebase.commitSha>"],
                    },
                }
            })

        return pre_steps

    def _extract_ecr_info(self, pipeline: GocdPipeline) -> Dict[str, str]:
        """Extract ECR account, region, and image name from pipeline env vars."""
        info: Dict[str, str] = {}
        registry = pipeline.environment_variables.get("DOCKER_REGISTRY", "")
        image_name = pipeline.environment_variables.get("IMAGE_NAME", "")

        if registry:
            match = re.match(r"^(\d+)\.dkr\.ecr\.([\w-]+)\.", registry)
            if match:
                info["account"] = match.group(1)
                info["region"] = match.group(2)
        if image_name:
            info["image_name"] = image_name

        return info

    # ------------------------------------------------------------------
    # Terraform stages (plan / apply)
    # ------------------------------------------------------------------

    def _build_terraform_stage(
        self,
        stage: GocdStage,
        builder: HarnessBuilder,
        pipeline: GocdPipeline,
        provisioner_id: str,
        is_plan: bool,
        delegate_selectors: List[str],
    ) -> Dict[str, Any]:
        steps: List[Dict[str, Any]] = []

        for job in stage.jobs:
            for task in job.tasks:
                if task.type == "fetch":
                    steps.append(self._build_fetch_step(task, builder))

        # Pre-plan script steps (copy artifacts, set branches, etc.)
        pre_steps = self._extract_pre_terraform_scripts(stage)
        if pre_steps:
            steps.append(builder.build_shell_step(
                name=sanitize_step_name(f"Prepare {stage.name}"),
                script=convert_gocd_variables("\n".join(pre_steps)),
            ))

        if is_plan:
            steps.append(builder.build_terraform_plan_step(
                provisioner_id=provisioner_id,
                command="Apply",
            ))
        else:
            if stage.approval and stage.approval.type == "manual":
                groups = self._resolve_user_groups(stage.approval)
                steps.append(builder.build_approval_step(
                    name=f"Approve {stage.name}",
                    message=f"Review Terraform plan and approve apply for {pipeline.name}",
                    user_groups=groups,
                ))
            steps.append(builder.build_terraform_apply_step(
                provisioner_id=provisioner_id,
            ))

        return builder.build_custom_stage(
            name=stage.name,
            description=f"Terraform {('Plan' if is_plan else 'Apply')} – {stage.name}",
            steps=steps,
            delegate_selectors=delegate_selectors[:1] if delegate_selectors else None,
        )

    def _extract_pre_terraform_scripts(self, stage: GocdStage) -> List[str]:
        """Extract shell commands that run before the actual Terraform plan/apply."""
        scripts = []
        for job in stage.jobs:
            for task in job.tasks:
                if task.type != "exec":
                    continue
                s = self._extract_script(task)
                if re.search(r"terraform\s+(plan|apply|init|destroy)", s, re.IGNORECASE):
                    continue
                scripts.append(s)
        return scripts

    # ------------------------------------------------------------------
    # Generic shell steps
    # ------------------------------------------------------------------

    def _build_generic_steps(
        self,
        stage: GocdStage,
        builder: HarnessBuilder,
        pipeline: GocdPipeline,
    ) -> List[Dict[str, Any]]:
        steps: List[Dict[str, Any]] = []

        if stage.approval and stage.approval.type == "manual":
            groups = self._resolve_user_groups(stage.approval)
            steps.append(builder.build_approval_step(
                name=f"Approve {stage.name}",
                message=f"Review and approve stage: {stage.name} for pipeline {pipeline.name}",
                user_groups=groups,
            ))

        for job in stage.jobs:
            tasks = job.tasks
            i = 0
            while i < len(tasks):
                task = tasks[i]

                if task.type == "fetch":
                    steps.append(self._build_fetch_step(task, builder))
                    i += 1
                    continue

                if task.type != "exec":
                    steps.append(builder.build_shell_step(
                        name=sanitize_step_name(f"Unknown task {task.type}"),
                        script=f"# TODO: Manually convert task type '{task.type}'",
                    ))
                    i += 1
                    continue

                script = self._extract_script(task)

                merged, consumed = self._try_merge_git_preamble(tasks, i)
                if consumed > 1:
                    name = sanitize_step_name(
                        self._infer_step_name(merged) or "Git Checkout"
                    )
                    steps.append(builder.build_shell_step(
                        name=name,
                        script=convert_gocd_variables(self._annotate_fetch_config(merged)),
                    ))
                    i += consumed
                    continue

                name = sanitize_step_name(
                    self._infer_step_name(script) or self._default_step_name(task)
                )
                steps.append(builder.build_shell_step(
                    name=name,
                    script=convert_gocd_variables(self._annotate_fetch_config(script)),
                ))
                i += 1

        return steps

    # ------------------------------------------------------------------
    # Fetch task stubs
    # ------------------------------------------------------------------

    def _build_fetch_run_step(self, task: GocdTask, builder: HarnessBuilder) -> Dict[str, Any]:
        """Build a CI-compatible Run step for fetch artifact stubs."""
        pipeline_ref = convert_gocd_variables(task.fetch_pipeline) if task.fetch_pipeline else "(same pipeline)"
        source = task.fetch_source or "artifact"
        dest = task.fetch_destination or ""

        script = (
            f"# Artifact fetch from upstream pipeline\n"
            f"# Source pipeline: {pipeline_ref}\n"
            f"# Stage: {task.fetch_stage} / Job: {task.fetch_job}\n"
            f"# File: {source}\n"
        )
        if dest:
            script += f"# Destination: {dest}\n"
        script += (
            f"#\n"
            f"# Harness migration options:\n"
            f"#   1. Use output variables from the upstream pipeline trigger\n"
            f"#   2. Store in S3/GCS and fetch via shell script\n"
            f"#   3. Use Harness Artifact Source with pipeline chaining\n"
            f'echo "TODO: Fetch {source} from {pipeline_ref}"\n'
        )

        builder._step_counter += 1
        return {
            "step": {
                "type": "Run",
                "name": sanitize_step_name(f"Fetch {source}"),
                "identifier": f"run_{builder._step_counter}",
                "spec": {
                    "connectorRef": "account.haborBuilderConnector",
                    "image": "ubuntu:latest",
                    "shell": "Sh",
                    "command": script,
                },
                "timeout": "5m",
            }
        }

    def _build_fetch_step(self, task: GocdTask, builder: HarnessBuilder) -> Dict[str, Any]:
        pipeline_ref = convert_gocd_variables(task.fetch_pipeline) if task.fetch_pipeline else "(same pipeline)"
        source = task.fetch_source or "artifact"
        dest = task.fetch_destination or ""

        script = (
            f"# Artifact fetch from upstream pipeline\n"
            f"# Source pipeline: {pipeline_ref}\n"
            f"# Stage: {task.fetch_stage} / Job: {task.fetch_job}\n"
            f"# File: {source}\n"
        )
        if dest:
            script += f"# Destination: {dest}\n"
        script += (
            f"#\n"
            f"# Harness migration options:\n"
            f"#   1. Use output variables from the upstream pipeline trigger\n"
            f"#   2. Store in S3/GCS and fetch via shell script\n"
            f"#   3. Use Harness Artifact Source with pipeline chaining\n"
            f'echo "TODO: Fetch {source} from {pipeline_ref}"\n'
        )

        return builder.build_shell_step(
            name=sanitize_step_name(f"Fetch {source}"),
            script=script,
            timeout="5m",
        )

    # ------------------------------------------------------------------
    # Script helpers
    # ------------------------------------------------------------------

    def _extract_script(self, task: GocdTask) -> str:
        if task.command in ("bash", "sh") and len(task.arguments) >= 2 and task.arguments[0] == "-c":
            script = " ".join(task.arguments[1:])
        elif task.arguments:
            script = f"{task.command} {' '.join(task.arguments)}"
        else:
            script = task.command

        if task.working_directory:
            wd = convert_gocd_variables(task.working_directory)
            script = f"cd {wd} && {script}"
        return script

    def _annotate_fetch_config(self, script: str) -> str:
        def _replace(m):
            path = m.group(1)
            return (
                f"# fetch_config: vault path = {path}\n"
                f"# TODO: Map to Harness Secret Manager → secrets.getValue(\"<secret_id>\")\n"
                f"{m.group(0)}"
            )
        return re.sub(r"(?:\.?\s*)?fetch_config\s+([\w/\-#{}.]+)", _replace, script)

    def _try_merge_git_preamble(self, tasks, start_idx) -> Tuple[str, int]:
        git_cmds = re.compile(r"git\s+(fetch|reset|checkout|pull)", re.IGNORECASE)
        scripts = []
        i = start_idx
        while i < len(tasks) and tasks[i].type == "exec":
            s = self._extract_script(tasks[i])
            if i == start_idx or git_cmds.search(s):
                scripts.append(s)
                i += 1
            else:
                break
        if len(scripts) > 1:
            return "\n".join(scripts), len(scripts)
        return scripts[0] if scripts else "", 1

    _STEP_HINTS = [
        (r"docker\s+build|DOCKER_BUILDKIT", "Docker Build"),
        (r"docker\s+push|ecr.*push", "Docker Push"),
        (r"aws\s+ecr\s+get-login|ecr.*login", "ECR Login"),
        (r"docker\s+tag", "Docker Tag"),
        (r"cw_repo_revision|git\s+rev-parse", "Get Git Revision"),
        (r"image_ref", "Build Image Reference"),
        (r"terraform\s+(plan|apply|init)", "Terraform"),
        (r"fetch_config", "Fetch Secrets"),
        (r"git\s+fetch.*git\s+reset|git\s+checkout", "Git Checkout"),
        (r"cp\s+.*tfplan|tfplan", "Copy Terraform Plan"),
        (r"cp\s+.*timestamp|timestamp", "Copy Timestamp"),
    ]

    def _infer_step_name(self, script: str) -> Optional[str]:
        for regex, label in self._STEP_HINTS:
            if re.search(regex, script, re.IGNORECASE):
                return label
        return None

    def _default_step_name(self, task: GocdTask) -> str:
        if task.arguments:
            hint = " ".join(task.arguments[:2])[:50]
            return sanitize_step_name(f"Execute {hint}")
        return sanitize_step_name(f"Execute {task.command[:50]}")

    # ------------------------------------------------------------------
    # User groups
    # ------------------------------------------------------------------

    def _resolve_user_groups(self, approval) -> List[str]:
        groups = []
        if approval.roles:
            groups = [f"account.{sanitize_identifier(r)}" for r in approval.roles]
        if approval.users:
            groups.extend([f"account.{sanitize_identifier(u)}" for u in approval.users])
        return groups or ["account.Admin"]

    # ------------------------------------------------------------------
    # Triggers
    # ------------------------------------------------------------------

    def _build_triggers(self, pipeline: GocdPipeline, builder: HarnessBuilder) -> List[Dict]:
        triggers = []
        if pipeline.timer:
            triggers.append(builder.build_cron_trigger(pipeline.timer, pipeline.name))

        for mat in pipeline.pipeline_materials:
            if mat.name:
                upstream_param = pipeline.parameters.get("upstream_pipeline", "")
                upstream = convert_gocd_variables(upstream_param) if upstream_param else mat.name
                triggers.append({
                    "trigger": {
                        "name": f"{pipeline.name}_on_{sanitize_identifier(upstream)}",
                        "identifier": sanitize_identifier(f"{pipeline.name}_on_{upstream}"),
                        "type": "Pipeline",
                        "spec": {
                            "type": "Pipeline",
                            "spec": {
                                "pipelineIdentifier": sanitize_identifier(upstream),
                                "stageName": "<+input>",
                                "event": "OnSuccess",
                            },
                        },
                        "pipelineIdentifier": sanitize_identifier(pipeline.name),
                    }
                })
        return triggers

    # ------------------------------------------------------------------
    # Entities
    # ------------------------------------------------------------------

    def _extract_entities(self, pipeline: GocdPipeline, delegate_selectors: List[str]) -> List[Entity]:
        entities: List[Entity] = []

        entities.append(Entity(
            type=EntityType.PROJECT,
            identifier=sanitize_identifier(pipeline.group),
            name=pipeline.group,
            payload={"orgIdentifier": "default"},
        ))

        if pipeline.git_materials:
            entities.append(Entity(
                type=EntityType.CONNECTOR,
                identifier="GitHub_Connector",
                name="GitHub Connector",
                payload={"type": "Github", "spec": {"url": pipeline.git_materials[0].url}},
            ))

        entities.append(Entity(
            type=EntityType.CONNECTOR,
            identifier="AWS_Connector",
            name="AWS Connector (ECR + Terraform)",
            payload={"type": "Aws", "spec": {"credential": {"type": "ManualConfig"}}},
        ))

        ecr_registry = pipeline.environment_variables.get("DOCKER_REGISTRY", "")
        if ecr_registry:
            entities.append(Entity(
                type=EntityType.CONNECTOR,
                identifier="ECR_Connector",
                name=f"ECR Connector ({ecr_registry})",
                payload={"type": "Aws", "spec": {"credential": {"type": "ManualConfig"}}},
            ))

        for sel in delegate_selectors:
            entities.append(Entity(
                type=EntityType.DELEGATE,
                identifier=sanitize_identifier(sel),
                name=f"{sel} Delegate",
                payload={"tags": [sel]},
            ))

        for stage in pipeline.stages:
            if stage.approval and stage.approval.type == "manual":
                for role in (stage.approval.roles or []):
                    entities.append(Entity(
                        type=EntityType.USER_GROUP,
                        identifier=sanitize_identifier(role),
                        name=f"{role} User Group",
                        payload={"accountIdentifier": "<+account.identifier>"},
                    ))

        return entities
