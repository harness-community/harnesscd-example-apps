"""
Ops/Script GoCD Converter.

Handles 10 operational sub-patterns:
  flink_infra, s3_data_copy, country_onboarding, telegraf_monitoring,
  trigger_pipeline, cms_copy, ddb_scale, incident_report, ml_pipeline, sonar_quality

All produce Custom stages with ShellScript steps, but with pattern-aware
enhancements over the generic fallback:
  - Context-aware step naming (e.g. "Scale DynamoDB" instead of "Execute: bash")
  - fetch_config #{vault} → Harness secret expression references
  - Cron timers → full Harness Scheduled trigger YAML
  - Pipeline dependencies → Harness pipeline trigger YAML
  - GoCD approval roles → mapped to Harness user groups
  - Fetch artifact tasks → structured TODO stubs with upstream context
"""

import re
from typing import List, Dict, Any, Optional, Tuple

from src.converters.base import BaseConverter
from src.converters.harness_builder import HarnessBuilder
from src.core.models import (
    GocdPipeline, GocdStage, GocdTask, GocdJob,
    ConversionResult, ConversionMethod, Entity, EntityType,
)
from src.validators.identifier import sanitize_identifier, sanitize_step_name, convert_gocd_variables

# Maps sub-pattern → human-readable label used in stage/step descriptions
PATTERN_LABELS: Dict[str, str] = {
    "flink_infra": "Flink Infrastructure",
    "s3_data_copy": "S3 Data Copy",
    "country_onboarding": "Country Onboarding",
    "telegraf_monitoring": "Telegraf Monitoring",
    "trigger_pipeline": "Trigger Downstream",
    "cms_copy": "CMS Sync",
    "ddb_scale": "DynamoDB Scale",
    "incident_report": "Incident Report",
    "ml_pipeline": "ML Pipeline",
    "sonar_quality": "Code Quality",
}

# Regex fragments for generating smart step names
_STEP_NAME_HINTS: List[Tuple[str, str]] = [
    (r"auto_scale\.py", "Scale DynamoDB"),
    (r"docker\s+build", "Docker Build"),
    (r"docker\s+push", "Docker Push"),
    (r"aws\s+s3\s+cp", "S3 Copy"),
    (r"aws\s+s3\s+sync", "S3 Sync"),
    (r"copy_cms|copy_all_cms", "CMS Copy"),
    (r"copy_tf_serving", "Copy TF Serving Models"),
    (r"sonar-scanner|sonar\.sh", "Sonar Analysis"),
    (r"incidents_analytics", "Generate Report"),
    (r"setup_churn_pred|offline_prediction", "ML Pipeline Setup"),
    (r"add_new_country_config", "Country Config Update"),
    (r"manage\.sh.*telegraf|telegraf.*manage", "Telegraf Management"),
    (r"build_telegraf", "Telegraf Build"),
    (r"helm3?\s+", "Helm Deploy"),
    (r"terraform\s+init|terraform\s+apply|terraform\s+plan", "Terraform"),
    (r"kubectl\s+", "Kubectl"),
    (r"flink.*submit|submit.*flink", "Flink Submit Job"),
    (r"flink.*cancel|cancel.*flink", "Flink Cancel Job"),
    (r"flink.*savepoint|savepoint", "Flink Savepoint"),
    (r"flink.*upload|upload.*jar", "Flink Upload JAR"),
    (r"make\s+test", "Run Tests"),
    (r"pip\s+install|pip3\s+install", "Install Dependencies"),
    (r"git\s+fetch.*git\s+reset|git\s+checkout", "Git Checkout"),
    (r"fetch_config", "Fetch Secrets"),
]


class OpsScriptConverter(BaseConverter):
    """Converter for operational and script-driven GoCD pipelines."""

    @property
    def converter_key(self) -> str:
        return "ops_script"

    @property
    def supported_patterns(self) -> List[str]:
        return [
            "flink_infra", "s3_data_copy", "country_onboarding",
            "telegraf_monitoring", "trigger_pipeline", "cms_copy",
            "ddb_scale", "incident_report", "ml_pipeline", "sonar_quality",
        ]

    def convert(self, pipeline: GocdPipeline, pattern_id: str) -> ConversionResult:
        builder = HarnessBuilder()
        builder.reset_counter()

        result = ConversionResult(
            source_file="",
            source_pipeline_name=pipeline.name,
            source_type="gocd",
            pattern=None,
            conversion_method=ConversionMethod.RULE_BASED,
        )

        label = PATTERN_LABELS.get(pattern_id, "Ops Script")
        variables = builder.build_all_variables(pipeline)
        has_git = bool(pipeline.git_materials)
        codebase = builder.build_codebase(pipeline.git_materials[0]) if has_git else None
        delegate_selectors = builder.get_delegate_selectors(pipeline)

        harness_stages = []
        first_ci_stage = True

        for stage in pipeline.stages:
            steps = self._build_stage_steps(stage, builder, pipeline, pattern_id)

            if has_git:
                approval_steps, ci_steps = builder.split_steps_for_ci(steps)
                if approval_steps:
                    harness_stages.append(builder.build_approval_stage(
                        name=f"Approve {stage.name}",
                        message=f"Review and approve stage: {stage.name} for pipeline {pipeline.name}",
                        user_groups=self._resolve_user_groups(
                            stage.approval.roles if stage.approval else []
                        ),
                    ))
                if ci_steps:
                    harness_stages.append(builder.build_ci_stage(
                        name=stage.name,
                        steps=ci_steps,
                        clone_codebase=first_ci_stage,
                        description=f"{label} – migrated from GoCD stage: {stage.name}",
                        delegate_selectors=delegate_selectors[:1] if delegate_selectors else None,
                    ))
                    first_ci_stage = False
            else:
                harness_stages.append(builder.build_custom_stage(
                    name=stage.name,
                    description=f"{label} – migrated from GoCD stage: {stage.name}",
                    steps=steps,
                    delegate_selectors=delegate_selectors[:1] if delegate_selectors else None,
                ))

        harness_yaml = builder.build_pipeline(
            name=pipeline.name,
            group=pipeline.group,
            stages=harness_stages,
            variables=variables if variables else None,
            codebase=codebase,
        )

        # Cron trigger
        if pipeline.timer:
            trigger = builder.build_cron_trigger(pipeline.timer, pipeline.name)
            harness_yaml["_triggers"] = [trigger]
            result.warnings.append(
                f"Cron schedule detected ({pipeline.timer.spec}). "
                f"A Harness Scheduled trigger definition is included in _triggers."
            )

        # Pipeline dependency triggers
        for mat in pipeline.pipeline_materials:
            dep_name = convert_gocd_variables(mat.pipeline)
            dep_stage = mat.stage
            trigger = self._build_pipeline_trigger(pipeline.name, dep_name, dep_stage)
            harness_yaml.setdefault("_triggers", []).append(trigger)
            result.warnings.append(
                f"Upstream dependency: '{dep_name}' (stage: {dep_stage}). "
                f"A Harness pipeline trigger is included in _triggers."
            )

        result.entities = self._extract_entities(pipeline, pattern_id)
        result.harness_yaml = harness_yaml
        result.success = True
        return result

    # ------------------------------------------------------------------
    # Stage / Step building
    # ------------------------------------------------------------------

    def _build_stage_steps(
        self,
        stage: GocdStage,
        builder: HarnessBuilder,
        pipeline: GocdPipeline,
        pattern_id: str,
    ) -> List[Dict[str, Any]]:
        steps: List[Dict[str, Any]] = []

        # Approval step (if manual)
        if stage.approval and stage.approval.type == "manual":
            user_groups = self._resolve_user_groups(stage.approval.roles)
            steps.append(builder.build_approval_step(
                name=f"Approve {stage.name}",
                message=f"Review and approve stage: {stage.name} for pipeline {pipeline.name}",
                user_groups=user_groups,
            ))

        # Convert tasks
        for job in stage.jobs:
            steps.extend(self._convert_job_tasks(job, builder, pattern_id))

        return steps

    def _convert_job_tasks(
        self,
        job: GocdJob,
        builder: HarnessBuilder,
        pattern_id: str,
    ) -> List[Dict[str, Any]]:
        steps: List[Dict[str, Any]] = []

        # Merge consecutive exec tasks into logical groups where possible
        i = 0
        tasks = job.tasks
        while i < len(tasks):
            task = tasks[i]

            if task.type == "fetch":
                steps.append(builder.fetch_task_to_comment_step(task))
                i += 1
                continue

            if task.type != "exec":
                steps.append(builder.build_shell_step(
                    name=sanitize_step_name(f"Unknown task {task.type}"),
                    script=f"# TODO: Manually convert task type '{task.type}'\n# Raw: {task.raw}",
                ))
                i += 1
                continue

            script = self._extract_script(task)

            # Try to merge with subsequent git-fetch/checkout tasks into a single step
            merged_script, consumed = self._try_merge_git_preamble(tasks, i)
            if consumed > 1:
                raw_name = self._infer_step_name(merged_script, pattern_id) or f"Execute {stage_hint(task)}"
                step_name = sanitize_step_name(raw_name)
                steps.append(builder.build_shell_step(
                    name=step_name,
                    script=convert_gocd_variables(merged_script),
                ))
                i += consumed
                continue

            step_name = sanitize_step_name(
                self._infer_step_name(script, pattern_id) or f"Execute {stage_hint(task)}"
            )
            steps.append(builder.build_shell_step(
                name=step_name,
                script=convert_gocd_variables(self._rewrite_fetch_config(script)),
            ))
            i += 1

        return steps

    # ------------------------------------------------------------------
    # Script extraction and rewriting
    # ------------------------------------------------------------------

    def _extract_script(self, task: GocdTask) -> str:
        """Pull the actual script content from a GoCD exec task."""
        if task.command in ("bash", "sh") and len(task.arguments) >= 2 and task.arguments[0] == "-c":
            script = " ".join(task.arguments[1:])
        elif task.arguments:
            script = f"{task.command} {' '.join(task.arguments)}"
        else:
            script = task.command

        if task.working_directory:
            script = f"cd {convert_gocd_variables(task.working_directory)} && {script}"
        return script

    def _rewrite_fetch_config(self, script: str) -> str:
        """Convert GoCD `. fetch_config #{vault_path}` to a Harness-compatible comment + export."""
        pattern = r'\.\s+fetch_config\s+(\S+)'
        match = re.search(pattern, script)
        if not match:
            return script

        vault_ref = match.group(1)
        replacement = (
            f"# fetch_config replaced – original vault path: {vault_ref}\n"
            f"# TODO: Map vault secrets to Harness Secret Manager references\n"
            f"# Example: export SECRET_VAR=<+secrets.getValue(\"vault_secret_name\")>\n"
            f". fetch_config {vault_ref}"
        )
        return re.sub(pattern, replacement, script, count=1)

    def _try_merge_git_preamble(
        self, tasks: List[GocdTask], start: int
    ) -> Tuple[str, int]:
        """Merge consecutive git-fetch + git-reset/checkout + main-command into one script."""
        scripts = []
        consumed = 0
        for idx in range(start, min(start + 4, len(tasks))):
            t = tasks[idx]
            if t.type != "exec":
                break
            s = self._extract_script(t)
            scripts.append(s)
            consumed += 1
            # Stop merging after first non-git command
            if not re.search(r'git\s+(fetch|reset|checkout|pull)', s):
                break

        if consumed <= 1:
            return scripts[0] if scripts else "", 1

        return "\n".join(scripts), consumed

    # ------------------------------------------------------------------
    # Step naming
    # ------------------------------------------------------------------

    def _infer_step_name(self, script: str, pattern_id: str) -> Optional[str]:
        """Derive a meaningful step name from the script content."""
        for regex, label in _STEP_NAME_HINTS:
            if re.search(regex, script, re.IGNORECASE):
                return label
        return None

    # ------------------------------------------------------------------
    # User group mapping
    # ------------------------------------------------------------------

    def _resolve_user_groups(self, roles: List[str]) -> List[str]:
        if not roles:
            return ["account.Admin"]
        return [f"account.{sanitize_identifier(r)}" for r in roles]

    # ------------------------------------------------------------------
    # Pipeline trigger
    # ------------------------------------------------------------------

    def _build_pipeline_trigger(
        self, pipeline_name: str, upstream_name: str, upstream_stage: str
    ) -> Dict[str, Any]:
        return {
            "trigger": {
                "name": f"{pipeline_name}_on_{sanitize_identifier(upstream_name)}",
                "identifier": sanitize_identifier(f"{pipeline_name}_on_{upstream_name}"),
                "type": "Pipeline",
                "spec": {
                    "type": "Pipeline",
                    "spec": {
                        "pipelineIdentifier": sanitize_identifier(upstream_name),
                        "stageName": upstream_stage,
                        "event": "OnSuccess",
                    },
                },
                "pipelineIdentifier": sanitize_identifier(pipeline_name),
            }
        }

    # ------------------------------------------------------------------
    # Entity extraction
    # ------------------------------------------------------------------

    def _extract_entities(
        self, pipeline: GocdPipeline, pattern_id: str
    ) -> List[Entity]:
        entities: List[Entity] = []
        seen: set = set()

        # Project
        proj_id = sanitize_identifier(pipeline.group)
        if proj_id not in seen:
            seen.add(proj_id)
            entities.append(Entity(
                type=EntityType.PROJECT,
                identifier=proj_id,
                name=pipeline.group,
                api_creatable=True,
            ))

        # GitHub Connector
        if pipeline.git_materials and "GitHub_Connector" not in seen:
            seen.add("GitHub_Connector")
            entities.append(Entity(
                type=EntityType.CONNECTOR,
                identifier="GitHub_Connector",
                name="GitHub Connector",
                api_creatable=True,
                dependencies=["Secret: github_ssh_key"],
            ))

        # AWS Connector (for s3_data_copy, ddb_scale, flink_infra, cms_copy, ml_pipeline)
        aws_patterns = {"s3_data_copy", "ddb_scale", "flink_infra", "cms_copy", "ml_pipeline"}
        if pattern_id in aws_patterns and "AWS_Connector" not in seen:
            seen.add("AWS_Connector")
            entities.append(Entity(
                type=EntityType.CONNECTOR,
                identifier="AWS_Connector",
                name="AWS Cloud Connector",
                api_creatable=True,
                dependencies=["Secret: aws_access_key (or use IRSA/cross-account role)"],
            ))

        # Delegates from elastic profiles
        profiles: set = set()
        for stage in pipeline.stages:
            for job in stage.jobs:
                if job.elastic_profile_id:
                    profiles.add(job.elastic_profile_id)

        for profile in profiles:
            d_id = sanitize_identifier(profile)
            if d_id not in seen:
                seen.add(d_id)
                entities.append(Entity(
                    type=EntityType.DELEGATE,
                    identifier=f"{d_id}_delegate",
                    name=f"{profile} Delegate",
                    api_creatable=False,
                ))

        # User Groups from approval roles
        for stage in pipeline.stages:
            if stage.approval and stage.approval.type == "manual":
                for role in stage.approval.roles:
                    ug_id = sanitize_identifier(role)
                    if ug_id not in seen:
                        seen.add(ug_id)
                        entities.append(Entity(
                            type=EntityType.USER_GROUP,
                            identifier=ug_id,
                            name=f"{role} User Group",
                            api_creatable=True,
                        ))

        # Vault / Secret references
        all_scripts = pipeline.all_scripts
        if "fetch_config" in all_scripts:
            vault_paths = set()
            for task in pipeline.all_tasks:
                if task.type == "exec":
                    s = " ".join(task.arguments)
                    for m in re.finditer(r'fetch_config\s+(\S+)', s):
                        vault_paths.add(m.group(1))
            for vp in vault_paths:
                clean = convert_gocd_variables(vp)
                s_id = sanitize_identifier(clean.replace("/", "_").replace("<+", "").replace(">", ""))
                if s_id not in seen:
                    seen.add(s_id)
                    entities.append(Entity(
                        type=EntityType.SECRET,
                        identifier=s_id,
                        name=f"Vault secret: {clean}",
                        api_creatable=False,
                        manual_instructions=(
                            f"Create a Harness Secret referencing vault path: {clean}. "
                            f"Use Harness Secret Manager with HashiCorp Vault connector."
                        ),
                    ))

        return entities


def stage_hint(task: GocdTask) -> str:
    """Short hint for default step name."""
    if task.arguments:
        full = " ".join(task.arguments[:2])
        return full[:50] if len(full) > 50 else full
    return task.command[:50]
