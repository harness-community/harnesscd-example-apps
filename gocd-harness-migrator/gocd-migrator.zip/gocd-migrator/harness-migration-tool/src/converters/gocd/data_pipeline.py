"""
Data Pipeline GoCD Converter.

Handles the `data_pipeline` pattern (92 pipelines): offline data pipeline
deployments including StepFunctions, Airflow, ETL, ML training, and data
copy workflows.

These pipelines are characterised by:
  - Heavy pipeline dependencies (cornerstone, s3_bucket, rds-terraform, builds)
  - Numerous fetch tasks pulling env files from upstream pipelines
  - deploy.sh / deploy_etl.sh / manage.sh scripts in offline/ subdirectories
  - fetch_config for Vault secrets
  - Manual approvals with personalisation-user role

All produce Custom stages with ShellScript steps, with data-pipeline-aware
step naming, full trigger generation for upstream dependencies, and fetch
task stubs that document the original artifact chain.
"""

import re
from typing import List, Dict, Any, Optional, Tuple

from src.converters.base import BaseConverter
from src.converters.harness_builder import HarnessBuilder
from src.core.models import (
    GocdPipeline, GocdStage, GocdJob, GocdTask,
    ConversionResult, ConversionMethod, Entity, EntityType,
)
from src.validators.identifier import sanitize_identifier, sanitize_step_name, convert_gocd_variables

_STEP_NAME_HINTS: List[Tuple[str, str]] = [
    (r"deploy_etl\.sh", "Deploy ETL Pipeline"),
    (r"deploy\.sh", "Deploy Data Pipeline"),
    (r"manage\.sh\s+\S+\s+plan", "Terraform Plan"),
    (r"manage\.sh\s+\S+\s+apply", "Terraform Apply"),
    (r"manage\.sh", "Terraform Manage"),
    (r"stepfunctions?\s+create-state-machine", "Create StepFunction"),
    (r"stepfunctions?\s+update-state-machine", "Update StepFunction"),
    (r"stepfunctions?\s+start-execution", "Trigger StepFunction"),
    (r"airflow\s+", "Airflow Deploy"),
    (r"docker\s+build", "Docker Build"),
    (r"docker\s+push", "Docker Push"),
    (r"build_.*_img\.sh|build\.sh|build_image", "Build Image"),
    (r"aws\s+s3\s+cp", "S3 Copy"),
    (r"aws\s+s3\s+sync", "S3 Sync"),
    (r"fetch_config", "Fetch Secrets"),
    (r"pip\s+install|pip3\s+install", "Install Dependencies"),
    (r"git\s+fetch.*git\s+reset|git\s+checkout", "Git Checkout"),
    (r"python3?\s+-m\s+", "Run Python Module"),
    (r"make\s+", "Make"),
]


class DataPipelineConverter(BaseConverter):
    """Converter for offline data pipeline GoCD pipelines."""

    @property
    def converter_key(self) -> str:
        return "data_pipeline"

    @property
    def supported_patterns(self) -> List[str]:
        return ["data_pipeline"]

    def convert(self, pipeline: GocdPipeline, pattern_id: str) -> ConversionResult:
        builder = HarnessBuilder()
        builder.reset_counter()

        result = ConversionResult(
            source_file="",
            source_pipeline_name=pipeline.name,
            source_type="gocd",
            pattern=None,
            conversion_method=ConversionMethod.RULE_BASED,
        )

        variables = builder.build_all_variables(pipeline)
        has_git = bool(pipeline.git_materials)
        codebase = builder.build_codebase(pipeline.git_materials[0]) if has_git else None
        delegate_selectors = builder.get_delegate_selectors(pipeline)

        harness_stages = []
        first_ci_stage = True

        for stage in pipeline.stages:
            steps = self._build_stage_steps(stage, builder, pipeline)

            if has_git:
                approval_steps, ci_steps = builder.split_steps_for_ci(steps)
                if approval_steps:
                    harness_stages.append(builder.build_approval_stage(
                        name=f"Approve {stage.name}",
                        message=f"Review and approve stage: {stage.name} for pipeline {pipeline.name}",
                        user_groups=self._resolve_user_groups(stage.approval) if stage.approval else ["account.Admin"],
                    ))
                if ci_steps:
                    harness_stages.append(builder.build_ci_stage(
                        name=stage.name,
                        steps=ci_steps,
                        clone_codebase=first_ci_stage,
                        description=f"Data Pipeline – migrated from GoCD stage: {stage.name}",
                        delegate_selectors=delegate_selectors[:1] if delegate_selectors else None,
                    ))
                    first_ci_stage = False
            else:
                harness_stages.append(builder.build_custom_stage(
                    name=stage.name,
                    description=f"Data Pipeline – migrated from GoCD stage: {stage.name}",
                    steps=steps,
                    delegate_selectors=delegate_selectors[:1] if delegate_selectors else None,
                ))

        harness_yaml = builder.build_pipeline(
            name=pipeline.name,
            group=pipeline.group,
            stages=harness_stages,
            variables=variables if variables else None,
            codebase=codebase,
        )

        # Cron trigger
        if pipeline.timer:
            trigger = builder.build_cron_trigger(pipeline.timer, pipeline.name)
            harness_yaml["_triggers"] = [trigger]
            result.warnings.append(
                f"Cron schedule detected ({pipeline.timer.spec}). "
                f"A Harness Scheduled trigger is included in _triggers."
            )

        # Pipeline dependency triggers
        for mat in pipeline.pipeline_materials:
            dep_name = convert_gocd_variables(mat.pipeline)
            trigger = self._build_pipeline_trigger(pipeline.name, dep_name, mat.stage)
            harness_yaml.setdefault("_triggers", []).append(trigger)
            result.warnings.append(
                f"Upstream dependency: '{dep_name}' (stage: {mat.stage}). "
                f"A Harness pipeline trigger is included in _triggers."
            )

        result.entities = self._extract_entities(pipeline)
        result.harness_yaml = harness_yaml
        result.success = True
        return result

    # ------------------------------------------------------------------
    # Stage / Step building
    # ------------------------------------------------------------------

    def _build_stage_steps(
        self,
        stage: GocdStage,
        builder: HarnessBuilder,
        pipeline: GocdPipeline,
    ) -> List[Dict[str, Any]]:
        steps: List[Dict[str, Any]] = []

        if stage.approval and stage.approval.type == "manual":
            user_groups = self._resolve_user_groups(stage.approval)
            steps.append(builder.build_approval_step(
                name=f"Approve {stage.name}",
                message=f"Review and approve stage: {stage.name} for pipeline {pipeline.name}",
                user_groups=user_groups,
            ))

        for job in stage.jobs:
            steps.extend(self._convert_job_tasks(job, builder))

        return steps

    def _convert_job_tasks(
        self,
        job: GocdJob,
        builder: HarnessBuilder,
    ) -> List[Dict[str, Any]]:
        steps: List[Dict[str, Any]] = []
        tasks = job.tasks
        i = 0

        while i < len(tasks):
            task = tasks[i]

            if task.type == "fetch":
                steps.append(self._build_fetch_step(task, builder))
                i += 1
                continue

            if task.type != "exec":
                steps.append(builder.build_shell_step(
                    name=sanitize_step_name(f"Unknown task {task.type}"),
                    script=f"# TODO: Manually convert task type '{task.type}'\n# Raw: {task.raw}",
                ))
                i += 1
                continue

            script = self._extract_script(task)

            # Try to merge consecutive git preamble tasks
            merged, consumed = self._try_merge_git_preamble(tasks, i)
            if consumed > 1:
                step_name = sanitize_step_name(self._infer_step_name(merged) or self._default_step_name(task))
                steps.append(builder.build_shell_step(
                    name=step_name,
                    script=convert_gocd_variables(self._annotate_fetch_config(merged)),
                ))
                i += consumed
                continue

            step_name = sanitize_step_name(self._infer_step_name(script) or self._default_step_name(task))
            steps.append(builder.build_shell_step(
                name=step_name,
                script=convert_gocd_variables(self._annotate_fetch_config(script)),
            ))
            i += 1

        return steps

    # ------------------------------------------------------------------
    # Fetch task handling
    # ------------------------------------------------------------------

    def _build_fetch_step(self, task: GocdTask, builder: HarnessBuilder) -> Dict[str, Any]:
        """Build a structured TODO step for GoCD fetch artifact tasks."""
        pipeline_ref = convert_gocd_variables(task.fetch_pipeline) if task.fetch_pipeline else "(same pipeline)"
        source = task.fetch_source or "artifact"
        dest = task.fetch_destination or ""

        script = (
            f"# Artifact fetch from upstream pipeline\n"
            f"# Source pipeline: {pipeline_ref}\n"
            f"# Stage: {task.fetch_stage} / Job: {task.fetch_job}\n"
            f"# File: {source}\n"
        )
        if dest:
            script += f"# Destination: {dest}\n"

        script += (
            f"#\n"
            f"# Harness migration options:\n"
            f"#   1. Use output variables from the upstream pipeline trigger\n"
            f"#   2. Store in S3/GCS and fetch via shell script\n"
            f"#   3. Use Harness Artifact Source with pipeline chaining\n"
            f"echo \"TODO: Fetch {source} from {pipeline_ref}\"\n"
        )

        return builder.build_shell_step(
            name=sanitize_step_name(f"Fetch {source}"),
            script=script,
            timeout="5m",
        )

    # ------------------------------------------------------------------
    # Script extraction and helpers
    # ------------------------------------------------------------------

    def _extract_script(self, task: GocdTask) -> str:
        if task.command in ("bash", "sh") and len(task.arguments) >= 2 and task.arguments[0] == "-c":
            script = " ".join(task.arguments[1:])
        elif task.arguments:
            script = f"{task.command} {' '.join(task.arguments)}"
        else:
            script = task.command

        if task.working_directory:
            script = f"cd {convert_gocd_variables(task.working_directory)} && {script}"
        return script

    def _annotate_fetch_config(self, script: str) -> str:
        """Add Harness secret migration guidance alongside fetch_config calls."""
        if "fetch_config" not in script:
            return script
        pattern = r'(\.\s+fetch_config\s+(\S+))'
        match = re.search(pattern, script)
        if not match:
            return script
        vault_ref = match.group(2)
        annotation = (
            f"# fetch_config: vault path = {vault_ref}\n"
            f"# TODO: Map to Harness Secret Manager → secrets.getValue(\"<secret_id>\")\n"
        )
        return annotation + script

    def _try_merge_git_preamble(
        self, tasks: List[GocdTask], start: int
    ) -> Tuple[str, int]:
        scripts = []
        consumed = 0
        for idx in range(start, min(start + 4, len(tasks))):
            t = tasks[idx]
            if t.type != "exec":
                break
            s = self._extract_script(t)
            scripts.append(s)
            consumed += 1
            if not re.search(r'git\s+(fetch|reset|checkout|pull|merge-base)', s):
                break

        if consumed <= 1:
            return scripts[0] if scripts else "", 1
        return "\n".join(scripts), consumed

    def _infer_step_name(self, script: str) -> Optional[str]:
        for regex, label in _STEP_NAME_HINTS:
            if re.search(regex, script, re.IGNORECASE):
                return label
        return None

    def _default_step_name(self, task: GocdTask) -> str:
        if task.arguments:
            hint = " ".join(task.arguments[:2])[:50]
            return sanitize_step_name(f"Execute {hint}")
        return sanitize_step_name(f"Execute {task.command[:50]}")

    # ------------------------------------------------------------------
    # User groups
    # ------------------------------------------------------------------

    def _resolve_user_groups(self, approval) -> List[str]:
        groups = []
        if approval.roles:
            groups = [f"account.{sanitize_identifier(r)}" for r in approval.roles]
        if approval.users:
            groups.extend([f"account.{sanitize_identifier(u)}" for u in approval.users])
        return groups or ["account.Admin"]

    # ------------------------------------------------------------------
    # Pipeline trigger
    # ------------------------------------------------------------------

    def _build_pipeline_trigger(
        self, pipeline_name: str, upstream_name: str, upstream_stage: str
    ) -> Dict[str, Any]:
        return {
            "trigger": {
                "name": f"{pipeline_name}_on_{sanitize_identifier(upstream_name)}",
                "identifier": sanitize_identifier(
                    f"{pipeline_name}_on_{upstream_name}"
                ),
                "type": "Pipeline",
                "spec": {
                    "type": "Pipeline",
                    "spec": {
                        "pipelineIdentifier": sanitize_identifier(upstream_name),
                        "stageName": upstream_stage,
                        "event": "OnSuccess",
                    },
                },
                "pipelineIdentifier": sanitize_identifier(pipeline_name),
            }
        }

    # ------------------------------------------------------------------
    # Entity extraction
    # ------------------------------------------------------------------

    def _extract_entities(self, pipeline: GocdPipeline) -> List[Entity]:
        entities: List[Entity] = []
        seen: set = set()

        # Project
        proj_id = sanitize_identifier(pipeline.group)
        if proj_id not in seen:
            seen.add(proj_id)
            entities.append(Entity(
                type=EntityType.PROJECT,
                identifier=proj_id,
                name=pipeline.group,
                api_creatable=True,
            ))

        # GitHub Connector
        if pipeline.git_materials and "GitHub_Connector" not in seen:
            seen.add("GitHub_Connector")
            entities.append(Entity(
                type=EntityType.CONNECTOR,
                identifier="GitHub_Connector",
                name="GitHub Connector",
                api_creatable=True,
                dependencies=["Secret: github_ssh_key"],
            ))

        # AWS Connector (data pipelines interact with S3, StepFunctions, ECR)
        if "AWS_Connector" not in seen:
            seen.add("AWS_Connector")
            entities.append(Entity(
                type=EntityType.CONNECTOR,
                identifier="AWS_Connector",
                name="AWS Cloud Connector",
                api_creatable=True,
                dependencies=["Secret: aws_access_key (or use IRSA/cross-account role)"],
            ))

        # Delegates
        profiles: set = set()
        for stage in pipeline.stages:
            for job in stage.jobs:
                if job.elastic_profile_id:
                    profiles.add(job.elastic_profile_id)
        for profile in profiles:
            d_id = sanitize_identifier(profile)
            if d_id not in seen:
                seen.add(d_id)
                entities.append(Entity(
                    type=EntityType.DELEGATE,
                    identifier=f"{d_id}_delegate",
                    name=f"{profile} Delegate",
                    api_creatable=False,
                ))

        # User Groups from approvals
        for stage in pipeline.stages:
            if stage.approval and stage.approval.type == "manual":
                for role in stage.approval.roles:
                    ug_id = sanitize_identifier(role)
                    if ug_id not in seen:
                        seen.add(ug_id)
                        entities.append(Entity(
                            type=EntityType.USER_GROUP,
                            identifier=ug_id,
                            name=f"{role} User Group",
                            api_creatable=True,
                        ))
                for user in stage.approval.users:
                    ug_id = sanitize_identifier(user)
                    if ug_id not in seen:
                        seen.add(ug_id)
                        entities.append(Entity(
                            type=EntityType.USER_GROUP,
                            identifier=ug_id,
                            name=f"{user} (User-level approval)",
                            api_creatable=True,
                        ))

        # Vault / Secret references
        for task in pipeline.all_tasks:
            if task.type != "exec":
                continue
            script = " ".join(task.arguments)
            for m in re.finditer(r'fetch_config\s+(\S+)', script):
                vault_ref = convert_gocd_variables(m.group(1))
                s_id = sanitize_identifier(
                    vault_ref.replace("/", "_").replace("<+", "").replace(">", "")
                )
                if s_id not in seen:
                    seen.add(s_id)
                    entities.append(Entity(
                        type=EntityType.SECRET,
                        identifier=s_id,
                        name=f"Vault secret: {vault_ref}",
                        api_creatable=False,
                        manual_instructions=(
                            f"Create a Harness Secret referencing vault path: {vault_ref}. "
                            f"Use Harness Secret Manager with HashiCorp Vault connector."
                        ),
                    ))

        return entities
