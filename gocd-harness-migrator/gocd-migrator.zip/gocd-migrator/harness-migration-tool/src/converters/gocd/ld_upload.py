"""
LaunchDarkly Upload Converter.

Handles GoCD patterns:
  - ld_config_upload: generate -> dryrun -> upload (Python script stages)
  - ld_single_update: single update stage (MLP/LD Python command)
  - ld_terraform: terraform-plan -> terraform-deploy (LD-specific Terraform)

All three produce Harness Custom stages with ShellScript steps since they are
config management pipelines, not application deployments. The converter
preserves the original Python/Terraform invocations and maps GoCD variables,
approvals, cron timers, and delegate selectors.
"""

import re
from typing import List, Dict, Any

from src.converters.base import BaseConverter
from src.core.models import (
    GocdPipeline, GocdStage, GocdJob, GocdTask,
    ConversionResult, ConversionMethod, Entity, EntityType,
)
from src.validators.identifier import (
    sanitize_identifier, convert_gocd_variables, extract_repo_name,
)
from config import config


class LdUploadConverter(BaseConverter):
    """Converts GoCD LaunchDarkly/MLP pipelines to Harness Custom stages."""

    @property
    def converter_key(self) -> str:
        return "ld_upload"

    @property
    def supported_patterns(self) -> List[str]:
        return ["ld_config_upload", "ld_single_update"]

    def convert(self, pipeline: GocdPipeline, pattern_id: str) -> ConversionResult:
        result = ConversionResult(
            source_file="",
            source_pipeline_name=pipeline.name,
            source_type="gocd",
            pattern=None,
            conversion_method=ConversionMethod.RULE_BASED,
        )

        variables = self._build_variables(pipeline)
        delegate_selectors = self._get_delegate_selectors(pipeline)
        approval_groups = self._get_approval_user_groups(pipeline)

        if pattern_id == "ld_config_upload":
            stages = self._build_config_upload_stages(
                pipeline, delegate_selectors, approval_groups
            )
        elif pattern_id == "ld_single_update":
            stages = self._build_single_update_stages(
                pipeline, delegate_selectors
            )
        elif pattern_id == "ld_terraform":
            stages = self._build_terraform_stages(
                pipeline, delegate_selectors, approval_groups
            )
        else:
            stages = self._build_generic_stages(pipeline, delegate_selectors)

        tags = {pipeline.group: ""} if pipeline.group else {}
        harness_yaml = {
            "pipeline": {
                "name": pipeline.name,
                "identifier": sanitize_identifier(pipeline.name),
                "projectIdentifier": sanitize_identifier(pipeline.group),
                "orgIdentifier": config.harness.org_identifier,
                "tags": tags,
                "variables": variables,
                "stages": stages,
            }
        }

        if pipeline.timer:
            result.warnings.append(
                f"Pipeline has a cron schedule ({pipeline.timer.spec}). "
                f"Create a Harness cron trigger separately."
            )

        for mat in pipeline.pipeline_materials:
            dep = convert_gocd_variables(mat.pipeline)
            result.warnings.append(
                f"Depends on upstream pipeline '{dep}' (stage: {mat.stage}). "
                f"Create a Harness trigger to chain these."
            )

        result.harness_yaml = harness_yaml
        result.entities = self._extract_entities(
            pipeline, delegate_selectors, approval_groups
        )
        result.success = True
        return result

    # ------------------------------------------------------------------
    # ld_config_upload: generate -> dryrun -> upload
    # ------------------------------------------------------------------

    def _build_config_upload_stages(
        self, pipeline: GocdPipeline, delegates: List[str],
        approval_groups: List[str],
    ) -> List[Dict[str, Any]]:
        stages = []
        repo_name = self._get_repo_dir(pipeline)
        module_name = self._detect_module_name(pipeline)
        env_vars = self._build_env_var_list(pipeline)

        # Stage 1: Generate
        generate_script = self._build_checkout_and_install(pipeline, repo_name, module_name)
        generate_script += self._extract_stage_command(pipeline, "generate", module_name)
        generate_script += f"\ncd {module_name}\nzip -r -X result.zip result"

        stages.append(self._custom_stage(
            name="Generate Config",
            identifier="generate_config",
            steps=[self._shell_step(
                "Generate LD Config", "generate_ld_config",
                generate_script, "15m", env_vars=env_vars,
            )],
            delegates=delegates,
        ))

        # Stage 2: Dry Run
        dryrun_script = self._build_checkout_and_install(pipeline, repo_name, module_name)
        dryrun_script += self._extract_stage_command(
            pipeline, "dryrun", module_name, dry_run=True
        )

        stages.append(self._custom_stage(
            name="Dry Run",
            identifier="dry_run",
            steps=[self._shell_step(
                "Dry Run Upload", "dry_run_upload",
                dryrun_script, "15m", env_vars=env_vars,
            )],
            delegates=delegates,
        ))

        # Stage 3: Upload (with optional approval)
        upload_steps = []
        has_approval = any(
            s.approval and s.approval.type == "manual"
            for s in pipeline.stages if s.name.lower() == "upload"
        )
        if has_approval:
            upload_steps.append(self._approval_step(approval_groups))

        upload_script = self._build_checkout_and_install(pipeline, repo_name, module_name)
        upload_script += self._extract_stage_command(pipeline, "upload", module_name)

        upload_steps.append(self._shell_step(
            "Upload to LaunchDarkly", "upload_to_ld",
            upload_script, "15m", env_vars=env_vars,
        ))

        stages.append(self._custom_stage(
            name="Upload",
            identifier="upload",
            steps=upload_steps,
            delegates=delegates,
        ))

        return stages

    # ------------------------------------------------------------------
    # ld_single_update: single update stage
    # ------------------------------------------------------------------

    def _build_single_update_stages(
        self, pipeline: GocdPipeline, delegates: List[str],
    ) -> List[Dict[str, Any]]:
        update_cmd = self._extract_update_command(pipeline)
        has_module = "python3 -m " in update_cmd and ".main" in update_cmd

        if has_module:
            repo_name = self._get_repo_dir(pipeline)
            module_name = self._detect_module_name(pipeline)
            script = self._build_checkout_and_install(pipeline, repo_name, module_name)
            script += update_cmd
        else:
            script = update_cmd

        env_vars = self._build_env_var_list(pipeline)

        return [self._custom_stage(
            name="Update",
            identifier="update",
            steps=[self._shell_step(
                "Run Update", "run_update", script, "15m",
                env_vars=env_vars,
            )],
            delegates=delegates,
        )]

    # ------------------------------------------------------------------
    # ld_terraform: terraform-plan -> terraform-deploy
    # ------------------------------------------------------------------

    def _build_terraform_stages(
        self, pipeline: GocdPipeline, delegates: List[str],
        approval_groups: List[str],
    ) -> List[Dict[str, Any]]:
        stages = []
        env_vars = self._build_env_var_list(pipeline)

        plan_script = self._build_tf_script(pipeline, "plan")
        stages.append(self._custom_stage(
            name="Terraform Plan",
            identifier="terraform_plan",
            steps=[self._shell_step(
                "Terraform Plan", "tf_plan", plan_script, "15m",
                env_vars=env_vars,
            )],
            delegates=delegates,
        ))

        deploy_steps = []
        has_approval = any(
            s.approval and s.approval.type == "manual"
            for s in pipeline.stages
            if "deploy" in s.name.lower() or "apply" in s.name.lower()
        )
        if has_approval:
            deploy_steps.append(self._approval_step(approval_groups))

        deploy_script = self._build_tf_script(pipeline, "deploy")
        deploy_steps.append(self._shell_step(
            "Terraform Deploy", "tf_deploy", deploy_script, "15m",
            env_vars=env_vars,
        ))

        stages.append(self._custom_stage(
            name="Terraform Deploy",
            identifier="terraform_deploy",
            steps=deploy_steps,
            delegates=delegates,
        ))

        return stages

    # ------------------------------------------------------------------
    # Fallback for unrecognized LD sub-patterns
    # ------------------------------------------------------------------

    def _build_generic_stages(
        self, pipeline: GocdPipeline, delegates: List[str],
    ) -> List[Dict[str, Any]]:
        stages = []
        env_vars = self._build_env_var_list(pipeline)
        for gocd_stage in pipeline.stages:
            script_lines = []
            for job in gocd_stage.jobs:
                for task in job.tasks:
                    if task.type == "exec" and task.arguments:
                        cmd = convert_gocd_variables(self._clean_script(task))
                        if task.working_directory:
                            wd = convert_gocd_variables(task.working_directory)
                            script_lines.append(f"cd {wd}")
                        script_lines.append(cmd)

            stages.append(self._custom_stage(
                name=gocd_stage.name,
                identifier=sanitize_identifier(gocd_stage.name),
                steps=[self._shell_step(
                    gocd_stage.name,
                    sanitize_identifier(f"run_{gocd_stage.name}"),
                    "\n".join(script_lines) or "echo 'No tasks found'",
                    "15m", env_vars=env_vars,
                )],
                delegates=delegates,
            ))
        return stages

    # ------------------------------------------------------------------
    # Script Builders
    # ------------------------------------------------------------------

    def _build_checkout_and_install(
        self, pipeline: GocdPipeline, repo_name: str, module_name: str
    ) -> str:
        lines = []
        branch_var = self._find_branch_var(pipeline)

        if repo_name:
            lines.append(f"cd {repo_name}")
        if branch_var:
            lines.append(
                f"git fetch -p origin && git reset --hard "
                f"<+pipeline.variables.{branch_var}>"
            )

        # Detect pip install from tasks
        for task in pipeline.all_tasks:
            if task.type != "exec" or not task.arguments:
                continue
            script = " ".join(task.arguments)
            pip_match = re.search(
                r'pip3?\s+install\s+-r\s+(\./\S+requirements\.txt)', script
            )
            if pip_match:
                req_path = convert_gocd_variables(pip_match.group(1))
                lines.append(f"python3 -m pip install -r {req_path} --user")
                break

        # Detect fetch_config for vault
        for task in pipeline.all_tasks:
            if task.type != "exec" or not task.arguments:
                continue
            script = " ".join(task.arguments)
            vault_match = re.search(r'\.\s+fetch_config\s+(\S+)', script)
            if vault_match:
                vault_path = convert_gocd_variables(vault_match.group(1))
                lines.append(f". fetch_config {vault_path}")
                break

        lines.append("")
        return "\n".join(lines)

    def _extract_stage_command(
        self, pipeline: GocdPipeline, stage_name: str,
        module_name: str, dry_run: bool = False,
    ) -> str:
        """Extract the python3 -m command for a specific GoCD stage.

        Uses a negative lookahead to skip 'python3 -m pip' (dependency install)
        and match the actual application command like 'python3 -m masthead.main'.
        """
        for stage in pipeline.stages:
            if stage.name.lower() != stage_name.lower():
                continue
            for job in stage.jobs:
                for task in job.tasks:
                    if task.type != "exec" or not task.arguments:
                        continue
                    script = self._clean_script(task)
                    py_match = re.search(
                        r'(python3\s+-m\s+(?!pip\b)\S+\.main\b.*?)(?:;|\n|$)',
                        script,
                    )
                    if py_match:
                        cmd = convert_gocd_variables(py_match.group(1).strip())
                        if dry_run and "--dry_run" not in cmd:
                            cmd += " --dry_run"
                        return cmd

        stage_flag = "--stage upload --dry_run" if dry_run else f"--stage {stage_name}"
        return (
            f"python3 -m {module_name}.main "
            f"--env <+pipeline.variables.ENV> "
            f"--name <+pipeline.variables.CONFIG_NAME> "
            f"{stage_flag}"
        )

    def _extract_update_command(self, pipeline: GocdPipeline) -> str:
        """Extract the main command from a single-update pipeline.

        Tries specific patterns first (python3 -m module.main), then
        falls back to concatenating all exec tasks verbatim.
        """
        for task in pipeline.all_tasks:
            if task.type != "exec" or not task.arguments:
                continue
            script = self._clean_script(task)
            py_match = re.search(
                r'(python3\s+-m\s+(?!pip\b)\S+\.main\b.*?)(?:\n|if\s|$)',
                script, re.DOTALL,
            )
            if py_match:
                cmd = py_match.group(1).strip()
                return convert_gocd_variables(cmd)

        all_scripts = []
        for stage in pipeline.stages:
            for job in stage.jobs:
                for task in job.tasks:
                    if task.type != "exec" or not task.arguments:
                        continue
                    script = self._clean_script(task)
                    if task.working_directory:
                        wd = convert_gocd_variables(task.working_directory)
                        all_scripts.append(f"cd {wd}")
                    all_scripts.append(convert_gocd_variables(script))

        if all_scripts:
            return "\n".join(all_scripts)
        return "# TODO: Update command not found in GoCD pipeline"

    def _build_tf_script(self, pipeline: GocdPipeline, mode: str) -> str:
        """Build terraform plan or deploy script."""
        lines = []
        branch_var = self._find_branch_var(pipeline)

        if branch_var:
            lines.append(
                f"git fetch origin && git checkout "
                f"<+pipeline.variables.{branch_var}>"
            )
        else:
            lines.append("git fetch origin && git checkout origin/master")

        target_stage = "terraform-plan" if mode == "plan" else "terraform-deploy"
        for stage in pipeline.stages:
            if stage.name.lower().replace("_", "-") != target_stage:
                continue
            for job in stage.jobs:
                for task in job.tasks:
                    if task.type != "exec" or not task.arguments:
                        continue
                    script = self._clean_script(task)
                    if "deploy" in script and ("fetch_config" in script or "sh ./" in script):
                        converted = convert_gocd_variables(script)
                        if task.working_directory:
                            wd = convert_gocd_variables(task.working_directory)
                            lines.append(f"cd {wd}")
                        lines.append(converted)
                        return "\n".join(lines)

        lines.append(f"# TODO: {mode} script not found")
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _clean_script(self, task: GocdTask) -> str:
        """Extract the actual script from task arguments, stripping bash -c prefix."""
        if (task.command in ("bash", "sh")
                and len(task.arguments) >= 2
                and task.arguments[0] == "-c"):
            return " ".join(task.arguments[1:])
        return " ".join(task.arguments)

    def _detect_module_name(self, pipeline: GocdPipeline) -> str:
        """Detect the Python module name (client, masthead, mlp, etc.)."""
        for task in pipeline.all_tasks:
            if task.type != "exec" or not task.arguments:
                continue
            script = " ".join(task.arguments)
            module_match = re.search(r'python3\s+-m\s+(\w+)\.main', script)
            if module_match:
                return module_match.group(1)
            req_match = re.search(r'requirements\.txt.*--user.*python3\s+-m\s+(\w+)', script)
            if req_match:
                return req_match.group(1)
        # Fallback: try to infer from pipeline name
        name = pipeline.name.lower()
        if "masthead" in name:
            return "masthead"
        if "mlp" in name:
            return "mlp"
        if "client" in name:
            return "client"
        return "main"

    def _get_repo_dir(self, pipeline: GocdPipeline) -> str:
        """Get the repo checkout directory from the first git material."""
        for mat in pipeline.git_materials:
            if mat.destination:
                return mat.destination
            return extract_repo_name(mat.url) or ""
        return ""

    def _find_branch_var(self, pipeline: GocdPipeline) -> str:
        """Find the branch env var name (CODE_GIT_BRANCH, RELEASE_BRANCH, etc.)."""
        for name in pipeline.environment_variables:
            upper = name.upper()
            if "BRANCH" in upper and ("CODE" in upper or "GIT" in upper or "RELEASE" in upper):
                return name
        return ""

    def _get_delegate_selectors(self, pipeline: GocdPipeline) -> List[str]:
        selectors = set()
        for stage in pipeline.stages:
            for job in stage.jobs:
                if job.elastic_profile_id:
                    selectors.add(convert_gocd_variables(job.elastic_profile_id))
        return list(selectors) if selectors else []

    def _get_approval_user_groups(self, pipeline: GocdPipeline) -> List[str]:
        groups = set()
        for stage in pipeline.stages:
            if stage.approval and stage.approval.type == "manual":
                for role in stage.approval.roles:
                    groups.add(f"account.{sanitize_identifier(role)}")
        return list(groups) if groups else ["account.Admin"]

    # ------------------------------------------------------------------
    # Harness YAML Building Helpers
    # ------------------------------------------------------------------

    def _shell_step(
        self, name: str, identifier: str, script: str, timeout: str,
        env_vars: List[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        return {
            "step": {
                "type": "ShellScript",
                "name": name,
                "identifier": identifier,
                "spec": {
                    "shell": "Bash",
                    "onDelegate": True,
                    "source": {"type": "Inline", "spec": {"script": script}},
                    "environmentVariables": env_vars or [],
                    "outputVariables": [],
                },
                "timeout": timeout,
            }
        }

    def _build_env_var_list(self, pipeline: GocdPipeline) -> List[Dict[str, Any]]:
        """Build environmentVariables list from pipeline params and env vars."""
        env_list = []
        for name in pipeline.parameters:
            env_list.append({
                "name": name,
                "value": f"<+pipeline.variables.{name}>",
                "type": "String",
            })
        for name in pipeline.environment_variables:
            env_list.append({
                "name": name,
                "value": f"<+pipeline.variables.{name}>",
                "type": "String",
            })
        return env_list

    def _approval_step(self, user_groups: List[str]) -> Dict[str, Any]:
        return {
            "step": {
                "type": "HarnessApproval",
                "name": "Approve Upload",
                "identifier": "approve_upload",
                "spec": {
                    "approvalMessage": "Review and approve the upload for <+pipeline.name>",
                    "includePipelineExecutionHistory": True,
                    "isAutoRejectEnabled": False,
                    "approvers": {
                        "userGroups": user_groups,
                        "minimumCount": 1,
                        "disallowPipelineExecutor": False,
                    },
                    "approverInputs": [],
                },
                "timeout": "1d",
            }
        }

    def _custom_stage(
        self, name: str, identifier: str, steps: List[Dict],
        delegates: List[str],
    ) -> Dict[str, Any]:
        stage = {
            "stage": {
                "name": name,
                "identifier": identifier,
                "type": "Custom",
                "spec": {
                    "execution": {
                        "steps": steps,
                    }
                },
                "tags": {},
                "failureStrategies": [
                    {
                        "onFailure": {
                            "errors": ["AllErrors"],
                            "action": {"type": "StageRollback"},
                        }
                    }
                ],
            }
        }
        if delegates:
            stage["stage"]["delegateSelectors"] = delegates[:1]
        return stage

    # ------------------------------------------------------------------
    # Entity Extraction
    # ------------------------------------------------------------------

    def _extract_entities(
        self, pipeline: GocdPipeline, delegates: List[str],
        approval_groups: List[str],
    ) -> List[Entity]:
        entities = []
        seen = set()
        project_id = sanitize_identifier(pipeline.group)

        # Project
        if project_id not in seen:
            seen.add(project_id)
            entities.append(Entity(
                type=EntityType.PROJECT,
                identifier=project_id,
                name=pipeline.group,
                api_creatable=True,
                payload={
                    "project": {
                        "identifier": project_id,
                        "name": pipeline.group,
                        "orgIdentifier": config.harness.org_identifier,
                        "description": f"Migrated from GoCD pipeline group: {pipeline.group}",
                    }
                },
            ))

        # Git Connector
        for mat in pipeline.git_materials:
            conn_id = "github_ssh_connector"
            if conn_id not in seen:
                seen.add(conn_id)
                entities.append(Entity(
                    type=EntityType.CONNECTOR,
                    identifier=conn_id,
                    name="GitHub SSH Connector",
                    api_creatable=True,
                    payload={
                        "connector": {
                            "name": "GitHub SSH Connector",
                            "identifier": conn_id,
                            "type": "Github",
                            "spec": {
                                "url": "https://github.com/hotstar",
                                "authentication": {
                                    "type": "Ssh",
                                    "spec": {"sshKeyRef": "account.github_ssh_key"},
                                },
                                "type": "Account",
                            },
                        }
                    },
                    dependencies=["Secret: github_ssh_key"],
                ))
            break

        # Delegates
        for sel in delegates:
            delegate_id = sanitize_identifier(sel)
            if delegate_id not in seen:
                seen.add(delegate_id)
                entities.append(Entity(
                    type=EntityType.DELEGATE,
                    identifier=delegate_id,
                    name=sel,
                    api_creatable=False,
                    manual_instructions=(
                        f"Install a Harness Delegate with tag: {sel}\n"
                        f"Requirements: Python 3, pip, git, vault CLI (fetch_config)\n"
                        f"Mapped from GoCD elastic_profile_id."
                    ),
                ))

        # User Groups (for approval)
        for group_ref in approval_groups:
            group_id = group_ref.replace("account.", "")
            if group_id not in seen and group_id != "Admin":
                seen.add(group_id)
                entities.append(Entity(
                    type=EntityType.USER_GROUP,
                    identifier=group_id,
                    name=group_id,
                    api_creatable=False,
                    manual_instructions=(
                        f"Create a User Group for upload approvals.\n"
                        f"Name: {group_id}\n"
                        f"Mapped from GoCD approval role."
                    ),
                ))

        return entities

    # ------------------------------------------------------------------
    # Variable Building
    # ------------------------------------------------------------------

    def _build_variables(self, pipeline: GocdPipeline) -> List[Dict[str, Any]]:
        variables = []
        for name, value in pipeline.parameters.items():
            variables.append({
                "name": name,
                "type": "String",
                "value": str(value) if value is not None else "",
            })
        for name, value in pipeline.environment_variables.items():
            converted = convert_gocd_variables(str(value) if value is not None else "")
            variables.append({
                "name": name,
                "type": "String",
                "value": converted,
            })
        return variables
