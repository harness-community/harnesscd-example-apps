"""
Perf Test / K8s Scale GoCD Converter.

Handles the `perf_test` pattern (7 pipelines): Kubernetes HPA scaling
operations (scale-up/scale-down) and Gatling-based performance test execution.

Two sub-types:
  1. K8s Scale (6 pipelines) – Single stage with multiple kubectl patch
     commands that set min/max replicas on HPA resources. Used for
     pre-event scale-up and post-event scale-down.
  2. Perf Runner (1 pipeline) – Three stages: scale-up → perf-test
     (Gatling) → scale-down.

The Harness output uses Custom stages with ShellScript steps. Each kubectl
command is preserved as-is with GoCD variables converted to Harness
expressions. For the perf runner, each stage maps 1:1.
"""

import re
from typing import List, Dict, Any, Optional, Tuple

from src.converters.base import BaseConverter
from src.converters.harness_builder import HarnessBuilder
from src.core.models import (
    GocdPipeline, GocdStage, GocdTask,
    ConversionResult, ConversionMethod, Entity, EntityType,
)
from src.validators.identifier import (
    sanitize_identifier, sanitize_step_name, convert_gocd_variables,
)


_KUBECTL_RE = re.compile(r"kubectl\s+", re.IGNORECASE)
_SCALE_RE = re.compile(r"scale\.py\s+(scaleUp|scaleDown)", re.IGNORECASE)
_PERF_RE = re.compile(r"perf\.sh|gatling|jmeter|locust|k6", re.IGNORECASE)
_HPA_RE = re.compile(r"horizontalpodautoscaler", re.IGNORECASE)

_SVC_NAME_RE = re.compile(
    r"horizontalpodautoscalers?(?:\.v\d+\.autoscaling)?\s+([\w-]+)", re.IGNORECASE
)


class PerfTestConverter(BaseConverter):
    """Converter for K8s scaling and performance test GoCD pipelines."""

    @property
    def converter_key(self) -> str:
        return "perf_test"

    @property
    def supported_patterns(self) -> List[str]:
        return ["perf_test"]

    def convert(self, pipeline: GocdPipeline, pattern_id: str) -> ConversionResult:
        builder = HarnessBuilder()
        builder.reset_counter()

        result = ConversionResult(
            source_file="",
            source_pipeline_name=pipeline.name,
            source_type="gocd",
            pattern=None,
            conversion_method=ConversionMethod.RULE_BASED,
        )

        variables = builder.build_all_variables(pipeline)
        has_git = bool(pipeline.git_materials)
        codebase = builder.build_codebase(pipeline.git_materials[0]) if has_git else None
        delegate_selectors = builder.get_delegate_selectors(pipeline)

        harness_stages = []
        first_ci_stage = True

        for stage in pipeline.stages:
            steps = self._build_stage_steps(stage, builder, pipeline)

            if has_git:
                approval_steps, ci_steps = builder.split_steps_for_ci(steps)
                if approval_steps:
                    harness_stages.append(builder.build_approval_stage(
                        name=f"Approve {stage.name}",
                        message=f"Review and approve {stage.name} for {pipeline.name}",
                        user_groups=self._resolve_user_groups(stage.approval) if stage.approval else ["account.Admin"],
                    ))
                if ci_steps:
                    harness_stages.append(builder.build_ci_stage(
                        name=stage.name,
                        steps=ci_steps,
                        clone_codebase=first_ci_stage,
                        description=self._stage_description(stage),
                        delegate_selectors=delegate_selectors[:1] if delegate_selectors else None,
                    ))
                    first_ci_stage = False
            else:
                harness_stages.append(builder.build_custom_stage(
                    name=stage.name,
                    description=self._stage_description(stage),
                    steps=steps,
                    delegate_selectors=delegate_selectors[:1] if delegate_selectors else None,
                ))

        pipeline_yaml = builder.build_pipeline(
            name=pipeline.name,
            group=pipeline.group,
            stages=harness_stages,
            variables=variables,
            codebase=codebase,
            description="K8s Scale / Performance Test pipeline migrated from GoCD",
        )

        triggers = self._build_triggers(pipeline, builder)
        if triggers:
            pipeline_yaml["_triggers"] = triggers

        result.harness_yaml = pipeline_yaml
        result.entities = self._extract_entities(pipeline, delegate_selectors)
        result.success = True
        return result

    # ------------------------------------------------------------------
    # Stage step builder
    # ------------------------------------------------------------------

    def _build_stage_steps(
        self,
        stage: GocdStage,
        builder: HarnessBuilder,
        pipeline: GocdPipeline,
    ) -> List[Dict[str, Any]]:
        steps: List[Dict[str, Any]] = []

        if stage.approval and stage.approval.type == "manual":
            groups = self._resolve_user_groups(stage.approval)
            steps.append(builder.build_approval_step(
                name=f"Approve {stage.name}",
                message=f"Review and approve {stage.name} for {pipeline.name}",
                user_groups=groups,
            ))

        for job in stage.jobs:
            tasks = job.tasks
            i = 0
            while i < len(tasks):
                task = tasks[i]

                if task.type == "fetch":
                    steps.append(self._build_fetch_step(task, builder))
                    i += 1
                    continue

                if task.type != "exec":
                    steps.append(builder.build_shell_step(
                        name=sanitize_step_name(f"Unknown task {task.type}"),
                        script=f"# TODO: Manually convert task type '{task.type}'",
                    ))
                    i += 1
                    continue

                script = self._extract_script(task)

                # Try merging consecutive kubectl patch commands into one step
                merged, consumed = self._try_merge_kubectl(tasks, i)
                if consumed > 1:
                    name = sanitize_step_name(
                        self._infer_step_name(merged) or "K8s Scale Operations"
                    )
                    steps.append(builder.build_shell_step(
                        name=name,
                        script=convert_gocd_variables(merged),
                    ))
                    i += consumed
                    continue

                # Try merging git preamble
                merged_git, consumed_git = self._try_merge_git_preamble(tasks, i)
                if consumed_git > 1:
                    name = sanitize_step_name("Git Checkout")
                    steps.append(builder.build_shell_step(
                        name=name,
                        script=convert_gocd_variables(merged_git),
                    ))
                    i += consumed_git
                    continue

                name = sanitize_step_name(
                    self._infer_step_name(script) or self._default_step_name(task)
                )
                steps.append(builder.build_shell_step(
                    name=name,
                    script=convert_gocd_variables(script),
                ))
                i += 1

        return steps

    # ------------------------------------------------------------------
    # Merge consecutive kubectl HPA patches into one step
    # ------------------------------------------------------------------

    def _try_merge_kubectl(self, tasks, start_idx) -> Tuple[str, int]:
        scripts = []
        i = start_idx
        while i < len(tasks) and tasks[i].type == "exec":
            s = self._extract_script(tasks[i])
            if _KUBECTL_RE.search(s) and _HPA_RE.search(s):
                svc = self._extract_service_name(s)
                scripts.append(f"# --- Scale: {svc or 'service'} ---\n{s}")
                i += 1
            elif i == start_idx:
                return s, 1
            else:
                break
        if len(scripts) > 1:
            return "\n\n".join(scripts), len(scripts)
        if scripts:
            return scripts[0], 1
        return "", 1

    def _extract_service_name(self, script: str) -> Optional[str]:
        m = _SVC_NAME_RE.search(script)
        return m.group(1) if m else None

    # ------------------------------------------------------------------
    # Script helpers
    # ------------------------------------------------------------------

    def _extract_script(self, task: GocdTask) -> str:
        if task.command in ("bash", "sh") and len(task.arguments) >= 2 and task.arguments[0] == "-c":
            script = " ".join(task.arguments[1:])
        elif task.arguments:
            script = f"{task.command} {' '.join(task.arguments)}"
        else:
            script = task.command

        if task.working_directory:
            wd = convert_gocd_variables(task.working_directory)
            script = f"cd {wd} && {script}"
        return script

    def _try_merge_git_preamble(self, tasks, start_idx) -> Tuple[str, int]:
        git_cmds = re.compile(r"git\s+(fetch|reset|checkout|pull)", re.IGNORECASE)
        scripts = []
        i = start_idx
        while i < len(tasks) and tasks[i].type == "exec":
            s = self._extract_script(tasks[i])
            if i == start_idx or git_cmds.search(s):
                scripts.append(s)
                i += 1
            else:
                break
        if len(scripts) > 1:
            return "\n".join(scripts), len(scripts)
        return scripts[0] if scripts else "", 1

    _STEP_HINTS = [
        (r"kubectl.*patch.*horizontalpodautoscaler", "Scale K8s HPA"),
        (r"kubectl.*scale", "K8s Scale"),
        (r"scale\.py\s+scaleUp", "Scale Up Services"),
        (r"scale\.py\s+scaleDown", "Scale Down Services"),
        (r"perf\.sh|gatling|jmeter", "Run Performance Tests"),
        (r"pip3?\s+install.*boto3", "Install Dependencies"),
        (r"git\s+fetch.*git\s+reset|git\s+checkout", "Git Checkout"),
    ]

    def _infer_step_name(self, script: str) -> Optional[str]:
        for regex, label in self._STEP_HINTS:
            if re.search(regex, script, re.IGNORECASE):
                return label
        return None

    def _default_step_name(self, task: GocdTask) -> str:
        if task.arguments:
            hint = " ".join(task.arguments[:2])[:50]
            return sanitize_step_name(f"Execute {hint}")
        return sanitize_step_name(f"Execute {task.command[:50]}")

    def _stage_description(self, stage: GocdStage) -> str:
        all_scripts = ""
        for job in stage.jobs:
            for task in job.tasks:
                if task.type == "exec":
                    all_scripts += " ".join(task.arguments or [task.command]) + " "

        if _PERF_RE.search(all_scripts):
            return f"Performance Test Execution – {stage.name}"
        if _SCALE_RE.search(all_scripts) or _KUBECTL_RE.search(all_scripts):
            return f"K8s Scale Operation – {stage.name}"
        return f"Migrated from GoCD stage: {stage.name}"

    # ------------------------------------------------------------------
    # Fetch task stubs
    # ------------------------------------------------------------------

    def _build_fetch_step(self, task: GocdTask, builder: HarnessBuilder) -> Dict[str, Any]:
        pipeline_ref = convert_gocd_variables(task.fetch_pipeline) if task.fetch_pipeline else "(same pipeline)"
        source = task.fetch_source or "artifact"

        script = (
            f"# Artifact fetch from upstream\n"
            f"# Source: {pipeline_ref} / {task.fetch_stage} / {task.fetch_job}\n"
            f"# File: {source}\n"
            f'echo "TODO: Fetch {source} from {pipeline_ref}"\n'
        )
        return builder.build_shell_step(
            name=sanitize_step_name(f"Fetch {source}"),
            script=script,
            timeout="5m",
        )

    # ------------------------------------------------------------------
    # User groups
    # ------------------------------------------------------------------

    def _resolve_user_groups(self, approval) -> List[str]:
        groups = []
        if approval.roles:
            groups = [f"account.{sanitize_identifier(r)}" for r in approval.roles]
        if approval.users:
            groups.extend([f"account.{sanitize_identifier(u)}" for u in approval.users])
        return groups or ["account.Admin"]

    # ------------------------------------------------------------------
    # Triggers
    # ------------------------------------------------------------------

    def _build_triggers(self, pipeline: GocdPipeline, builder: HarnessBuilder) -> List[Dict]:
        triggers = []
        if pipeline.timer:
            triggers.append(builder.build_cron_trigger(pipeline.timer, pipeline.name))
        return triggers

    # ------------------------------------------------------------------
    # Entities
    # ------------------------------------------------------------------

    def _extract_entities(self, pipeline: GocdPipeline, delegate_selectors: List[str]) -> List[Entity]:
        entities: List[Entity] = []

        entities.append(Entity(
            type=EntityType.PROJECT,
            identifier=sanitize_identifier(pipeline.group),
            name=pipeline.group,
            payload={"orgIdentifier": "default"},
        ))

        if pipeline.git_materials:
            entities.append(Entity(
                type=EntityType.CONNECTOR,
                identifier="GitHub_Connector",
                name="GitHub Connector",
                payload={"type": "Github", "spec": {"url": pipeline.git_materials[0].url}},
            ))

        entities.append(Entity(
            type=EntityType.CONNECTOR,
            identifier="K8s_Cluster_Connector",
            name="K8s Cluster Connector (for kubectl operations)",
            payload={"type": "K8sCluster", "spec": {"credential": {"type": "ManualConfig"}}},
        ))

        for sel in delegate_selectors:
            entities.append(Entity(
                type=EntityType.DELEGATE,
                identifier=sanitize_identifier(sel),
                name=f"{sel} Delegate",
                payload={"tags": [sel]},
            ))

        for stage in pipeline.stages:
            if stage.approval and stage.approval.type == "manual":
                for role in (stage.approval.roles or []):
                    entities.append(Entity(
                        type=EntityType.USER_GROUP,
                        identifier=sanitize_identifier(role),
                        name=f"{role} User Group",
                        payload={"accountIdentifier": "<+account.identifier>"},
                    ))

        return entities
