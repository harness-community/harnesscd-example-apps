"""
Abstract base class for pipeline converters.

Each pattern (Terraform, K8s, LD Upload, etc.) implements a converter that
takes a parsed GocdPipeline and produces Harness pipeline YAML.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List

from src.core.models import GocdPipeline, ConversionResult, Entity


class BaseConverter(ABC):
    """Base class for all pipeline converters."""

    @property
    @abstractmethod
    def converter_key(self) -> str:
        """Unique key for this converter (matches classifier's converter_key)."""
        ...

    @property
    @abstractmethod
    def supported_patterns(self) -> List[str]:
        """List of pattern IDs this converter handles."""
        ...

    @abstractmethod
    def convert(self, pipeline: GocdPipeline, pattern_id: str) -> ConversionResult:
        """
        Convert a GoCD pipeline to Harness pipeline YAML.

        Args:
            pipeline: Parsed GoCD pipeline
            pattern_id: The specific pattern ID that matched

        Returns:
            ConversionResult with Harness YAML and entities
        """
        ...
