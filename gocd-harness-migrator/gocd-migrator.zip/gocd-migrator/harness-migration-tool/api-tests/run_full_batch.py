#!/usr/bin/env python3
"""
Full batch conversion of all GoCD sample YAMLs through the API.
Saves each result in its own subfolder with:
  - SOURCE_<name>.gocd.yaml
  - <pipeline>.harness.yaml (one per pipeline)
  - entities.md
"""

import json
import os
import shutil
import sys
import time
from pathlib import Path

import requests

from enhance_entities import process_folder

API_BASE = "http://localhost:8080"
SAMPLES_DIR = Path(__file__).resolve().parent.parent.parent / "GoCD sample yamls"
OUTPUT_DIR = Path(__file__).resolve().parent / "full-test-results"


def convert_file(filepath: Path):
    with open(filepath, "rb") as f:
        resp = requests.post(
            f"{API_BASE}/convert",
            files={"file": (filepath.name, f, "text/yaml")},
            timeout=60,
        )
    resp.raise_for_status()
    return resp.json()


def save_results(result, sample_name, out_dir, source_filepath):
    sample_dir = out_dir / sample_name
    sample_dir.mkdir(parents=True, exist_ok=True)

    if source_filepath and source_filepath.exists():
        shutil.copy2(source_filepath, sample_dir / f"SOURCE_{source_filepath.name}")

    for i, pipeline in enumerate(result.get("pipelines", [])):
        pipeline_name = pipeline.get("source_pipeline_name", f"pipeline_{i}")
        safe_name = pipeline_name.replace("/", "_").replace(" ", "_")
        yaml_path = sample_dir / f"{safe_name}.harness.yaml"
        with open(yaml_path, "w") as f:
            f.write(pipeline.get("harness_yaml", "# No YAML generated"))

        for j, trigger in enumerate(pipeline.get("triggers", [])):
            trig_path = sample_dir / f"{safe_name}.trigger_{j}.yaml"
            with open(trig_path, "w") as f:
                f.write(trigger.get("yaml", "# No trigger YAML"))

    entities = result.get("all_entities", [])
    with open(sample_dir / "entities.md", "w") as f:
        f.write(f"# Required Harness Entities for {sample_name}\n\n")
        f.write(f"Total entities: {len(entities)}\n\n")
        if not entities:
            f.write("_No additional entities required._\n")
        for entity in entities:
            f.write(f"## {entity['type']}: `{entity['identifier']}`\n\n")
            f.write(f"- **Name:** {entity['name']}\n")
            f.write(f"- **API Creatable:** {'Yes' if entity.get('api_creatable') else 'No'}\n")
            if entity.get("manual_instructions"):
                f.write(f"- **Manual Instructions:** {entity['manual_instructions']}\n")
            f.write("\n")


def main():
    yamls = sorted(SAMPLES_DIR.glob("*.gocd.yaml"))
    print(f"Found {len(yamls)} GoCD YAML files")

    if OUTPUT_DIR.exists():
        shutil.rmtree(OUTPUT_DIR)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    success = 0
    failed = 0
    total_pipelines = 0
    total_entities = 0
    summary_rows = []

    for idx, filepath in enumerate(yamls, 1):
        sample_name = filepath.name.replace(".gocd.yaml", "")
        try:
            result = convert_file(filepath)
            n_pipelines = result.get("total_pipelines", 0)
            n_entities = len(result.get("all_entities", []))
            patterns = [p.get("pattern", "?") for p in result.get("pipelines", [])]

            save_results(result, sample_name, OUTPUT_DIR, filepath)

            try:
                process_folder(OUTPUT_DIR / sample_name)
            except Exception as enhance_exc:
                print(f"    WARN: Could not enhance entities.md: {enhance_exc}")

            success += 1
            total_pipelines += n_pipelines
            total_entities += n_entities

            print(f"  [{idx:3d}/{len(yamls)}] OK  {sample_name} -> {n_pipelines} pipeline(s), {n_entities} entities, patterns: {', '.join(patterns)}")
            summary_rows.append((sample_name, n_pipelines, n_entities, ", ".join(patterns), "OK"))

        except Exception as exc:
            failed += 1
            print(f"  [{idx:3d}/{len(yamls)}] ERR {sample_name}: {exc}")
            summary_rows.append((sample_name, 0, 0, "-", f"FAIL: {exc}"))

    # Write summary
    with open(OUTPUT_DIR / "SUMMARY.md", "w") as f:
        f.write("# Full Batch Conversion Results\n\n")
        f.write(f"**Date:** {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        f.write(f"- **Files processed:** {success + failed}\n")
        f.write(f"- **Successful:** {success}\n")
        f.write(f"- **Failed:** {failed}\n")
        f.write(f"- **Total pipelines generated:** {total_pipelines}\n")
        f.write(f"- **Total entities identified:** {total_entities}\n\n")
        f.write("| # | GoCD File | Pipelines | Entities | Pattern(s) | Status |\n")
        f.write("|---|-----------|-----------|----------|------------|--------|\n")
        for i, (name, npip, nent, pats, status) in enumerate(summary_rows, 1):
            f.write(f"| {i} | {name} | {npip} | {nent} | {pats} | {status} |\n")

    print(f"\n{'='*60}")
    print(f"DONE: {success} OK, {failed} FAIL out of {len(yamls)} files")
    print(f"Total pipelines: {total_pipelines}, Total entities: {total_entities}")
    print(f"Results: {OUTPUT_DIR}")

    return failed == 0


if __name__ == "__main__":
    ok = main()
    sys.exit(0 if ok else 1)
