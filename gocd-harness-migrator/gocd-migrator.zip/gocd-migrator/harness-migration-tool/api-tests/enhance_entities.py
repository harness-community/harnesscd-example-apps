#!/usr/bin/env python3
"""
Enhance entities.md for every converted GoCD→Harness folder.

For each subfolder in the output directory, reads the SOURCE GoCD YAML and
all Harness YAML(s), then rewrites entities.md with:
  1. GoCD Pipeline Summary   – what the original pipeline was doing
  2. Harness Pipeline Summary – what the converted pipeline does
  3. Business Logic Parity    – notes on whether the intent is preserved
  4. Entity Mapping Table     – per-pipeline GoCD→Harness entity map
  5. Required Entities        – the original entity list (preserved)
"""

import re
import sys
import textwrap
from pathlib import Path

import yaml


class DuplicateKeySafeLoader(yaml.SafeLoader):
    """YAML loader that silently handles duplicate anchors (common in GoCD YAMLs)."""
    pass

DuplicateKeySafeLoader.yaml_implicit_resolvers = yaml.SafeLoader.yaml_implicit_resolvers.copy()

_orig_compose_node = DuplicateKeySafeLoader.compose_node
def _compose_node_dup(self, parent, index):
    if self.check_event(yaml.events.AliasEvent):
        return _orig_compose_node(self, parent, index)
    event = self.peek_event()
    anchor = event.anchor
    if anchor is not None and anchor in self.anchors:
        del self.anchors[anchor]
    return _orig_compose_node(self, parent, index)

DuplicateKeySafeLoader.compose_node = _compose_node_dup


OUTPUT_DIR = Path(__file__).resolve().parent / "GoCD-Harness-converted-YAMLS"


# ---------------------------------------------------------------------------
# GoCD YAML parsing helpers
# ---------------------------------------------------------------------------

def parse_gocd(filepath: Path) -> dict:
    """Parse a GoCD YAML and return structured info for all pipelines."""
    with open(filepath) as f:
        raw = yaml.load(f, Loader=DuplicateKeySafeLoader)

    pipelines = {}
    for pname, pdef in (raw.get("pipelines") or {}).items():
        info = {
            "name": pname,
            "group": pdef.get("group", ""),
            "parameters": pdef.get("parameters") or {},
            "env_vars": pdef.get("environment_variables") or {},
            "materials": [],
            "stages": [],
            "timer": pdef.get("timer"),
            "label_template": pdef.get("label_template"),
        }

        for mname, mdef in (pdef.get("materials") or {}).items():
            mat = {"name": mname}
            if isinstance(mdef, dict):
                mat["type"] = "git" if "git" in mdef else "pipeline" if "pipeline" in mdef else "unknown"
                mat["url"] = mdef.get("git", "")
                mat["branch"] = mdef.get("branch", "")
                mat["pipeline_dep"] = mdef.get("pipeline", "")
                mat["stage_dep"] = mdef.get("stage", "")
                mat["destination"] = mdef.get("destination", "")
            info["materials"].append(mat)

        for stage_entry in pdef.get("stages") or []:
            for sname, sdef in stage_entry.items():
                stage = {
                    "name": sname,
                    "approval": None,
                    "jobs": [],
                }
                if isinstance(sdef.get("approval"), dict):
                    stage["approval"] = sdef["approval"].get("type", "manual")
                    stage["approval_roles"] = sdef["approval"].get("roles", [])
                elif sdef.get("approval") == "manual":
                    stage["approval"] = "manual"
                    stage["approval_roles"] = []

                for jname, jdef in (sdef.get("jobs") or {}).items():
                    if isinstance(jdef, str):
                        continue
                    if jdef is None:
                        continue
                    job = {
                        "name": jname,
                        "elastic_profile_id": jdef.get("elastic_profile_id", ""),
                        "tasks": [],
                        "artifacts": [],
                    }
                    for task in jdef.get("tasks") or []:
                        if isinstance(task, dict):
                            if "exec" in task:
                                edef = task["exec"]
                                args = edef.get("arguments", [])
                                cmd_str = " ".join(str(a) for a in args) if args else ""
                                job["tasks"].append({
                                    "type": "exec",
                                    "command": edef.get("command", ""),
                                    "args": cmd_str,
                                    "working_directory": edef.get("working_directory", ""),
                                })
                            elif "fetch" in task:
                                fdef = task["fetch"]
                                job["tasks"].append({
                                    "type": "fetch",
                                    "pipeline": fdef.get("pipeline", ""),
                                    "stage": fdef.get("stage", ""),
                                    "job": fdef.get("job", ""),
                                    "source": fdef.get("source", ""),
                                })
                    for art in jdef.get("artifacts") or []:
                        if isinstance(art, dict) and "build" in art:
                            job["artifacts"].append(art["build"].get("source", ""))
                    stage["jobs"].append(job)
                info["stages"].append(stage)

        pipelines[pname] = info
    return pipelines


# ---------------------------------------------------------------------------
# Harness YAML parsing helpers
# ---------------------------------------------------------------------------

def parse_harness(filepath: Path) -> dict:
    """Parse a Harness pipeline YAML and return structured info."""
    with open(filepath) as f:
        raw = yaml.safe_load(f)

    pdef = raw.get("pipeline", {})
    info = {
        "name": pdef.get("name", ""),
        "identifier": pdef.get("identifier", ""),
        "project": pdef.get("projectIdentifier", ""),
        "org": pdef.get("orgIdentifier", ""),
        "variables": [],
        "stages": [],
        "codebase": None,
    }

    props = pdef.get("properties", {})
    if props.get("ci", {}).get("codebase"):
        cb = props["ci"]["codebase"]
        info["codebase"] = {
            "connector": cb.get("connectorRef", ""),
            "repo": cb.get("repoName", ""),
            "branch": cb.get("build", {}).get("spec", {}).get("branch", ""),
        }

    for v in pdef.get("variables") or []:
        info["variables"].append({
            "name": v.get("name", ""),
            "value": str(v.get("value", "")),
            "description": v.get("description", ""),
        })

    for stage_wrapper in pdef.get("stages") or []:
        sdef = stage_wrapper.get("stage", {})
        stage = {
            "name": sdef.get("name", ""),
            "identifier": sdef.get("identifier", ""),
            "type": sdef.get("type", ""),
            "description": sdef.get("description", ""),
            "steps": [],
            "rollback_steps": [],
            "delegate_selectors": sdef.get("delegateSelectors", []),
            "service_ref": "",
            "environment_ref": "",
            "infra_id": "",
        }

        spec = sdef.get("spec", {})
        svc = spec.get("service", {})
        stage["service_ref"] = svc.get("serviceRef", "")

        env = spec.get("environment", {})
        stage["environment_ref"] = env.get("environmentRef", "")
        infra_defs = env.get("infrastructureDefinitions") or []
        if infra_defs:
            stage["infra_id"] = infra_defs[0].get("identifier", "")

        execution = spec.get("execution", {})
        for step_wrapper in execution.get("steps") or []:
            st = step_wrapper.get("step") or step_wrapper.get("stepGroup", {})
            if st:
                stage["steps"].append({
                    "type": st.get("type", ""),
                    "name": st.get("name", ""),
                    "identifier": st.get("identifier", ""),
                })
        for step_wrapper in execution.get("rollbackSteps") or []:
            st = step_wrapper.get("step", {})
            if st:
                stage["rollback_steps"].append({
                    "type": st.get("type", ""),
                    "name": st.get("name", ""),
                })

        info["stages"].append(stage)

    return info


# ---------------------------------------------------------------------------
# Summary generation
# ---------------------------------------------------------------------------

def extract_repo_short(url: str) -> str:
    """Extract org/repo from a git URL."""
    m = re.search(r"[:/]([^/:]+/[^/.]+?)(?:\.git)?$", url)
    return m.group(1) if m else url


def summarize_gocd_pipeline(pinfo: dict) -> str:
    """Generate a human-readable summary of what a GoCD pipeline does."""
    lines = []
    name = pinfo["name"]
    group = pinfo["group"]

    lines.append(f"**Pipeline:** `{name}` (group: `{group}`)")

    # Materials
    git_mats = [m for m in pinfo["materials"] if m.get("type") == "git"]
    dep_mats = [m for m in pinfo["materials"] if m.get("type") == "pipeline"]
    if git_mats:
        repos = ", ".join(f"`{extract_repo_short(m['url'])}` ({m.get('branch', 'default')})" for m in git_mats)
        lines.append(f"- **Source repos:** {repos}")
    if dep_mats:
        deps = ", ".join(f"`{m['pipeline_dep']}` (stage: {m['stage_dep']})" for m in dep_mats)
        lines.append(f"- **Pipeline dependencies:** {deps}")

    # Timer
    if pinfo.get("timer"):
        spec = pinfo["timer"].get("spec", "")
        lines.append(f"- **Scheduled trigger:** `{spec}`")

    # Parameters
    if pinfo["parameters"]:
        params = ", ".join(f"`{k}`=`{v}`" for k, v in pinfo["parameters"].items())
        lines.append(f"- **Parameters:** {params}")

    # Stages overview
    for stage in pinfo["stages"]:
        approval_note = ""
        if stage["approval"]:
            roles = ", ".join(stage.get("approval_roles", [])) or "any"
            approval_note = f" (manual approval required, roles: {roles})"

        lines.append(f"- **Stage `{stage['name']}`**{approval_note}")
        for job in stage["jobs"]:
            agent = job.get("elastic_profile_id", "")
            agent_note = f" on agent `{agent}`" if agent else ""
            lines.append(f"  - Job `{job['name']}`{agent_note}")
            for task in job["tasks"]:
                if task["type"] == "exec":
                    cmd_preview = task["args"][:120]
                    if len(task["args"]) > 120:
                        cmd_preview += "..."
                    lines.append(f"    - exec: `{cmd_preview}`")
                elif task["type"] == "fetch":
                    lines.append(f"    - fetch artifact `{task['source']}` from `{task['stage']}/{task['job']}`")
            if job["artifacts"]:
                arts = ", ".join(f"`{a}`" for a in job["artifacts"])
                lines.append(f"    - Produces artifacts: {arts}")

    return "\n".join(lines)


def summarize_harness_pipeline(hinfo: dict) -> str:
    """Generate a human-readable summary of what a Harness pipeline does."""
    lines = []
    lines.append(f"**Pipeline:** `{hinfo['name']}` (project: `{hinfo['project']}`)")

    if hinfo.get("codebase"):
        cb = hinfo["codebase"]
        lines.append(f"- **Codebase:** `{cb['repo']}` ({cb['branch']}) via connector `{cb['connector']}`")

    if hinfo["variables"]:
        var_names = ", ".join(f"`{v['name']}`" for v in hinfo["variables"])
        lines.append(f"- **Variables ({len(hinfo['variables'])}):** {var_names}")

    for stage in hinfo["stages"]:
        stype = stage.get("type", "Custom")
        desc = stage.get("description", "")
        desc_note = f" — {desc}" if desc else ""
        lines.append(f"- **Stage `{stage['name']}`** (type: {stype}){desc_note}")

        if stage["service_ref"]:
            lines.append(f"  - Service: `{stage['service_ref']}`")
        if stage["environment_ref"]:
            lines.append(f"  - Environment: `{stage['environment_ref']}`, Infrastructure: `{stage['infra_id']}`")
        if stage["delegate_selectors"]:
            delegates = ", ".join(f"`{d}`" for d in stage["delegate_selectors"])
            lines.append(f"  - Delegates: {delegates}")

        for step in stage["steps"]:
            lines.append(f"  - Step: **{step['name']}** (`{step['type']}`)")
        for step in stage["rollback_steps"]:
            lines.append(f"  - Rollback: **{step['name']}** (`{step['type']}`)")

    return "\n".join(lines)


def generate_entity_mapping(gocd_pipelines: dict, harness_files: list) -> str:
    """Generate a mapping table from GoCD entities to Harness entities."""
    rows = []

    all_gocd_materials = {}
    all_gocd_agents = set()
    all_gocd_params = {}
    all_gocd_env_vars = {}
    all_gocd_stages = []
    all_gocd_approvals = []
    all_gocd_artifacts = []
    all_gocd_timers = []
    gocd_groups = set()
    all_gocd_deps = []

    for pname, pinfo in gocd_pipelines.items():
        gocd_groups.add(pinfo["group"])
        all_gocd_params.update(pinfo["parameters"])
        all_gocd_env_vars.update(pinfo["env_vars"])
        if pinfo.get("timer"):
            all_gocd_timers.append({"pipeline": pname, "spec": pinfo["timer"].get("spec", "")})

        for mat in pinfo["materials"]:
            if mat.get("type") == "git":
                all_gocd_materials[mat["name"]] = mat
            elif mat.get("type") == "pipeline":
                all_gocd_deps.append(mat)

        for stage in pinfo["stages"]:
            all_gocd_stages.append({"pipeline": pname, "stage": stage["name"]})
            if stage["approval"]:
                all_gocd_approvals.append({
                    "pipeline": pname,
                    "stage": stage["name"],
                    "roles": stage.get("approval_roles", []),
                })
            for job in stage["jobs"]:
                if job["elastic_profile_id"]:
                    all_gocd_agents.add(job["elastic_profile_id"])
                for art in job["artifacts"]:
                    all_gocd_artifacts.append({"pipeline": pname, "stage": stage["name"], "artifact": art})

    all_harness_vars = {}
    all_harness_stages = []
    all_harness_delegates = set()
    all_harness_services = set()
    all_harness_envs = set()
    all_harness_connectors = set()
    harness_project = ""

    for hpath in harness_files:
        hinfo = parse_harness(hpath)
        harness_project = hinfo["project"]
        for v in hinfo["variables"]:
            all_harness_vars[v["name"]] = v["value"]
        if hinfo.get("codebase"):
            all_harness_connectors.add(hinfo["codebase"]["connector"])
        for stage in hinfo["stages"]:
            all_harness_stages.append({"pipeline": hinfo["name"], "stage": stage["name"], "type": stage["type"]})
            for d in stage.get("delegate_selectors") or []:
                all_harness_delegates.add(d)
            if stage["service_ref"]:
                all_harness_services.add(stage["service_ref"])
            if stage["environment_ref"]:
                all_harness_envs.add(stage["environment_ref"])

    # Build the mapping table
    lines = []
    lines.append("| GoCD Entity | GoCD Value | Harness Entity | Harness Value | Notes |")
    lines.append("|---|---|---|---|---|")

    # Pipeline Group → Project
    for g in sorted(gocd_groups):
        lines.append(f"| Pipeline Group | `{g}` | Project | `{harness_project}` | Organizational container |")

    # Materials → Connectors
    for mname, mat in all_gocd_materials.items():
        repo = extract_repo_short(mat.get("url", ""))
        branch = mat.get("branch", "")
        connectors = ", ".join(f"`{c}`" for c in sorted(all_harness_connectors)) if all_harness_connectors else "—"
        lines.append(f"| Material (`{mname}`) | `{repo}` ({branch}) | Connector | {connectors} | SCM source |")

    # Pipeline Dependencies
    for dep in all_gocd_deps:
        lines.append(f"| Pipeline Dependency | `{dep['pipeline_dep']}` (stage: `{dep['stage_dep']}`) | — | Pipeline chaining / trigger | Needs manual trigger setup |")

    # Elastic Profile → Delegate
    for agent in sorted(all_gocd_agents):
        harness_del = f"`{agent}`" if agent in {d for d in all_harness_delegates} else f"`{agent}` (delegate selector)"
        lines.append(f"| Elastic Profile | `{agent}` | Delegate Selector | {harness_del} | Worker node |")

    # Parameters → Variables
    for k, v in sorted(all_gocd_params.items()):
        hval = all_harness_vars.get(k, "—")
        lines.append(f"| Parameter | `{k}` = `{v}` | Pipeline Variable | `{k}` = `{hval}` | Parameterization |")

    # Environment Variables → Variables
    for k, v in sorted(all_gocd_env_vars.items()):
        hval = all_harness_vars.get(k, "—")
        display_v = str(v)[:50] + "..." if len(str(v)) > 50 else str(v)
        display_hval = str(hval)[:50] + "..." if len(str(hval)) > 50 else str(hval)
        lines.append(f"| Environment Variable | `{k}` = `{display_v}` | Pipeline Variable | `{k}` = `{display_hval}` | Runtime config |")

    # Stages mapping
    gocd_stage_names = [s["stage"] for s in all_gocd_stages]
    harness_stage_names = [(s["stage"], s["type"]) for s in all_harness_stages]
    max_len = max(len(gocd_stage_names), len(harness_stage_names), 1)
    for i in range(max_len):
        gs = f"`{gocd_stage_names[i]}`" if i < len(gocd_stage_names) else "—"
        if i < len(harness_stage_names):
            hs = f"`{harness_stage_names[i][0]}` ({harness_stage_names[i][1]})"
        else:
            hs = "—"
        lines.append(f"| Stage | {gs} | Stage | {hs} | Pipeline phase |")

    # Approvals
    for appr in all_gocd_approvals:
        roles = ", ".join(appr["roles"]) if appr["roles"] else "any"
        lines.append(f"| Manual Approval | Stage `{appr['stage']}` (roles: {roles}) | HarnessApproval Step | In stage execution | Deployment gate |")

    # Timers → Triggers
    for timer in all_gocd_timers:
        lines.append(f"| Timer | `{timer['spec']}` | Cron Trigger | Same schedule | Scheduled execution |")

    # Artifacts
    for art in all_gocd_artifacts:
        lines.append(f"| Build Artifact | `{art['artifact']}` (stage: `{art['stage']}`) | Output Variable / File Store | Step output or file store upload | Artifact passing |")

    # Services
    for svc in sorted(all_harness_services):
        lines.append(f"| — | — | Service | `{svc}` | Created for K8s deployment type |")

    # Environments
    for env in sorted(all_harness_envs):
        lines.append(f"| Environment (manual) | GoCD environment config | Environment | `{env}` | Deployment target |")

    return "\n".join(lines)


def generate_parity_notes(gocd_pipelines: dict, harness_files: list) -> str:
    """Generate business logic parity notes."""
    notes = []

    for pname, pinfo in gocd_pipelines.items():
        # Collect all exec commands from GoCD
        gocd_commands = []
        for stage in pinfo["stages"]:
            for job in stage["jobs"]:
                for task in job["tasks"]:
                    if task["type"] == "exec":
                        gocd_commands.append(task["args"])

        # Check for common patterns
        has_docker_build = any("docker build" in c for c in gocd_commands)
        has_k8s_deploy = any("deploy.sh" in c or "kubectl" in c for c in gocd_commands)
        has_terraform = any("terraform" in c for c in gocd_commands)
        has_git_clone = any("git clone" in c for c in gocd_commands)
        has_fetch_artifact = any(
            t["type"] == "fetch"
            for s in pinfo["stages"]
            for j in s["jobs"]
            for t in j["tasks"]
        )
        has_approval = any(s["approval"] for s in pinfo["stages"])
        has_timer = pinfo.get("timer") is not None

    # Harness-side checks
    harness_step_types = set()
    harness_has_approval = False
    harness_has_rollback = False
    harness_has_k8s_deploy = False

    for hpath in harness_files:
        hinfo = parse_harness(hpath)
        for stage in hinfo["stages"]:
            for step in stage["steps"]:
                harness_step_types.add(step["type"])
                if step["type"] == "HarnessApproval":
                    harness_has_approval = True
                if step["type"] in ("K8sRollingDeploy", "K8sCanaryDeploy", "K8sBGDeploy"):
                    harness_has_k8s_deploy = True
            if stage["rollback_steps"]:
                harness_has_rollback = True

    notes.append("**Preserved in conversion:**")
    preserved = []
    preserved.append("All shell/exec commands are mapped to ShellScript steps running on delegates")
    if has_git_clone:
        preserved.append("Git clone and branch checkout logic is retained in shell steps")
    if has_docker_build:
        preserved.append("Docker build and push commands are preserved")
    if has_k8s_deploy and harness_has_k8s_deploy:
        preserved.append("Kubernetes deployment is handled via native K8sRollingDeploy step")
    if has_approval and harness_has_approval:
        preserved.append("Manual approval gates are converted to HarnessApproval steps")
    if has_fetch_artifact:
        preserved.append("Artifact fetching between stages is handled via output variables / file store")
    for p in preserved:
        notes.append(f"- {p}")

    notes.append("")
    notes.append("**Differences to be aware of:**")
    diffs = []
    if has_k8s_deploy and harness_has_k8s_deploy:
        diffs.append("Harness uses native K8s rolling deploy with built-in rollback, replacing custom deploy scripts")
    if harness_has_rollback:
        diffs.append("Harness adds automatic rollback steps (K8sRollingRollback) not present in GoCD")
    if has_fetch_artifact:
        diffs.append("GoCD `fetch` artifact tasks are replaced by Harness output variables or File Store uploads — verify artifact paths")
    if has_timer:
        diffs.append("Timer/cron schedule should be verified as a Harness Cron Trigger after pipeline creation")
    if has_terraform:
        diffs.append("Terraform commands run as shell steps — consider migrating to Harness Terraform Provider steps for better state management")
    if not diffs:
        diffs.append("Shell commands are executed as-is; verify environment-specific paths and secrets are accessible from the delegate")
    for d in diffs:
        notes.append(f"- {d}")

    notes.append("")
    notes.append("> **Recommendation:** Run the Harness pipeline in a non-production environment first. "
                 "Compare the execution logs side-by-side with a recent GoCD run to confirm identical behavior "
                 "before decommissioning the GoCD pipeline.")

    return "\n".join(notes)


# ---------------------------------------------------------------------------
# Main: rewrite entities.md for every subfolder
# ---------------------------------------------------------------------------

def process_folder(folder: Path):
    """Enhance entities.md for a single converted pipeline folder."""
    # Find source GoCD YAML
    gocd_files = list(folder.glob("SOURCE_*.gocd.yaml"))
    if not gocd_files:
        return False
    gocd_file = gocd_files[0]

    # Find Harness YAML(s)
    harness_files = sorted(folder.glob("*.harness.yaml"))
    if not harness_files:
        return False

    # Read existing entities.md to preserve only the entity list entries
    # Entity entries match pattern: ## Type: `identifier`
    existing_entities_text = ""
    entities_path = folder / "entities.md"
    entity_type_prefixes = (
        "## Project:", "## Service:", "## Environment:", "## Connector:",
        "## Delegate:", "## Secret:", "## UserGroup:", "## InfrastructureDefinition:",
        "## Template:", "## Trigger:", "## Pipeline:", "## InputSet:",
    )
    if entities_path.exists():
        with open(entities_path) as f:
            full_text = f.read()
        lines = full_text.split("\n")
        entity_lines = []
        capturing = False
        for line in lines:
            if any(line.startswith(prefix) for prefix in entity_type_prefixes):
                capturing = True
            elif line.startswith("## ") and not any(line.startswith(prefix) for prefix in entity_type_prefixes):
                capturing = False
            elif line.startswith("---") and capturing:
                capturing = False
            if capturing:
                entity_lines.append(line)
        existing_entities_text = "\n".join(entity_lines).strip()

    # Parse GoCD
    try:
        gocd_pipelines = parse_gocd(gocd_file)
    except Exception as e:
        print(f"  WARN: Could not parse GoCD YAML {gocd_file.name}: {e}")
        return False

    # Parse Harness
    harness_infos = []
    for hf in harness_files:
        try:
            harness_infos.append((hf, parse_harness(hf)))
        except Exception as e:
            print(f"  WARN: Could not parse Harness YAML {hf.name}: {e}")

    if not harness_infos:
        return False

    sample_name = folder.name

    # Build enhanced entities.md
    out = []
    out.append(f"# {sample_name} — Migration Reference\n")
    out.append(f"Source: `{gocd_file.name}`\n")

    # --- Section 1: GoCD Pipeline Summary ---
    out.append("---\n")
    out.append("## GoCD Pipeline Summary\n")
    out.append("What the original GoCD pipeline(s) were doing:\n")
    for pname, pinfo in gocd_pipelines.items():
        out.append(summarize_gocd_pipeline(pinfo))
        out.append("")

    # --- Section 2: Harness Pipeline Summary ---
    out.append("---\n")
    out.append("## Harness Pipeline Summary\n")
    out.append("What the converted Harness pipeline(s) do:\n")
    for hpath, hinfo in harness_infos:
        out.append(f"File: `{hpath.name}`\n")
        out.append(summarize_harness_pipeline(hinfo))
        out.append("")

    # --- Section 3: Business Logic Parity ---
    out.append("---\n")
    out.append("## Business Logic Parity\n")
    out.append(generate_parity_notes(gocd_pipelines, harness_files))
    out.append("")

    # --- Section 4: Entity Mapping ---
    out.append("---\n")
    out.append("## Entity Mapping (GoCD → Harness)\n")
    out.append("Use this table to trace every GoCD entity to its Harness equivalent. "
               "If something fails, this is your debugging reference.\n")
    out.append(generate_entity_mapping(gocd_pipelines, harness_files))
    out.append("")

    # --- Section 5: Required Harness Entities ---
    out.append("---\n")
    out.append("## Required Harness Entities\n")
    if existing_entities_text:
        out.append(existing_entities_text)
    else:
        out.append("_No entity data available. Re-run conversion to populate._")
    out.append("")

    with open(entities_path, "w") as f:
        f.write("\n".join(out) + "\n")

    return True


def main():
    if not OUTPUT_DIR.exists():
        print(f"ERROR: Output directory not found: {OUTPUT_DIR}")
        sys.exit(1)

    folders = sorted([
        d for d in OUTPUT_DIR.iterdir()
        if d.is_dir() and not d.name.startswith(".")
    ])
    print(f"Found {len(folders)} pipeline folders in {OUTPUT_DIR.name}")

    success = 0
    skipped = 0
    for i, folder in enumerate(folders, 1):
        try:
            ok = process_folder(folder)
            if ok:
                success += 1
                if i % 20 == 0 or i == len(folders):
                    print(f"  [{i:3d}/{len(folders)}] Processed {success} so far...")
            else:
                skipped += 1
        except Exception as e:
            skipped += 1
            print(f"  [{i:3d}/{len(folders)}] ERROR {folder.name}: {e}")

    print(f"\nDone: {success} enhanced, {skipped} skipped out of {len(folders)} folders")


if __name__ == "__main__":
    main()
