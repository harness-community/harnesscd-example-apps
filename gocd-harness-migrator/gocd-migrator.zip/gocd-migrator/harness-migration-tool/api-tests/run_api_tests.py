#!/usr/bin/env python3
"""
End-to-end API test suite for the Harness Migration Tool.

Picks a diverse set of GoCD sample YAMLs, calls the /convert endpoint,
saves individual Harness pipeline YAMLs, entity lists, and trigger YAMLs
into the api-tests/ directory, and produces a summary report.
"""

import json
import os
import shutil
import sys
import time
from pathlib import Path
from typing import Dict, Any

import requests

from enhance_entities import process_folder

API_BASE = "http://localhost:8080"
SAMPLES_DIR = Path(__file__).resolve().parent.parent.parent / "GoCD sample yamls"
OUTPUT_DIR = Path(__file__).resolve().parent / "results"

TEST_SAMPLES = [
    # (filename, expected pattern category)
    ("reco-autogen-ab-rds-apse1-prod.gocd.yaml", "terraform_infra"),
    ("personalisation-persona-service.gocd.yaml", "docker_k8s_deploy"),
    ("reco-copy-prod-data-deploy.gocd.yaml", "data_pipeline"),
    ("discovery-incidents-report.gocd.yaml", "ops_script"),
    ("persona-service-launch-darkly.gocd.yaml", "ld_terraform"),
    ("p13n-feature-store-database.gocd.yaml", "db_migration"),
    ("hs-discovery-locust.gocd.yaml", "perf_test"),
    ("personalisation-degradation.gocd.yaml", "ops_script_misc"),
    ("personalisation-pr-merge-github-app.gocd.yaml", "pr_build"),
    ("reco-content-similarity-offline-pipelines.gocd.yaml", "multi_pipeline"),
    ("personalisation-copy-cms-meta.gocd.yaml", "s3_data_copy"),
    ("personalisation-telegraf.gocd.yaml", "telegraf"),
]


def check_health() -> Dict[str, Any]:
    resp = requests.get(f"{API_BASE}/health")
    resp.raise_for_status()
    return resp.json()


def convert_file(filepath: Path) -> Dict[str, Any]:
    with open(filepath, "rb") as f:
        resp = requests.post(f"{API_BASE}/convert", files={"file": (filepath.name, f, "text/yaml")})
    resp.raise_for_status()
    return resp.json()


def batch_convert(filepaths: list) -> Dict[str, Any]:
    files = []
    for fp in filepaths:
        files.append(("files", (fp.name, open(fp, "rb"), "text/yaml")))
    resp = requests.post(f"{API_BASE}/batch", files=files)
    for _, (_, fobj, _) in files:
        fobj.close()
    resp.raise_for_status()
    return resp.json()


def save_results(result: Dict[str, Any], sample_name: str, out_dir: Path, source_filepath: Path = None):
    """Save source GoCD YAML, converted Harness YAMLs, entity list, and triggers."""
    sample_dir = out_dir / sample_name
    sample_dir.mkdir(parents=True, exist_ok=True)

    # Copy the original GoCD YAML into the results folder
    if source_filepath and source_filepath.exists():
        shutil.copy2(source_filepath, sample_dir / f"SOURCE_{source_filepath.name}")

    # Save full JSON response
    with open(sample_dir / "response.json", "w") as f:
        json.dump(result, f, indent=2)

    # Save each pipeline YAML
    for i, pipeline in enumerate(result.get("pipelines", [])):
        pipeline_name = pipeline.get("source_pipeline_name", f"pipeline_{i}")
        safe_name = pipeline_name.replace("/", "_").replace(" ", "_")

        yaml_path = sample_dir / f"{safe_name}.harness.yaml"
        with open(yaml_path, "w") as f:
            f.write(pipeline.get("harness_yaml", "# No YAML generated"))

        # Save triggers
        for j, trigger in enumerate(pipeline.get("triggers", [])):
            trig_path = sample_dir / f"{safe_name}.trigger_{j}.yaml"
            with open(trig_path, "w") as f:
                f.write(trigger.get("yaml", "# No trigger YAML"))

    # Save consolidated entity list
    entities = result.get("all_entities", [])
    entity_path = sample_dir / "entities.md"
    with open(entity_path, "w") as f:
        f.write(f"# Required Harness Entities for {sample_name}\n\n")
        f.write(f"Total entities: {len(entities)}\n\n")
        if not entities:
            f.write("_No additional entities required._\n")
        for entity in entities:
            f.write(f"## {entity['type']}: `{entity['identifier']}`\n\n")
            f.write(f"- **Name:** {entity['name']}\n")
            f.write(f"- **API Creatable:** {'Yes' if entity.get('api_creatable') else 'No'}\n")
            if entity.get("manual_instructions"):
                f.write(f"- **Manual Instructions:** {entity['manual_instructions']}\n")
            if entity.get("payload"):
                f.write(f"- **API Payload:**\n```json\n{json.dumps(entity['payload'], indent=2)}\n```\n")
            f.write("\n")

    # Save a README that maps source -> output for quick orientation
    pipelines = result.get("pipelines", [])
    readme_path = sample_dir / "README.md"
    with open(readme_path, "w") as f:
        f.write(f"# {sample_name}\n\n")
        f.write(f"**Source:** `SOURCE_{source_filepath.name if source_filepath else 'unknown'}`\n\n")
        f.write(f"## Conversion Summary\n\n")
        f.write(f"| # | GoCD Pipeline | Pattern | Confidence | Harness YAML | Triggers |\n")
        f.write(f"|---|---------------|---------|------------|--------------|----------|\n")
        for i, p in enumerate(pipelines, 1):
            pname = p.get("source_pipeline_name", f"pipeline_{i}")
            safe = pname.replace("/", "_").replace(" ", "_")
            pattern = p.get("pattern", "?")
            conf = p.get("confidence", 0)
            n_trig = len(p.get("triggers", []))
            trig_str = f"{n_trig} trigger(s)" if n_trig else "-"
            f.write(f"| {i} | {pname} | {pattern} | {conf:.0f}% | `{safe}.harness.yaml` | {trig_str} |\n")
        f.write(f"\nSee `entities.md` for the full list of Harness entities to create.\n")

    try:
        process_folder(sample_dir)
    except Exception as enhance_exc:
        print(f"    WARN: Could not enhance entities.md: {enhance_exc}")


def run_tests():
    print("=" * 70)
    print("Harness Migration Tool – API Test Suite")
    print("=" * 70)

    # Health check
    print("\n[1/3] Health Check")
    health = check_health()
    print(f"  Status: {health['status']}")
    print(f"  Version: {health['version']}")
    print(f"  Converters: {health['converters']}, Patterns: {health['patterns']}")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # Individual conversions
    print(f"\n[2/3] Individual File Conversions ({len(TEST_SAMPLES)} files)")
    print("-" * 70)

    summary_rows = []
    total_pipelines = 0
    total_entities = 0
    total_triggers = 0
    errors = []

    for filename, expected_category in TEST_SAMPLES:
        filepath = SAMPLES_DIR / filename
        if not filepath.exists():
            print(f"  SKIP  {filename} (file not found)")
            errors.append((filename, "File not found"))
            continue

        try:
            start = time.time()
            result = convert_file(filepath)
            elapsed = time.time() - start

            n_pipelines = result.get("total_pipelines", 0)
            n_success = result.get("successful", 0)
            n_failed = result.get("failed", 0)
            n_entities = len(result.get("all_entities", []))
            n_triggers = sum(
                len(p.get("triggers", []))
                for p in result.get("pipelines", [])
            )
            patterns = [p.get("pattern", "?") for p in result.get("pipelines", [])]

            status = "PASS" if n_failed == 0 else "WARN"
            total_pipelines += n_pipelines
            total_entities += n_entities
            total_triggers += n_triggers

            save_results(result, filename.replace(".gocd.yaml", ""), OUTPUT_DIR, source_filepath=filepath)

            print(f"  {status}  {filename}")
            print(f"        Pipelines: {n_pipelines} (ok={n_success}, fail={n_failed}) | "
                  f"Entities: {n_entities} | Triggers: {n_triggers} | "
                  f"Patterns: {', '.join(patterns)} | {elapsed:.2f}s")

            warnings = []
            for p in result.get("pipelines", []):
                warnings.extend(p.get("warnings", []))
            if warnings:
                for w in warnings[:3]:
                    print(f"        ⚠ {w}")
                if len(warnings) > 3:
                    print(f"        ... and {len(warnings) - 3} more warnings")

            summary_rows.append({
                "file": filename,
                "pipelines": n_pipelines,
                "success": n_success,
                "failed": n_failed,
                "entities": n_entities,
                "triggers": n_triggers,
                "patterns": patterns,
                "elapsed": elapsed,
                "status": status,
            })

        except Exception as exc:
            print(f"  FAIL  {filename}: {exc}")
            errors.append((filename, str(exc)))
            summary_rows.append({
                "file": filename,
                "pipelines": 0,
                "success": 0,
                "failed": 0,
                "entities": 0,
                "triggers": 0,
                "patterns": [],
                "elapsed": 0,
                "status": "FAIL",
            })

    # Batch conversion test
    print(f"\n[3/3] Batch Conversion Test (first 5 files)")
    print("-" * 70)
    batch_files = [SAMPLES_DIR / f for f, _ in TEST_SAMPLES[:5] if (SAMPLES_DIR / f).exists()]
    try:
        start = time.time()
        batch_result = batch_convert(batch_files)
        elapsed = time.time() - start
        print(f"  Files: {batch_result.get('total_files', 0)}")
        print(f"  Total pipelines: {batch_result.get('total_pipelines', 0)}")
        print(f"  Successful: {batch_result.get('successful', 0)}")
        print(f"  Failed: {batch_result.get('failed', 0)}")
        print(f"  Global entities: {len(batch_result.get('all_entities', []))}")
        print(f"  Elapsed: {elapsed:.2f}s")

        batch_dir = OUTPUT_DIR / "_batch_test"
        batch_dir.mkdir(parents=True, exist_ok=True)
        with open(batch_dir / "batch_response.json", "w") as f:
            json.dump(batch_result, f, indent=2)

    except Exception as exc:
        print(f"  FAIL: {exc}")
        errors.append(("batch", str(exc)))

    # Summary report
    print("\n" + "=" * 70)
    print("SUMMARY")
    print("=" * 70)
    print(f"  Files tested:    {len(summary_rows)}")
    print(f"  Total pipelines: {total_pipelines}")
    print(f"  Total entities:  {total_entities}")
    print(f"  Total triggers:  {total_triggers}")
    passed = sum(1 for r in summary_rows if r["status"] == "PASS")
    warned = sum(1 for r in summary_rows if r["status"] == "WARN")
    failed = sum(1 for r in summary_rows if r["status"] == "FAIL")
    print(f"  PASS: {passed}  |  WARN: {warned}  |  FAIL: {failed}")

    if errors:
        print(f"\n  Errors ({len(errors)}):")
        for name, err in errors:
            print(f"    - {name}: {err}")

    # Save summary report as markdown
    report_path = OUTPUT_DIR / "SUMMARY.md"
    with open(report_path, "w") as f:
        f.write("# API Test Results\n\n")
        f.write(f"**Date:** {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        f.write(f"| File | Pipelines | Entities | Triggers | Pattern(s) | Status | Time |\n")
        f.write(f"|------|-----------|----------|----------|------------|--------|------|\n")
        for row in summary_rows:
            patterns_str = ", ".join(row["patterns"]) if row["patterns"] else "-"
            f.write(
                f"| {row['file']} | {row['pipelines']} "
                f"| {row['entities']} | {row['triggers']} "
                f"| {patterns_str} | {row['status']} | {row['elapsed']:.2f}s |\n"
            )
        f.write(f"\n**Totals:** {total_pipelines} pipelines, {total_entities} entities, {total_triggers} triggers\n")
        if errors:
            f.write(f"\n## Errors\n\n")
            for name, err in errors:
                f.write(f"- **{name}**: {err}\n")

    print(f"\n  Results saved to: {OUTPUT_DIR}")
    print(f"  Summary report:  {report_path}")
    print("=" * 70)

    return len(errors) == 0


if __name__ == "__main__":
    success = run_tests()
    sys.exit(0 if success else 1)
