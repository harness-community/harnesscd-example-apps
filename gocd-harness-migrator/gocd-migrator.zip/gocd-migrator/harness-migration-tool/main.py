#!/usr/bin/env python3
"""
Harness Migration Tool -- Main Entry Point.

Supports CLI usage for local conversion and FastAPI for hosted deployment.

CLI Usage:
    python main.py convert --input file.yaml --output output/
    python main.py batch --input-dir samples/ --output output/
    python main.py classify --input file.yaml
    python main.py serve  (starts FastAPI server)
"""

import sys
import argparse
import json
from pathlib import Path

from config import config
from src.core.engine import ConversionEngine


def cmd_convert(args):
    """Convert a single GoCD YAML file."""
    engine = ConversionEngine()
    input_path = Path(args.input)
    output_dir = Path(args.output)

    if not input_path.exists():
        print(f"Error: File not found: {input_path}")
        sys.exit(1)

    print(f"\n{'='*60}")
    print(f"  Harness Migration Tool v{config.app.version}")
    print(f"{'='*60}\n")
    print(f"  Input:  {input_path}")
    print(f"  Output: {output_dir}\n")

    results = engine.convert_file(input_path)

    print(f"  Pipelines found: {len(results)}")
    print()

    for result in results:
        status = "OK" if result.success else "FAIL"
        pattern = result.pattern.pattern_name if result.pattern else "N/A"
        confidence = result.pattern.confidence if result.pattern else 0
        print(f"  [{status}] {result.source_pipeline_name}")
        print(f"         Pattern: {pattern} ({confidence:.0f}% confidence)")
        if result.warnings:
            for w in result.warnings:
                print(f"         Warning: {w}")
        if result.errors:
            for e in result.errors:
                print(f"         Error: {e}")
        print()

    # Write output
    engine.write_results(results, output_dir)
    successful = sum(1 for r in results if r.success)
    print(f"  Wrote {successful} pipeline(s) to {output_dir}")
    print()


def cmd_batch(args):
    """Convert all YAML files in a directory."""
    engine = ConversionEngine()
    input_dir = Path(args.input_dir)
    output_dir = Path(args.output)

    if not input_dir.is_dir():
        print(f"Error: Directory not found: {input_dir}")
        sys.exit(1)

    print(f"\n{'='*60}")
    print(f"  Harness Migration Tool v{config.app.version}")
    print(f"  Batch Mode")
    print(f"{'='*60}\n")

    # Collect all YAML files
    pattern = args.glob or "*.yaml"
    batch = engine.convert_batch(input_dir, glob_pattern=pattern)

    print(f"  Files processed:    {batch.total_files}")
    print(f"  Pipelines found:    {batch.total_pipelines}")
    print(f"  Successful:         {batch.successful}")
    print(f"  Failed:             {batch.failed}")
    print(f"  LLM fallback used:  {batch.llm_fallback_used}")
    print(f"  Success rate:       {batch.success_rate:.1f}%")
    print()

    # Show failures
    failures = [r for r in batch.results if not r.success]
    if failures:
        print("  --- Failures ---")
        for r in failures:
            print(f"  [{r.source_file}] {r.source_pipeline_name}: {'; '.join(r.errors)}")
        print()

    # Pattern distribution
    pattern_counts = {}
    for r in batch.results:
        if r.pattern:
            key = r.pattern.pattern_name
            pattern_counts[key] = pattern_counts.get(key, 0) + 1

    print("  --- Pattern Distribution ---")
    for pattern_name, count in sorted(pattern_counts.items(), key=lambda x: -x[1]):
        print(f"  {count:4d}  {pattern_name}")
    print()

    # Write output
    engine.write_results(batch.results, output_dir)
    print(f"  Wrote {batch.successful} pipeline(s) to {output_dir}")

    # Write batch report
    report_path = output_dir / "migration_report.json"
    report = {
        "total_files": batch.total_files,
        "total_pipelines": batch.total_pipelines,
        "successful": batch.successful,
        "failed": batch.failed,
        "success_rate": f"{batch.success_rate:.1f}%",
        "pattern_distribution": pattern_counts,
        "entities": [
            {"type": e.type.value if hasattr(e.type, 'value') else str(e.type),
             "identifier": e.identifier,
             "name": e.name,
             "api_creatable": e.api_creatable}
            for e in batch.all_entities
        ],
        "failures": [
            {"file": r.source_file, "pipeline": r.source_pipeline_name, "errors": r.errors}
            for r in failures
        ],
    }
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"  Report: {report_path}")
    print()


def cmd_classify(args):
    """Classify pipelines without converting."""
    engine = ConversionEngine()
    input_path = Path(args.input)

    if not input_path.exists():
        print(f"Error: File not found: {input_path}")
        sys.exit(1)

    from src.parsers.gocd import GocdParser
    from src.classifiers.gocd import GocdClassifier

    parser = GocdParser()
    classifier = GocdClassifier()

    pipelines = parser.parse_file(input_path)

    print(f"\nClassification results for: {input_path}\n")
    for p in pipelines:
        match = classifier.classify(p)
        print(f"  Pipeline: {p.name}")
        print(f"  Pattern:  {match.pattern_name} ({match.confidence:.0f}%)")
        print(f"  Converter: {match.converter_key}")
        print(f"  Signals:")
        for s in match.signals:
            print(f"    - {s}")
        print()


def cmd_serve(args):
    """Start the FastAPI server."""
    import uvicorn
    # Import here to avoid circular imports
    from api.routes import app
    uvicorn.run(
        app,
        host=config.app.host,
        port=config.app.port,
        reload=config.app.debug,
    )


def main():
    parser = argparse.ArgumentParser(
        description="Harness Migration Tool - Convert CI/CD pipelines to Harness",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # convert
    p_convert = subparsers.add_parser("convert", help="Convert a single file")
    p_convert.add_argument("-i", "--input", required=True, help="Input GoCD YAML file")
    p_convert.add_argument("-o", "--output", required=True, help="Output directory")

    # batch
    p_batch = subparsers.add_parser("batch", help="Convert all files in a directory")
    p_batch.add_argument("-i", "--input-dir", required=True, help="Input directory")
    p_batch.add_argument("-o", "--output", required=True, help="Output directory")
    p_batch.add_argument("-g", "--glob", default="*.yaml", help="File glob pattern")

    # classify
    p_classify = subparsers.add_parser("classify", help="Classify pipelines (no conversion)")
    p_classify.add_argument("-i", "--input", required=True, help="Input GoCD YAML file")

    # serve
    p_serve = subparsers.add_parser("serve", help="Start the web server")

    args = parser.parse_args()

    commands = {
        "convert": cmd_convert,
        "batch": cmd_batch,
        "classify": cmd_classify,
        "serve": cmd_serve,
    }

    if args.command in commands:
        commands[args.command](args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
