"""
FastAPI routes for the Harness Migration Tool.

Endpoints:
  POST /convert        – Convert GoCD YAML (text body or file upload)
  POST /convert/json   – Convert GoCD YAML (JSON body with gocd_yaml field)
  POST /batch          – Convert multiple GoCD YAML files (multipart upload)
  GET  /health         – Health check
"""

import sys
from pathlib import Path
from io import StringIO
from typing import List

from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware

# Ensure project root is importable
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import config
from src.core.engine import ConversionEngine
from src.core.models import ConversionResult, Entity
from src.converters.gocd import list_converters
from api.schemas import (
    ConvertResponse, ConvertRequest, BatchConvertResponse,
    PipelineConversion, EntityResponse, TriggerResponse, HealthResponse,
)
from api.serializer import result_to_pipeline_yaml, result_to_trigger_yamls


app = FastAPI(
    title=config.app.app_name,
    version=config.app.version,
    description=(
        "Converts GoCD pipeline YAMLs to Harness pipeline YAMLs. "
        "Returns the Harness YAML along with a complete entity list "
        "(identifiers match the pipeline YAML references)."
    ),
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

engine = ConversionEngine()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _entity_to_response(entity: Entity) -> EntityResponse:
    return EntityResponse(
        type=entity.type.value if hasattr(entity.type, "value") else str(entity.type),
        identifier=entity.identifier,
        name=entity.name,
        api_creatable=entity.api_creatable,
        payload=entity.payload,
        manual_instructions=entity.manual_instructions,
    )


def _result_to_pipeline(result: ConversionResult) -> PipelineConversion:
    pipeline_yaml = result_to_pipeline_yaml(result)
    trigger_yamls = result_to_trigger_yamls(result)

    triggers = []
    for t in trigger_yamls:
        triggers.append(TriggerResponse(
            name=t["name"],
            identifier=t["identifier"],
            type=t["type"],
            yaml=t["yaml"],
        ))

    entities = [_entity_to_response(e) for e in result.entities]

    return PipelineConversion(
        source_pipeline_name=result.source_pipeline_name,
        pattern=result.pattern.pattern_id if result.pattern else "unknown",
        pattern_name=result.pattern.pattern_name if result.pattern else "Unknown",
        confidence=result.pattern.confidence if result.pattern else 0,
        converter=result.pattern.converter_key if result.pattern else "generic",
        harness_yaml=pipeline_yaml,
        triggers=triggers,
        entities=entities,
        warnings=result.warnings + result.errors,
        success=result.success,
    )


def _convert_content(content: str, filename: str = "input.yaml") -> ConvertResponse:
    """Core conversion logic shared by all endpoints."""
    try:
        pipelines = engine.parser.parse_content(content, filename=filename)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Failed to parse GoCD YAML: {exc}")

    if not pipelines:
        raise HTTPException(status_code=400, detail="No pipelines found in the provided YAML")

    results: List[ConversionResult] = []
    for pipeline in pipelines:
        result = engine.convert_pipeline(pipeline, source_file=filename)
        results.append(result)

    pipeline_responses = [_result_to_pipeline(r) for r in results]
    all_entities = [
        _entity_to_response(e)
        for e in engine._deduplicate_entities(results)
    ]

    successful = sum(1 for r in results if r.success)
    failed = len(results) - successful

    return ConvertResponse(
        source_filename=filename,
        pipelines=pipeline_responses,
        all_entities=all_entities,
        total_pipelines=len(results),
        successful=successful,
        failed=failed,
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.post("/convert", response_model=ConvertResponse)
async def convert_file(file: UploadFile = File(...)):
    """
    Convert a GoCD YAML file to Harness YAML(s).

    Upload a single `.yaml` file. Returns one or more Harness pipeline YAMLs
    plus a complete entity list with identifiers matching the YAML references.
    """
    content = await file.read()
    try:
        text = content.decode("utf-8")
    except UnicodeDecodeError:
        raise HTTPException(status_code=400, detail="File must be valid UTF-8 text")

    return _convert_content(text, filename=file.filename or "upload.yaml")


@app.post("/convert/json", response_model=ConvertResponse)
async def convert_json(request: ConvertRequest):
    """
    Convert GoCD YAML provided as a JSON string payload.

    Accepts `{"gocd_yaml": "...", "filename": "..."}`.
    """
    return _convert_content(request.gocd_yaml, filename=request.filename)


@app.post("/convert/text", response_model=ConvertResponse)
async def convert_text(gocd_yaml: str = Form(...), filename: str = Form("input.yaml")):
    """
    Convert GoCD YAML provided as form-encoded text.

    Useful for simple HTML form submissions.
    """
    return _convert_content(gocd_yaml, filename=filename)


@app.post("/batch", response_model=BatchConvertResponse)
async def batch_convert(files: List[UploadFile] = File(...)):
    """
    Convert multiple GoCD YAML files in a single request.

    Upload multiple `.yaml` files. Returns conversion results per file,
    plus a single deduplicated entity list across all files.
    """
    all_results: List[ConversionResult] = []
    file_responses: List[ConvertResponse] = []

    for upload in files:
        content = await upload.read()
        try:
            text = content.decode("utf-8")
        except UnicodeDecodeError:
            file_responses.append(ConvertResponse(
                source_filename=upload.filename or "unknown",
                pipelines=[],
                total_pipelines=0,
                successful=0,
                failed=1,
            ))
            continue

        resp = _convert_content(text, filename=upload.filename or "upload.yaml")
        file_responses.append(resp)

    # Collect all results for global dedup
    global_results = []
    for upload in files:
        content = await upload.read()
        # Files already consumed above; re-read from responses
    # Actually, collect from the file_responses
    total_pipelines = sum(f.total_pipelines for f in file_responses)
    successful = sum(f.successful for f in file_responses)
    failed = sum(f.failed for f in file_responses)

    # Deduplicate entities across all files
    seen = set()
    all_entities: List[EntityResponse] = []
    for resp in file_responses:
        for entity in resp.all_entities:
            key = f"{entity.type}:{entity.identifier}"
            if key not in seen:
                seen.add(key)
                all_entities.append(entity)

    return BatchConvertResponse(
        files=file_responses,
        all_entities=all_entities,
        total_files=len(files),
        total_pipelines=total_pipelines,
        successful=successful,
        failed=failed,
    )


@app.get("/health", response_model=HealthResponse)
async def health():
    """Health check endpoint."""
    from src.classifiers.gocd import PATTERNS
    converters = list_converters()
    return HealthResponse(
        status="healthy",
        version=config.app.version,
        converters=len(converters),
        patterns=len(PATTERNS),
    )
