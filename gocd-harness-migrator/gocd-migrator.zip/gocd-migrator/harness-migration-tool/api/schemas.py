"""
API request/response schemas.

Every conversion response returns:
  - One or more Harness pipeline YAMLs (a single GoCD file can define multiple pipelines)
  - A complete entity list with identifiers that match the pipeline YAML references
  - Triggers (if any) as separate YAML blocks
  - Warnings for anything that needs manual attention
"""

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any


# ---------------------------------------------------------------------------
# Response Models
# ---------------------------------------------------------------------------

class EntityResponse(BaseModel):
    """A Harness entity required by the generated pipeline(s)."""
    type: str = Field(..., description="Entity type: Project, Connector, Secret, Delegate, Service, Environment, etc.")
    identifier: str = Field(..., description="Harness identifier (matches references in pipeline YAML)")
    name: str = Field(..., description="Human-readable name")
    api_creatable: bool = Field(True, description="Whether this entity can be created via Harness API")
    payload: Dict[str, Any] = Field(default_factory=dict, description="API creation payload (if api_creatable)")
    manual_instructions: str = Field("", description="Manual setup instructions (if not api_creatable)")


class TriggerResponse(BaseModel):
    """A Harness trigger that should be created alongside the pipeline."""
    name: str
    identifier: str
    type: str = Field(..., description="Scheduled or Pipeline")
    yaml: str = Field(..., description="Full trigger YAML")


class PipelineConversion(BaseModel):
    """Result of converting a single GoCD pipeline to Harness."""
    source_pipeline_name: str = Field(..., description="Original GoCD pipeline name")
    pattern: str = Field(..., description="Detected GoCD pattern (e.g., terraform_infra, k8s_deploy)")
    pattern_name: str = Field("", description="Human-readable pattern label")
    confidence: float = Field(..., description="Pattern match confidence (0-100)")
    converter: str = Field(..., description="Converter used (e.g., terraform_infra, generic)")
    harness_yaml: str = Field(..., description="Generated Harness pipeline YAML")
    triggers: List[TriggerResponse] = Field(default_factory=list, description="Associated triggers")
    entities: List[EntityResponse] = Field(default_factory=list, description="Required Harness entities")
    warnings: List[str] = Field(default_factory=list, description="Items needing manual attention")
    success: bool = True


class ConvertResponse(BaseModel):
    """Response for a single GoCD YAML conversion (may contain multiple pipelines)."""
    source_filename: str = Field("", description="Original filename (if uploaded)")
    pipelines: List[PipelineConversion] = Field(..., description="One entry per GoCD pipeline found in the input")
    all_entities: List[EntityResponse] = Field(
        default_factory=list,
        description="Deduplicated entity list across all pipelines (identifiers match YAML references)",
    )
    total_pipelines: int = 0
    successful: int = 0
    failed: int = 0


class BatchConvertResponse(BaseModel):
    """Response for batch conversion of multiple GoCD YAML files."""
    files: List[ConvertResponse] = Field(default_factory=list)
    all_entities: List[EntityResponse] = Field(
        default_factory=list,
        description="Deduplicated entity list across ALL files and pipelines",
    )
    total_files: int = 0
    total_pipelines: int = 0
    successful: int = 0
    failed: int = 0


class HealthResponse(BaseModel):
    """Health check response."""
    status: str = "healthy"
    version: str = ""
    converters: int = 0
    patterns: int = 0


# ---------------------------------------------------------------------------
# Request Models
# ---------------------------------------------------------------------------

class ConvertRequest(BaseModel):
    """Convert GoCD YAML provided as a string."""
    gocd_yaml: str = Field(..., description="Raw GoCD YAML content")
    filename: str = Field("input.yaml", description="Optional source filename for reference")
