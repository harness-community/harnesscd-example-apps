"""
YAML serializer for conversion results.

Handles:
  - Extracting the pipeline YAML (excluding internal keys like _triggers)
  - Extracting trigger YAMLs as separate blocks
  - Clean serialization via ruamel.yaml for proper formatting
"""

from io import StringIO
from typing import Dict, Any, List

from ruamel.yaml import YAML

from src.core.models import ConversionResult


def _get_yaml_serializer() -> YAML:
    y = YAML()
    y.default_flow_style = False
    y.width = 120
    y.best_map_representor = True
    return y


def _dump(data: Dict[str, Any]) -> str:
    y = _get_yaml_serializer()
    buf = StringIO()
    y.dump(data, buf)
    return buf.getvalue()


def result_to_pipeline_yaml(result: ConversionResult) -> str:
    """Serialize just the pipeline portion (no _triggers or internal keys)."""
    if not result.harness_yaml:
        return ""
    clean = {k: v for k, v in result.harness_yaml.items() if not k.startswith("_")}
    return _dump(clean)


def result_to_trigger_yamls(result: ConversionResult) -> List[Dict[str, Any]]:
    """Extract trigger blocks as individual serialized YAMLs."""
    if not result.harness_yaml:
        return []

    raw_triggers = result.harness_yaml.get("_triggers", [])
    if not raw_triggers:
        return []

    triggers = []
    for t in raw_triggers:
        trigger_data = t.get("trigger", t)
        triggers.append({
            "name": trigger_data.get("name", "unknown"),
            "identifier": trigger_data.get("identifier", "unknown"),
            "type": trigger_data.get("type", "Unknown"),
            "yaml": _dump(t),
        })
    return triggers
